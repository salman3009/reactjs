function Fhome(){
    return(
        <div className="Home">
        Welcome To ARK Bakery 
        Login/Register To See the Magic....
        </div>
    )
}
export default Fhome