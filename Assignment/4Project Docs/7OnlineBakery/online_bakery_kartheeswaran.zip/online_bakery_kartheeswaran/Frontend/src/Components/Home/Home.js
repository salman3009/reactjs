function Home(){
    return(
        <div className="Home">
        welcome to ARK Bakery
        See the dishes in above..
        </div>
    )
}
export default Home