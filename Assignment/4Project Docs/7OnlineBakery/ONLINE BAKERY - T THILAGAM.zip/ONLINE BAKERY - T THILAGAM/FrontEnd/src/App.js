
import './App.css';
import './asserts/font-awesome/css/font-awesome.min.css';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Intro from './components/Intro/Intro';
import Header from './components/Header/Header';
import Register from './components/Register/Register';
import Login from './components/Login/Login';
import SearchItems from './components/SearchItems/SearchItems';
import AddImages from './components/AddImages/AddImages';
import Brownie from './components/Brownie/Brownie';
import Cookies from './components/Cookies/Cookies';
import Cakes from './components/Cakes/Cakes';
import Puddings from './components/Puddings/Puddings';
import PlaceOrder from './components/PlaceOrder/PlaceOrder';
import ViewCart from './components/ViewCart/ViewCart';



function App() {
  return (
    <div>
        <BrowserRouter>      
          <Routes>      
            <Route path='' element={<><Header/><Intro/></>}/>  
            <Route path='/Intro' element={<><Header/><Intro/></>}/> 
            <Route path='/Login' element={<><Header/><Login/></>}/>
            <Route path='/Register' element={<><Header/><Register/></>}/>
            <Route path='/Brownie' element={<><Header/><Brownie/></>}/>
            <Route path='/AddImages' element={<><Header/><AddImages/></>}/>
            <Route path='/SearchItems' element={<><Header/><SearchItems/></>}/>
            <Route path='/Cakes' element={<><Header/><Cakes/></>}/>
            <Route path='/Puddings' element={<><Header/><Puddings/></>}/>
            <Route path='/Cookies' element={<><Header/><Cookies/></>}/>
            <Route path='/PlaceOrder' element={<><Header/><PlaceOrder/></>}/>
            <Route path='/ViewCart' element={<><Header/><ViewCart/></>}/>

           
            
          </Routes>
        </BrowserRouter>
    </div> 
  );
}
export default App;
