
//Thilagam
export function firstNameValidation(input){
    return /^[A-za-z].{3,15}$/.test(input);
  }
  //Kannan
  export function lastNameValidation(input){
    return /^[A-Za-z].{3,15}$/.test(input);
  }
  
  //thilagam@gmail.com
  export function emp_IDValidation(input){
    return /^[A-Z0-9].{0,7}$/.test(input);
  }
  
  //passowrd validation
  export function passwordValidation(input){
    return /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{5,30}$/.test(input);
  }
   //confirm passowrd validation
   export function conf_passwordValidation(input){
    return /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{5,30}$/.test(input);
  }
  export function address1Validation(input){
    return /^[A-Za-z0-9].{3,15}$/.test(input);
  }
  export function address2Validation(input){
    return /^[A-Za-z0-9].{3,15}$/.test(input);
  }
  export function phoneNoValidation(input){
    return /^[0-9].{9,12}$/.test(input);
  }
  export function altphoneNoValidation(input){
    return /^[0-9].{9,12}$/.test(input);
  }
  export function pincodeValidation(input){
    return /^[0-9].{5,10}$/.test(input);
  }
  export function cityValidation(input){
    return /^[A-Za-z].{3,15}$/.test(input);
  }
  export function stateValidation(input){
    return /^[A-Za-z].{2,15}$/.test(input);
  }



  