import {Link} from 'react-router-dom';
import bakeryicon from '../../asserts/bakeryicon.png';

function Header(){
    return(<div>
        <nav className="navbar navbar-expand-lg navbar-light navhead">      
                    <Link to="/Intro"><img src={bakeryicon} width={150} height= {100}/>   </Link>       
                    <button type="button" className="btn btn-success"><Link to="/Login">Login</Link></button>
                    <button type="button" className="btn btn-success"><Link to="/Brownie">Brownies</Link></button>
                    <button type="button" className="btn btn-success"><Link to="/Puddings">Puddings</Link></button>
                    <button type="button" className="btn btn-success"><Link to="/Cakes">Cakes</Link></button>
                    <button type="button" className="btn btn-success"><Link to="/Cookies">Cookies</Link></button>
                    <button type="button" className="btn btn-success"><Link to="/PlaceOrder">cart</Link></button>    
        </nav>  
    </div>);
}
export default Header;