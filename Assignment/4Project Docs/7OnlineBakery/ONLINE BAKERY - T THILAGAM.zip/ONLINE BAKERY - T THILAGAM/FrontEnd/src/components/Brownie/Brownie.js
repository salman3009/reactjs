import image1 from '../../asserts/brownie1.jpg';
import image2 from '../../asserts/brownie2.jpg';
import image3 from '../../asserts/brownie3.jpg';
import image4 from '../../asserts/brownie4.jpg';
import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';


function Brownie(){
    const[getForm,setForm]=useState({       
        selitem:'',
        amount:''       
      });


    const[getList,setList] =  useState([]);
    const[getIndex,setIndex]=useState(-1);
    const[getBook,setBook]=useState({       
        image:'',
        imageName:'',
        Desc:'',
        Price:''        
      });
      const [counter, setCounter] = useState(0);
      const [count, setCount] = useState(0);
      const [amount, setAmount] = useState(0);
      //increase counter
  const increase = () => {    
    setCounter(count => count + 1);
    setAmount(amount => count * getBook.Price)    
  };
 
  //decrease counter
  const decrease = () => {
    if (counter > 0) {
        setCounter(count => count - 1);
      }
  };

  const onSubmitHandler=(event)=>{
    event.preventDefault(); 
      sessionStorage.setItem("imageName",getForm.imageName);
      sessionStorage.setItem("Desc",getForm.Desc);
      sessionStorage.setItem("Price",getForm.Price); 
    }   

      const onChangeHandler=(event)=>{
        setBook({
          ...getBook,[event.target.name]:event.target.value
        })
      }
      const handleChange=(event)=>{
        setBook({
          ...getBook,[event.target.name]:event.target.value
        })
      }

       // display items details from table
     useEffect(()=>{

        axios.get('http://localhost:3000/Brownie').then((response)=>{
          console.log(response.data)
          setList(response.data);
      }).catch((error)=>{
        console.log(error);
      })     
       },[])


    return(<div>        
        <div className="seareg-bg">
            <form>
            <button type="submit"  className="btn viewcart"><Link to="/ViewCart">View Cart</Link></button>
            </form>
            <div className="container ">
                <div className="row">
                <div className="col-md-4">                    
                    <table className="thumbnail itemtable">
                    {/* <img src={{"/asserts/brownie1.jpg"}} /> */}

                    
                            {getList.map((obj,index)=>{
                            return(<tr key={index} className="itemtable">                          
                            
                            <td colSpan={3}><img src={obj.image} className="imgsize" /></td>
                            <td>{obj.imageName}</td>
                            <td>{obj.Desc}</td>
                            <td>${obj.Price}</td>
                            <td><i onClick={increase}  id={obj.id} className="fa fa-plus-circle" aria-hidden="true"/></td>
                            <td><input type="number"  onChange={onChangeHandler} className="itemaddtxt" id={obj.id} value={getForm.qnty} placeholder={counter}/></td>
                            <td><i  onClick={decrease} id={obj.id} className="fa fa-minus-circle" aria-hidden="true"/></td>
                            <td>Amount = $<input type="number" onChange={onChangeHandler} className="amounttxt" value={getForm.amount} placeholder={amount}/></td>
                            <td><button type="submit"  onClick={onSubmitHandler} className="btn addcart">Add to Cart</button></td>

                          </tr>)
                            })} 
                            
                        </table>


                {/* <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image1} className="imgsize"/>
                        <div className="caption">                        
                            <lable className="bronielable">Double Chocolate Box Brownie : $5</lable>                                                     
                        </div>
                        <div>
                        <h3><i className="fa fa-plus-circle" aria-hidden="true"/>
                        <lable className="bronielable">0 </lable> 
                        <i className="fa fa-minus-circle" aria-hidden="true"/></h3>
                        <lable className="bronielable">Amount= $ 0.0</lable>                     
                        </div>                   
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image2} className="imgsize"/>
                        <div className="caption">                            
                            <lable className="bronielable">Cosmic Brownie Mini cake : $10</lable>                            
                        </div>
                        <div>
                        <h3><i className="fa fa-plus-circle" aria-hidden="true"/>
                        <lable className="bronielable">0 </lable> 
                        <i className="fa fa-minus-circle" aria-hidden="true"/></h3>
                        <lable className="bronielable">Amount= $ 0.0</lable>                     
                        </div>                    
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image3}  className="imgsize"/>
                        <div className="caption">
                            
                            <lable className="bronielable">Chocolate Brownie cake : $9</lable>
                            
                        </div>
                        <div>
                        <h3><i className="fa fa-plus-circle" aria-hidden="true"/>
                        <lable className="bronielable">0 </lable>
                        <i className="fa fa-minus-circle" aria-hidden="true"/></h3>
                        <lable className="bronielable">Amount= $ 0.0</lable>                     
                        </div>                  
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image4} className="imgsize"/>
                        <div className="caption">
                            
                            <lable className="bronielable">Red Velvet Brownie  : $7</lable>
                            
                        </div>
                        <div>
                        <h3><i className="fa fa-plus-circle" aria-hidden="true"/>
                        <lable className="bronielable">0 </lable> 
                        <i className="fa fa-minus-circle" aria-hidden="true"/></h3>
                        <lable className="bronielable">Amount= $ 0.0</lable>                     
                        </div> 
                                        
                    </div>
                </div> */}
                </div>
                </div>
            </div>
            
        </div>

    </div>);
}
export default Brownie;