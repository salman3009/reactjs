import {Link,useNavigate} from 'react-router-dom';
import {useState} from 'react';
import {firstNameValidation,lastNameValidation,address1Validation,address2Validation,phoneNoValidation,altphoneNoValidation,stateValidation,pincodeValidation,cityValidation}  from '../Validation';

function PlaceOrder(){

    const navigate = useNavigate();
    const[getForm,setForm]=useState({
        firstName:'',
        lastName:'',
        address1:'',
        address2:'',
        phoneNo:'',
        altphoneNo:'',
        state:'',
        city:'',
        pincode:''
      });

      const[getValidation,setValidation]=useState({
        firstName:'',
        lastName:'',
        address1:'',
        address2:'',
        phoneNo:'',
        altphoneNo:'',
        state:'',
        city:'',
        pincode:''
      });
    

    const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
      }

      const onSubmitHandler=(event)=>{
        event.preventDefault(); 
        setValidation({
          ...getValidation,firstName:!firstNameValidation(getForm.firstName)?"Enter the firstName":'',
          lastName:!lastNameValidation(getForm.lastName)?"Enter the lastName":'',
          phoneNo:!phoneNoValidation(getForm.phoneNo)?"Phone no. mandatory":'',
          altphoneNo:!altphoneNoValidation(getForm.altphoneNo)?"Phone no. mandatory":'',
          address1:!address1Validation(getForm.address1)?"Enter the Address":'',
          address2:!address2Validation(getForm.address2)?"Enter the Address":'',
          city:!cityValidation(getForm.city)?"Enter the city":'',
          state:!stateValidation(getForm.state)?"Enter the state":'',
          pincode:!pincodeValidation(getForm.pincode)?"Enter the state":''
        });
        
        if(firstNameValidation(getForm.firstName) && lastNameValidation(getForm.lastName) && phoneNoValidation(getForm.phoneNo)
        && altphoneNoValidation(getForm.altphoneNo) && address1Validation(getForm.address1) && address2Validation(getForm.address2) 
        && cityValidation(getForm.city) && stateValidation(getForm.state) && pincodeValidation(getForm.pincode)){           
               alert(getForm.firstName+"Successfuly placed order");
            }
            
        }
    


    return(<div>
        <form className="form-group regform">
                  <table className="regtable">
                    <tr>
                        <td className="viewtext">First Name</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.firstName} id="firstName" name="firstName"/>
                                {getValidation.firstName && <div class="alert alert-danger" role="alert">
                                {getValidation.firstName} </div>} </div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">Last Name</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.lastName} id="lastName" name="lastName"/>
                                {getValidation.lastName && <div class="alert alert-danger" role="alert">
                                {getValidation.lastName}
                                </div> } </div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">Phone No.</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.phoneNo} id="phoneNo" name="phoneNo"/>
                                {getValidation.phoneNo && <div class="alert alert-danger" role="alert">
                                {getValidation.phoneNo}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">Alternate Phone No.</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.altphoneNo} id="altphoneNo" name="altphoneNo"/>
                                {getValidation.altphoneNo && <div class="alert alert-danger" role="alert">
                                {getValidation.altphoneNo}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">Address Line 1</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.address1} id="address1" name="address1"/>
                                {getValidation.address && <div class="alert alert-danger" role="alert">
                                {getValidation.address}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">Address Line 2</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.address2} id="address2" name="address2"/>
                                {getValidation.address && <div class="alert alert-danger" role="alert">
                                {getValidation.address}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">City</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.city} id="city" name="city"/>
                                {getValidation.city && <div class="alert alert-danger" role="alert">
                                {getValidation.city}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">Pincode</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.pincode} id="pincode" name="pincode"/>
                                {getValidation.pincode && <div class="alert alert-danger" role="alert">
                                {getValidation.pincode}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="viewtext">State</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.state} id="state" name="state"/>
                                {getValidation.state && <div class="alert alert-danger" role="alert">
                                {getValidation.state}
                                </div> }</div>
                        </td>
                    </tr>
                   
                    <tr>
                        <td className="viewtext"><input type="radio"/>Cash on delivery</td>
                        <td className="tablebutton"><button type="submit" onClick={onSubmitHandler} className="btn btn-green">Confirm</button></td>
                        
                    </tr>
                  </table> 
        </form> 

    </div>);

}
export default PlaceOrder;
