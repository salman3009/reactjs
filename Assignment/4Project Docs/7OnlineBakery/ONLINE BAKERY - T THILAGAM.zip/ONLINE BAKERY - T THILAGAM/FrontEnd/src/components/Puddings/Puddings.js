import image1 from '../../asserts/BananaPudding.jpg';
import image2 from '../../asserts/caramelpudding.jpg';
import image3 from '../../asserts/chocolatepudding.jpg';
import image4 from '../../asserts/lemonpudding.jpg';
import {Link} from 'react-router-dom';

function Puddings(){
   

    return(<div>        
         
         <div className="seareg-bg">
         <form>
            <button type="submit"  className="btn addcart"><Link to="/AddCart">Add to Cart</Link></button>
        </form>
        <div className="container">

            <div className="row">
              <div className="col-md-4">
                <div className="thumbnail">                  
                <img src={image4} className="imgsize"/>
                    <div className="caption">
                        <i className="fa fa-plus-circle" aria-hidden="true"><lable className="bronielable">Lemon Puddings : $15</lable></i>
                    </div>                  
                </div>
              </div>
              <div className="col-md-4">
                <div className="thumbnail">                  
                     <img src={image1} className="imgsize"/>
                    <div className="caption">
                        <i className="fa fa-plus-circle" aria-hidden="true"><lable className="bronielable">BananaPudding : $10</lable></i>
                    </div>                  
                </div>
              </div>
              <div className="col-md-4">
                <div className="thumbnail">                  
                    <img src={image2} className="imgsize"/>
                    <div className="caption">
                        <i className="fa fa-plus-circle" aria-hidden="true"><lable className="bronielable">Caramel Pudding : $15</lable></i>
                    </div>                  
                </div>
              </div>
              <div className="col-md-4">
                <div className="thumbnail">                  
                        <img src={image3} className="imgsize"/>
                    <div className="caption">
                        <i className="fa fa-plus-circle" aria-hidden="true"><lable className="bronielable">Chocolate Pudding : $18</lable></i>
                    </div>                  
                </div>
              </div>
            </div>
          </div>
          </div>
    </div>);
}
export default Puddings;