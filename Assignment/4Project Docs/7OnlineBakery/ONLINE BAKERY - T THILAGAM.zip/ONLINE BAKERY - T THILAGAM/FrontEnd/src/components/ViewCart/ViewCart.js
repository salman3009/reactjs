import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';


function ViewCart(){
    const [counter1, setCounter1] = useState(0);
    const [counter2, setCounter2] = useState(0);
    const [counter3, setCounter3] = useState(0);
    const [counter4, setCounter4] = useState(0);
    let [amount1, setAmount1] = useState(0);
    let [amount2, setAmount2] = useState(0);
    let [amount3, setAmount3] = useState(0);
    let [amount4, setAmount4] = useState(0);

   
    const[getForm,setForm]=useState({       
        image:'',
        imageName:'',
        Desc:'',
        Price:''  ,
        quantity1:''     
      });
      useEffect(()=>{     
        let q1 = sessionStorage.getItem('quantity1');
        let amt1 = sessionStorage.getItem('amount1'); 
        let q2 = sessionStorage.getItem('quantity2');
        let amt2 = sessionStorage.getItem('amount2'); 
        let q3 = sessionStorage.getItem('quantity3');
        let amt3 = sessionStorage.getItem('amount3'); 
        let q4 = sessionStorage.getItem('quantity4');
        let amt4 = sessionStorage.getItem('amount4'); 
        if(q1 > 0 )
        {
        setCounter1(q1);   
        setAmount1(amt1);  
        }   
        if(q2 > 0 )
        {
        setCounter2(q2);   
        setAmount2(amt2);  
        }
        if(q3 > 0 )
        {
        setCounter3(q3);   
        setAmount3(amt3);  
        }
        if(q4 > 0 )
        {
        setCounter4(q4);   
        setAmount4(amt4);  
        }
    },[])     


       const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
      }


    return(<div>
        <div className="seareg-bg">        
        <div className="container ">
            <div className="row">
            <div className="col-md-4"> 
             <table className="itemtable">
                <tr>
                    <td>  <lable className="bronielable" id="Double Chocolate Box Brownie" >Double Chocolate Box Brownie : $5</lable></td>
                    <td>  <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={counter1} placeholder={counter1}/></td>
                    <td> <input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount1} placehoder={amount1}/> </td>                   
                </tr>
                <tr>
                    <td> <lable className="bronielable">Cosmic Brownie Mini cake : $10</lable>   </td>
                    <td>  <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={counter2} placeholder={counter2}/></td>
                    <td> <input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount2} placehoder={amount2}/> </td>                   
                </tr>         
                <tr>
                    <td>  <lable className="bronielable">Chocolate Brownie cake : $9</lable></td>
                    <td>  <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={counter3} placeholder={counter3}/></td>
                    <td> <input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount3} placehoder={amount3}/> </td>                   
                </tr>
                <tr>
                    <td>  <lable className="bronielable">Red Velvet Brownie  : $7</lable></td>
                    <td>  <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={counter4} placeholder={counter4}/></td>
                    <td> <input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount4} placehoder={amount4}/> </td>                   
                </tr>
                <tr>
                    <td><button type="submit"  className="btn addcart"><Link to="/PlaceOrder">Place Order</Link></button></td>
                </tr>  
             </table>
            </div>
        </div>
        </div>
        </div>
    </div>);
}
export default ViewCart;