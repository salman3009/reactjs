import image1 from '../../asserts/cookies1.jpg';
import image2 from '../../asserts/cookies2.jpg';
import image3 from '../../asserts/cookies3.jpg';
import image4 from '../../asserts/cookies4.jpg';
import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';


function Cookies(){

const [counter1, setCounter1] = useState(0);
const [counter2, setCounter2] = useState(0);
const [counter3, setCounter3] = useState(0);
const [counter4, setCounter4] = useState(0);
let [amount1, setAmount1] = useState(0);
let [amount2, setAmount2] = useState(0);
let [amount3, setAmount3] = useState(0);
let [amount4, setAmount4] = useState(0);


const[getList,setList] =  useState([]);    
const[getForm,setForm]=useState({       
        image:'',
        imageName:'',
        Desc:'',
        Price:''        
      });
        // increase counter
let amountCalc1 = () => {  
  //let q4=sessionStorage.getItem('counter4');  
  let amt = parseInt(counter1 * 5);
  amount1 = parseInt(amt);
  setAmount1(amount1);
  console.log(amount1);   
  sessionStorage.setItem("amount1",amount1); 
};
       
  let amountCalc2 = () => {           
    let amt = parseInt(counter2 * 10);
    amount2 = parseInt(amt);
    setAmount2(amount2);
    console.log(amount2);   
    sessionStorage.setItem("amount2",amount2); 
  };
             
let amountCalc3 = () => {    
  
  let amt = parseInt(counter3 * 9);
  amount3 = parseInt(amt);
  setAmount3(amount3);
  console.log(amount3);   
  sessionStorage.setItem("amount3",amount3); 
};
      
let amountCalc4 = () => {  
  //let q4=sessionStorage.getItem('counter4');
  
  let amt = parseInt(counter4 * 7);
  amount4 = parseInt(amt);
  setAmount4(amount4);
  console.log(amount4);   
  sessionStorage.setItem("amount4",amount4); 
};
      

    //increase counter
const increase1 = () => {       
    setCounter1(count => count + 1);          
  };
  const increase2 = () => {    
    setCounter2(count => count + 1);    
  };
  const increase3 = () => {    
    setCounter3(count => count + 1);    
  };
  const increase4 = () => {    
    setCounter4(count => count + 1);  
     
  };
 
  //decrease counter
  const decrease1 = () => {
    if (counter1 > 0) {
        setCounter1(count => count - 1);
      }
  };
  const decrease2 = () => {
    if (counter2 > 0) {
        setCounter2(count => count - 1);
      }
  };
  const decrease3 = () => {
    if (counter3 > 0) {
        setCounter3(count => count - 1);
      }
  };
  const decrease4 = () => {
    if (counter4 > 0) {
        setCounter4(count => count - 1);
      }
  };
   
  const onChangeHandler=(event)=>{
    setForm({
      ...getForm,[event.target.name]:event.target.value
    })
  }
  // display items details from table
useEffect(()=>{
    axios.get('http://localhost:3000/Brownie').then((response)=>{
      console.log(response.data)
      setList(response.data);
  }).catch((error)=>{
    console.log(error);
  })
   },[])


  const onSubmitHandler=(event)=>{
    event.preventDefault();  
        let name=getForm.imageName;
        console.log(name);
            
      sessionStorage.setItem("imageName",name);
      sessionStorage.setItem("Desc",getForm.Desc);
      sessionStorage.setItem("Price",getForm.Price);
      sessionStorage.setItem("quantity1",counter1);
      sessionStorage.setItem("quantity2",counter2);
      sessionStorage.setItem("quantity3",counter3);
      sessionStorage.setItem("quantity4",counter4); 
}


return(<div>        
        <div className="seareg-bg">
            <form>
           <div> <button type="submit" onClick={onSubmitHandler} className="btn addcart">Add to Cart</button>
            <button type="submit"  className="btn addcart"><Link to="/ViewCart">View Cart</Link></button></div>
            </form>
            <div className="container ">
                <div className="row">    
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image1} className="imgsize"/>
                        <div className="caption">                        
                            <lable className="bronielable" id="Double Chocolate Box Brownie" >Christmas five types cookies : $15</lable>                                                     
                        </div>
                        <div>
                        <h3><i onClick={() => {increase1(); amountCalc1()}} className="fa fa-plus-circle" aria-hidden="true"/>
                        <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={getForm.quantity1} placeholder={counter1}/> 
                        <i  onClick={() =>{decrease1(); amountCalc1()}} className="fa fa-minus-circle" aria-hidden="true"/></h3></div>
                        Amount:<input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount1} placehoder={amount1}/>
                     </div>                   
                    </div>
               
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image2} className="imgsize"/>
                        <div className="caption">                            
                            <lable className="bronielable">Cashew milky cookies : $10</lable>                            
                        </div>
                        <div>
                        <h3><i onClick={() => {increase2(); amountCalc2()}} className="fa fa-plus-circle" aria-hidden="true"/>
                        <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={getForm.quantity2} placeholder={counter2}/> 
                        <i  onClick={() =>{decrease2(); amountCalc2()}} className="fa fa-minus-circle" aria-hidden="true"/></h3></div> 
                        Amount:<input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount2} placehoder={amount2}/>                 
                                            
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image3}  className="imgsize"/>
                        <div className="caption">
                            
                            <lable className="bronielable">Choco Filles cookies : $9</lable>
                            
                        </div>
                        <div>
                        <h3><i onClick={() => {increase3(); amountCalc3()}} className="fa fa-plus-circle" aria-hidden="true"/>
                        <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={getForm.qnty3} placeholder={counter3}/> 
                        <i  onClick={() =>{decrease3(); amountCalc3()}} className="fa fa-minus-circle" aria-hidden="true"/></h3>
                        Amount:<input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount3} placehoder={amount3}/>
                                            
                        </div>                   
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="thumbnail">                  
                        <img src={image4} className="imgsize"/>
                        <div className="caption">                            
                            <lable className="bronielable">Crispy shaped cookies  : $7</lable>                            
                        </div>
                        <div>
                        <h3><i  onClick={() => {increase4(); amountCalc4()}} className="fa fa-plus-circle" aria-hidden="true"/>
                        <input type="number"  onChange={onChangeHandler} className="itemaddtxt"  value={getForm.qnty4} placeholder={counter4}/> 
                        <i  onClick={() => {decrease4(); amountCalc4()}} className="fa fa-minus-circle" aria-hidden="true"/></h3>  

                        Amount:<input type="number" onChange={onChangeHandler}  className="itemaddtxt" value={amount4} placehoder={amount4}/></div>                     
                        </div>                                          
                    </div>
                    </div>
                </div>
                </div>

    </div>);
}
export default Cookies;