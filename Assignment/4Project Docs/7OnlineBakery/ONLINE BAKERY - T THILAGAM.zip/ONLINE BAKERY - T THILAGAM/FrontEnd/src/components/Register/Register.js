import {Link,useNavigate} from 'react-router-dom';
import {useState} from 'react';
import {firstNameValidation,lastNameValidation,emp_IDValidation,passwordValidation,conf_passwordValidation}  from '../Validation';

function Register(){

    const navigate = useNavigate();
    const[getForm,setForm]=useState({
        firstName:'',
        lastName:'',
        emp_ID:'',
        password:'',
        conf_password:''
      });

      const[getValidation,setValidation]=useState({
        firstName:'',
        lastName:'',
        emp_ID:'',
        password:'',
        conf_password:''
      });
    

    const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
      }

      const onSubmitHandler=(event)=>{
        event.preventDefault(); 
        setValidation({
          ...getValidation,firstName:!firstNameValidation(getForm.firstName)?"Please provide the firstName":'',
          lastName:!lastNameValidation(getForm.lastName)?"Please provide the lastName":'',
          emp_ID:!emp_IDValidation(getForm.emp_ID)?"please provide emp_ID":'',
          password:!passwordValidation(getForm.password)?"Please provide the password":'',
          conf_password:!conf_passwordValidation(getForm.conf_password)?"Please provide the password":''
          
        });
        
        if(emp_IDValidation(getForm.emp_ID) && passwordValidation(getForm.password) && conf_passwordValidation(getForm.conf_password) &&
        firstNameValidation(getForm.firstName) && lastNameValidation(getForm.lastName)){
            if(getForm.password===getForm.conf_password){
                alert(getForm.emp_ID+getForm.password+"successully regisred");
          sessionStorage.setItem("firstName",getForm.firstName);
          sessionStorage.setItem("lastName",getForm.lastName);
          sessionStorage.setItem("emp_ID",getForm.emp_ID);
          sessionStorage.setItem("password",getForm.password);
          sessionStorage.setItem("conf_password",getForm.conf_password);
          navigate('/Login');
            }
            else{
                alert("Password Not matched");
            }
        }
    }




    return(<div>
        <form className="form-group regform">
                  <table className="regtable">
                    <tr>
                        <td className="tabletext">First Name</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.firstName} id="firstName" name="firstName"/>
                                {getValidation.firstName && <div class="alert alert-danger" role="alert">
                                {getValidation.firstName} </div>} </div>
                        </td>
                    </tr>
                    <tr>
                        <td className="tabletext">Last Name</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.lastName} id="lastName" name="lastName"/>
                                {getValidation.lastName && <div class="alert alert-danger" role="alert">
                                {getValidation.lastName}
                                </div> } </div>
                        </td>
                    </tr>
                    <tr>
                        <td className="tabletext">Employee ID</td>
                        <td><div className="form-group"><input type="text" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.emp_ID} id="emp_ID" name="emp_ID"/>
                                {getValidation.emp_ID && <div class="alert alert-danger" role="alert">
                                {getValidation.emp_ID}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="tabletext">Password</td>
                        <td><div className="form-group"><input type="password" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.password} id="password" name="password"/>
                                {getValidation.password && <div class="alert alert-danger" role="alert">
                                {getValidation.password}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="tabletext">Confirm Password</td>
                        <td><div className="form-group"><input type="password" onChange={onChangeHandler} className="form-control regtext-bg" value={getForm.conf_password} id="conf_password" name="conf_password"/>
                                {getValidation.conf_password && <div class="alert alert-danger" role="alert">
                                {getValidation.conf_password}
                                </div> }</div>
                        </td>
                    </tr>
                    <tr>
                        <td className="tablebutton"><button type="submit" onClick={onSubmitHandler} className="btn btn-green">Confirm</button></td>
                        <td ><button type="submit"  className="btn btn-green">Cancel</button></td>
                    </tr>
                  </table> 
        </form> 

    </div>);

}
export default Register;