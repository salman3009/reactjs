import image1 from '../../asserts/brownie1.jpg';
import image2 from '../../asserts/brownie2.jpg';
import image3 from '../../asserts/brownie3.jpg';
import image4 from '../../asserts/brownie4.jpg';
import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';


function SearchItems(){
  const[getList,setList] =  useState([]);
  const[getIndex,setIndex]=useState(-1);
  const[getItem,setItem]=useState({       
      image:'',
      imageName:'',
      Desc:'',
      Price:''        
    });

  const[getForm,setForm]=useState({       
    selitem:'',
    amount:''       
  });

  const onChangeHandler=(event)=>{
    setItem({
      ...getItem,[event.target.name]:event.target.value
    })
  }



// display items details from table
useEffect(()=>{

  axios.get('http://localhost:3000/Brownie').then((response)=>{
    console.log(response.data)
    setList(response.data);
}).catch((error)=>{
  console.log(error);
})
//         if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
//            setList(JSON.parse(sessionStorage.getItem('bookDetails')))
//         }
 },[])

 //delete item from table when delete icon clicked
 const onDeleteHandler=(index)=>{
  let itemDetails = [...getList];
  let id = itemDetails[index].id;
  axios.delete('http://localhost:3000/Brownie/'+id).then((response)=>{
    itemDetails.splice(index,1);
   setList(itemDetails);
  }).catch(()=>{
  })
}
 // sessionStorage.setItem('expenseDetails',JSON.stringify(expenseDetails));

  //Modal dialog field edit submit
  const onEditSubmitHandler=(event)=>{
    event.preventDefault();
    let itemDetails =[...getList];
    let id=itemDetails[getIndex].id;
    axios.patch('http://localhost:3000/library/'+id,{

      imageName:getItem.imageName,
      Desc:getItem.Desc,
      Price:getItem.Price

    }).then(()=>{
      setList(itemDetails);
      itemDetails[getIndex].imageName = getItem.imageName;      
      itemDetails[getIndex].Desc = getItem.Desc;
      itemDetails[getIndex].Price= getItem.Price;      
    }).catch(()=>{

    })
  }

          //edit table item
          const onEditHandler=(index)=>{
            setItem({
              imageName:getList[index].imageName,
              Desc:getList[index].Desc,
              Price:getList[index].Price,                    
            })
            setIndex(index);
           }

           






    return(<div>
        <div className="seareg-bg">
        <div className="container ">
          <div className="add-new-item">
                  <Link to="/AddImages"><h1><i class="fa fa-paperclip" aria-hidden="true">Add New Item</i></h1></Link>
          </div>
            <div className="row">
            <div className="col-md-4"> 

                  <table className="thumbnail itemtable">
                    {/* <img src={{"/asserts/brownie1.jpg"}} /> */}

                    
                            {getList.map((obj,index)=>{
                            return(<tr key={index} className="itemtable">                          
                            
                            <td colSpan={3}><img src={obj.image} className="imgsize" /></td>
                            <td>{obj.imageName}</td>
                            <td>{obj.Desc}</td>
                            <td>${obj.Price}</td>
                            <td><i onClick={()=>onEditHandler(index)}  data-toggle="modal" data-target="#edit"  class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td> <i  onClick={()=>onDeleteHandler(index)} className="fa fa-trash" aria-hidden="true"></i></td>
                            

                          </tr>)
                            })} 
                            
                        </table>
                        </div>
                
              </div>
              
          </div>
          </div>




              {/* <div className="col-md-4">
                <div className="thumbnail">                  
                    <img src={image1} className="imgsize"/>
                    <div className="caption">
                        <h3><lable className="bronielable">Double Chocolate Box Brownie : $5</lable>
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                        <i  className="fa fa-trash" aria-hidden="true"></i></h3>
                    
                    </div>                                      
                </div>
              </div>
              <div className="col-md-4">
                <div className="thumbnail">                  
                    <img src={image2} className="imgsize"/>
                    <div className="caption">
                        <h3>
                        <lable className="bronielable">Cosmic Brownie Mini cake : $10</lable> 
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                        <i  className="fa fa-trash" aria-hidden="true"></i>
                        </h3>                       
                    </div>                                      
                </div>
              </div>
              <div className="col-md-4">
                <div className="thumbnail">                  
                    <img src={image3}  className="imgsize"/>
                    <div className="caption">
                        <h3>
                        <lable className="bronielable">Chocolate Brownie cake : $9</lable> 
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                        <i  className="fa fa-trash" aria-hidden="true"></i>
                        </h3>                       
                    </div>                                      
                </div>
              </div>
              <div className="col-md-4">
                <div className="thumbnail">                  
                    <img src={image4} className="imgsize"/>
                    <div className="caption">
                        <h3>
                        <lable className="bronielable">Red Velvet Brownie  : $7</lable>
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                        <i  className="fa fa-trash" aria-hidden="true"></i>
                        </h3>
                    </div>              
                </div>
              </div>
              <div className="col-md-4"></div> */}
    <div className="modal fade" id="edit"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div className="modal-dialog" role="document">
          <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLabel">Modal title</h5>
                  <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                <form>
                      <div className="form-group">
                          <label>Image Name</label>
                          <input type="text"  value={getItem.imageName} onChange={onChangeHandler} name="imageName" className="form-control" id="imageName"  placeholder="Enter Image name"/>
                        </div>
                        <div className="form-group">
                          <label>Description</label>
                          <input  type="text" value={getItem.Desc} onChange={onChangeHandler}  name="desc" className="form-control" id="desc" placeholder="Enter Description"/>
                        </div>
                        
                      <div className="form-group">
                        <label>Price</label>
                        <input type="number" value={getItem.Price} onChange={onChangeHandler}  name="price" className="form-control" id="price" placeholder="Enter Price"/>
                      
                      </div>
                      
                  
                      <button data-dismiss="modal"  onClick={onEditSubmitHandler} type="submit" className="btn btn-success">ADD</button>
                    </form>
        </div>
       
      </div>
    </div>
  </div>
              

    </div>);
}
export default SearchItems;