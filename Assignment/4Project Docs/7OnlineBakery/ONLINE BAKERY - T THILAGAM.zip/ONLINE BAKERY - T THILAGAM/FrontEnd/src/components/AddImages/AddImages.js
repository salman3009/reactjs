import {Link,useNavigate} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';


function AddImages(){

    const navigate = useNavigate();
    const[getBook,setBook]=useState({       
        image:'',
        imageName:'',
        Desc:'',
        Price:''        
      });

      const onChangeHandler=(event)=>{
        setBook({
          ...getBook,[event.target.name]:event.target.value
        })
      }

      const onAddHandler=(event)=>{
        event.preventDefault();
        axios.post('http://localhost:3000/Brownie',{
            image:getBook.image,  
            imageName:getBook.imageName,
            Desc:getBook.Desc,
            Price:getBook.Price,
           
          }).then(()=>{
            navigate('/SearchItems');
          }).catch(()=>{
             alert("error");
          })
        }

  




    return(<div>
        <form className="seareg-bg">
        <div className="form-group">
            <div className="container addimage">
                <div > 
                               
                    <span><h3><i className="fa fa-upload"><input type="file" onChange={onChangeHandler} value={getBook.image} id="image" name="image"/> </i></h3></span>
                </div>
                  <div>
                      <input type="text"  className="form-control desctext" onChange={onChangeHandler} value={getBook.imageName} id="imageName" name="imageName"/>
                  </div>
                
                    <div><input type="text"  className="form-control desctext" onChange={onChangeHandler} value={getBook.Desc} id="Desc" name="Desc" placeholder="Add Description"/></div>
                    <div className="input-group">
                        <label  className="qutytext" style={{width: 300}}>Price :</label>
                        <input type="number"  className="qutytext" onChange={onChangeHandler} value={getBook.Price} id="Price" name="Price" placeholder="Add Price"/>                       
                        
                    </div>
                    <div className="Additembtn"><button className="btn btn-green" onClick={onAddHandler} type="button" id="AddItems">OK</button> </div>
                </div>
            </div>
      </form>

    </div>);
}
export default AddImages;