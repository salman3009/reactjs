import {Link} from 'react-router-dom';
function intro(){
    return(<div>
        <div className="introbg">
            <div className="container">
                <div>               
                    <h1 className="headtext1">Welcome To Online Bakery</h1>                    
                    <Link to="/Brownie">Click here for Orders...</Link>                  
                </div>               
                <div><p className="banner">50% Discount!!!! Hurry up... Limited Orders.....</p></div>
                </div>
        </div>    

        </div>);
}
export default intro;