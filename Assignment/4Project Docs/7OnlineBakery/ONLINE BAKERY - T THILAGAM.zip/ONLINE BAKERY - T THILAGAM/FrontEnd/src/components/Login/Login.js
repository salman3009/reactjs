import {Link,useNavigate} from 'react-router-dom';
import {useState} from 'react';
import {emp_IDValidation,passwordValidation}  from '../Validation';

function Login(){
    const navigate = useNavigate();

    const[getForm,setForm]=useState({       
        emp_ID:'',
        password:''       
      });

      const[getValidation,setValidation]=useState({        
        emp_ID:'',
        password:''        
      });
      const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
      }

      const onSubmitHandler=(event)=>{
        event.preventDefault();
        setValidation({
            ...getValidation,emp_ID:!emp_IDValidation(getForm.emp_ID)?"Required":'',
        password:!passwordValidation(getForm.password)?"Required":''
        });
        if(emp_IDValidation(getForm.emp_ID) && passwordValidation(getForm.password)){
            
            let emp_ID = sessionStorage.getItem('emp_ID');
            let password = sessionStorage.getItem('password');
            if(emp_ID === getForm.emp_ID && password === getForm.password){                
              navigate('/SearchItems');
            }            
            else{
              setValidation({
                emp_ID:'Please enter valid Employee ID',
                password:'Password Not Matched'
              });
            }        
          }  
    }
    return(<div>
        <form className="logform">
                  <table className="logtable">
                    <tr>
                        <td className="logtabletext">Employee ID :</td>
                        <td><input type="text" onChange={onChangeHandler} value={getForm.emp_ID} class="form-control logtext-bg" id="emp_ID" name="emp_ID"/>
                                {getValidation.emp_ID && <div class="alert alert-danger" role="alert">
                                {getValidation.emp_ID}
                                </div> }
                        </td>
                    </tr>                   
                    <tr>
                        <td className="logtabletext">Password : </td>
                        <td><input type="password" onChange={onChangeHandler} value={getForm.password} class="form-control logtext-bg" id="password" name="password" />
                                {getValidation.password && <div class="alert alert-danger" role="alert">
                                {getValidation.password}</div> }
                                </td>
                    </tr>                    
                    <tr>
                        <td className="logtablebutton"> <button onClick={onSubmitHandler} type="submit" class="btn btn-green">Login</button></td>
                        <td ><Link to="/Register"><button  type="submit" class="btn btn-green">Sign Up</button></Link></td>
                    </tr>
                  </table> 
        </form>

        </div>
        );  
}
export default Login;