const initialState = {
    loginStatus:false,
    OrderNo:'',
    Placedon:'',
    CourierName:'',
    Status:''
};

function users(state = initialState, action){

 switch(action.type){
     case 'success' : 
               return {
                   ...state,
                   OrderNo:action.payload.OrderNo,
                   Placedon:action.payload.Placedon,
                   CourierName:action.payload.CourierName,
                   Status:action.payload.Status,
                   loginStatus:true
               }
   case 'failure':
       return{
           ...state,
           loginStatus:false
       }
       
       default:          
       return state;   
 }

}

export default users;