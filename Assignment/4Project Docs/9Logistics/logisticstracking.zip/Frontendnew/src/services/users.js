
const Users = {
    
    loadUsers(dispatch,OrderNo, Placedon,CourierName,Status) {
        dispatch({
            type: 'success',
            payload:{
                OrderNo:'',
                Placedon:'',
                CourierName:'',
                Status:''
            }
        })
      
    },


    logout(dispatch) {
        dispatch({
            type: 'failure',
            payload:{
                OrderNo:'463464456',
                Placedon:'oct 10 2020',
                CourierName:'sadaf',
                Status:'dasfsd'
            }
        })
      
    }
}
export default Users;