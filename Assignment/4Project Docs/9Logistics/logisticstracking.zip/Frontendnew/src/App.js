import './App.css';
import './assests/font-awesome/css/font-awesome.min.css';
import Header from './components/Header/Header';
import Homescreen from './components/Homescreen/Homescreen';
import Adminsignup from './components/Adminsignup/Adminsignup';
import Userlogin from './components/Userlogin/Userlogin';
import Adminlogin from './components/Adminlogin/Adminlogin';
import Orderform from './components/Orderform/Orderform';
import Customertracking from './components/Customertracking/Customertracking';
import Searchlogistics from './components/Searchlogistics/Searchlogistics';
import Addentry from './components/Addentry/Addentry';
import Customertrackingnew from './components/Customertrackingnew/Customertrackingnew';

import {BrowserRouter,Routes, Route} from 'react-router-dom';


function App() {
  return (<div> 
    <BrowserRouter>        
    <Routes>         
    <Route path='/' element={<><Header/><Homescreen/></>} /> 
    <Route path='/adminsignup' element={<Adminsignup/>} />
    <Route path='/userlogin' element={<Userlogin/>} />
    <Route path='/adminlogin' element={<Adminlogin/>} />
    <Route path='/orderform' element={<Orderform/>} /> 
    <Route path='/customertracking' element={<Customertracking/>} /> 
    <Route path='/searchlogistics' element={<Searchlogistics/>} /> 
    <Route path='/addentry' element={<Addentry/>} /> 
    <Route path='/customertrackingnew' element={<Customertrackingnew/>} /> 
    <Route path='/homescreen' element={<><Header/><Homescreen/></>} /> 
         

    </Routes>   
    </BrowserRouter>
        
    </div>
  )
}

export default App;
