import './Orderform.css';
import {Link,useNavigate} from 'react-router-dom'; 
import { useEffect,useState } from 'react';
import axios from 'axios';
import {useDispatch } from 'react-redux';
import Users from '../../services/users';
import {OrderNoValidation,PlacedonValidation,CourierNameValidation, StatusValidation}  from '../Validation';

function Orderform(){
    const[getList,setList] = useState([]);
    const[getSearch,setSearch]=useState('');
    const[getIndex,setIndex]=useState(-1);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const[getForm,setForm]=useState({
        OrderNo:'',
        Placedon:'',
        CourierName:'',
        Status:''
      });

    const[getValidation,setValidation]=useState({
      OrderNo:'',
      Placedon:'',
      CourierName:'',
      Status:''
      });
    const onChangeSearchHandler=(event)=>{
        setSearch(event.target.value);
      }

    const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
    }
     //Modal dialog field edit submit
     const onEditSubmitHandler=(event)=>{
        event.preventDefault();
        let logisticsDetails =[...getList];
        let id= logisticsDetails[getIndex].id;
        axios.patch('http://localhost:3000/logistics/'+id,{
            OrderNo:getForm.OrderNo,
            Placedon:getForm.Placedon,
            CourierName:getForm.CourierName,
            Status:getForm.Status

            }).then(()=>{
          setList(logisticsDetails);
          logisticsDetails[getIndex].OrderNo = getForm.OrderNo;
          logisticsDetails[getIndex].Placedon=getForm.Placedon;
          logisticsDetails[getIndex].CourierName = getForm.CourierName;
          logisticsDetails[getIndex].Status= getForm.Status;
          
        }).catch(()=>{
        })
  
      }
      
      
      // Add  details into table
    useEffect(()=>{
        axios.get('http://localhost:3000/logistics').then((response)=>{
          console.log(response.data)
          setList(response.data);
      }).catch((error)=>{
        console.log(error);
      })
      //         if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
      //            setList(JSON.parse(sessionStorage.getItem('bookDetails')))
      //         }
       },[])

       //delete item from table when delete icon clicked
     const onDeleteHandler=(index)=>{
        let logisticsDetails = [...getList];
        let id = logisticsDetails[index].id;
        axios.delete('http://localhost:3000/logistics/'+id).then((response)=>{
            logisticsDetails.splice(index,1);
         setList(logisticsDetails);
        }).catch(()=>{
        })
       // sessionStorage.setItem('expenseDetails',JSON.stringify(expenseDetails));
      }
  
      //edit table item
      const onEditHandler=(index)=>{
        setForm({
            OrderNo:getList[index].OrderNo,
            Placedon:getList[index].Placedon,
            CourierName:getList[index].CourierName,
            Status:getList[index].Status
                
        })
        setIndex(index);
       }
      //search data in the table
   const searchFilter=(event)=>{
    event.preventDefault();
    let details = getList.filter((obj)=>{
      return obj.OrderNo === getSearch; 
    })
    setList(details);
  }

   //reset search field
  const resetFilter=(event)=>{
      event.preventDefault();
      setSearch('');
      axios.get('http://localhost:3000/logistics').then((response)=>{
          console.log(response.data)
          setList(response.data);
      }).catch((error)=>{
        console.log(error);
      })
    //   if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
    //     setList(JSON.parse(sessionStorage.getItem('bookDetails')))
     }

     const onSubmitHandler=(event)=>{
      event.preventDefault(); 
      setValidation({
        ...getValidation,OrderNo:!OrderNoValidation(getForm.OrderNo)?"please provide Correct Order No":'',
        Placedon:!PlacedonValidation(getForm.Placedon)?"Please provide correct Placedon":'',
        CourierName:!CourierNameValidation(getForm.CourierName)?"Please provide CourierName":'',
        Status:!StatusValidation(getForm.Status)?"Please provide correct Status":'',
      });
      if(OrderNoValidation(getForm.OrderNo) && PlacedonValidation(getForm.Placedon) && CourierNameValidation(getForm.CourierName) && 
      StatusValidation(getForm.Status)){
        alert("success");
        let OrderNo = sessionStorage.getItem('OrderNo');
        let Placedon = sessionStorage.getItem('Placedon ');
        let CourierName= sessionStorage.getItem('CourierName');
        let Status = sessionStorage.getItem(' Status ');
        if(OrderNo=== getForm.OrderNo && Placedon === getForm.Placedon && CourierName=== getForm.CourierName
          && Status=== getForm.Status){
          Users.loadUsers(dispatch,OrderNo,Placedon,CourierName,Status);
          navigate('/homescreen');
        }
        else{
          setValidation({
            OrderNo:'no match found',
            Placedon:'no match found',
            CourierName:'no match found',
            Status:'no match found'
          });
        }
    
      }
  }
    return(<div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <div className="orderformheading"> Capital Logistics</div>  
            <form className="form-inline my-2 my-lg-0">
                <div>
                 <p>Welcome Sherkan</p>   
                 </div>           
                <div className="orderformicon">   
                    <tr>
                        <a className="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a> 
                    </tr>
                </div>
        </form>
        </nav>

        <form className="orderform">
             <div className="container-fluid">
                  <div className="row">
                      <div className="col-12">
                         <form>       
                             <div className="form-group row">
                                <table className="table">
                                  <thead className="tablenew">
                                  <tr>
                                  <th scope="col">Order No</th>
                                  <th scope="col">Placed on</th>
                                  <th scope="col">Courier Name</th>
                                  <th scope="col">Status</th>
                                  <th scope="col">Edit</th>
                                  <th scope="col">Delete</th>

                                  </tr>
                                  </thead>
                                  <tbody>
                            {getList.map((obj,index)=>{
                            return(<tr key={index}>                          
                            <td>{obj.OrderNo}</td>
                            <td>{obj.Placedon}</td>
                            <td>{obj.CourierName}</td>
                            <td>{obj.Status}</td>
                            <td><i  onClick={()=>onEditHandler(index)} data-toggle="modal" data-target="#edit" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i  onClick={()=>onDeleteHandler(index)} className="fa fa-trash" aria-hidden="true"></i></td>
                            </tr>)
                            })}  

        
        <div className="modal fade" id="edit"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLabel">Modal title</h5>
                  <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                <form>
                      <div className="form-group">
                          <label>Order No:</label>
                          <input type="text"  value={getForm.OrderNo}  onChange={onChangeHandler} name="OrderNo" className="form-control" id="OrderNo"  placeholder="Enter Order No"/>
                          {getValidation.OrderNo && <div class="alert alert-danger" role="alert">
                        {getValidation.OrderNo}
                        </div> }
                        </div>
                        <div className="form-group">
                          <label>Placed on</label>
                          <input  value={getForm.Placedon} onChange={onChangeHandler} type="text" name="Placedon" className="form-control" id="Placedon"  placeholder="Enter Placedon Date"/>
                          {getValidation.Placedon && <div class="alert alert-danger" role="alert">
                        {getValidation.Placedon}
                        </div> }
                        </div>
                        
                      <div className="form-group">
                        <label>Courier Name</label>
                        <input value={getForm.CourierName} onChange={onChangeHandler} type="text" name="CourierName" className="form-control" id="CourierName" placeholder="Enter CourierName"/>
                        {getValidation.CourierName && <div class="alert alert-danger" role="alert">
                        {getValidation.CourierName}
                        </div> }
                      </div>
                      <div className="form-group">
                        <label>Status:</label>
                        <input value={getForm.Status} onChange={onChangeHandler} type="text"  name="Status" className="form-control" id="Status" placeholder="Enter Status"/>
                        {getValidation.Status && <div class="alert alert-danger" role="alert">
                        {getValidation.Status}
                        </div> }
                      </div>
                                        
                      <button data-dismiss="modal" onClick={onEditSubmitHandler} type="submit" className="btn btn-success">ADD</button>
                    
                      <button type="submit" onClick={onSubmitHandler} className="btn btn-warning logbutton1">Logout</button>
                    </form>
        </div>
       
      </div>
    </div>
  </div> 

                                  
                                     
                    <tr>
                        <td ><button type="submit" className="btn btn-darkblue" ><Link to="/addentry">Add New Entry</Link><br/></button><br/></td>

                        <td ><button type="submit" className="btn btn-darkblue" ><Link to="/homescreen">Submit</Link></button></td>
                   </tr>
                               </tbody>
                               </table>
                            </div>
                         </form>
      
                    </div>            
                </div>

             </div>
        </form>


    </div>)
}
    export default Orderform;
