import './Addentry.css';
import {Link,useNavigate} from 'react-router-dom';
import {useState} from 'react';
import {OrderNoValidation,PlacedonValidation,CourierNameValidation,StatusValidation}  from '../Validation';
import axios from 'axios';
function Addentry(){

  const[getForm,setForm]=useState({
    OrderNo:'',
    Placedon:'',
    CourierName:'',
    Status:''
  });

  const[getValidation,setValidation]=useState({
    OrderNo:'',
    Placedon:'',
    CourierName:'',
    Status:''
  });

  const navigate = useNavigate();


  const onChangeHandler=(event)=>{
    setForm({
      ...getForm,[event.target.name]:event.target.value
    })
  }
  
  const onAddHandler=(event)=>{
  event.preventDefault();
  // setValidation({
  //     ...getValidation,OrderNo:!OrderNoValidation(getForm.OrderNo)?"please provide OrderNo":'',
  //     // Placedon:!PlacedonValidation(getForm.Placedon)?"Please provide Placedon":'',
  //     CourierName:!CourierNameValidation(getForm.CourierName)?"Please provide CourierName":'',
  //     Status:!StatusValidation(getForm.Status)?"Please provide Status":'',
  //         });
    if(getForm.OrderNo && getForm.Placedon && getForm.CourierName && getForm.Status){
      axios.post('http://localhost:3000/logistics',{
        OrderNo:getForm.OrderNo,  
        Placedon:getForm.Placedon,
        CourierName :getForm.CourierName,
        Status:getForm.Status
            
        }).then(()=>{
            navigate('/Orderform');
          }).catch(()=>{
             alert("error");
          })     
    
    }
    else{
      alert("Please add some data");
    }
  }


    return(<div>
        
        <div className="container">
            <div className="row">
            
              <div className="col-12">
                  <form>       
                    <div><label><h1>Add Order Details</h1></label></div> 
                   
                    <div className="form-group row">   
                    <table className="addbook_table">
                      <tbody>
                      <tr>
                        <td><label >Order No:</label></td>
                        <td><input type="text" onChange={onChangeHandler} className="form-control" value={getForm.OrderNo} id="OrderNo" name="OrderNo"/></td>
                      </tr>
                      <tr>
                        <td><label >Placed On:</label>  </td>
                        <td><input type="text" onChange={onChangeHandler} className="form-control " value={getForm.Placedon} id="Placedon" name="Placedon" /></td>
                      </tr>
                      <tr>                       
                        <td><label >Courier Name:</label></td>
                        <td><input type="text" onChange={onChangeHandler} className="form-control" value={getForm.CourierName} id="CourierName" name="CourierName" /></td>
                      </tr>
                      <tr>
                        <td><label >Status:</label> </td>
                        {/* <td>
                        <select>
                        <option>Delivered</option>
                        <option selected>Shipped</option>
                        <option>Order placed</option>
                        <option>Returned</option>
                        </select>                        
                        </td>  */}
                         <td><input type="text" onChange={onChangeHandler} className="form-control" value={getForm.Status} id="Status" name="Status" /></td> 
                      </tr>
                      </tbody>
                    </table>                                                            
                       
                    </div>
                                                                 
                      <button type="submit" onClick={onAddHandler} className="btn btn-warning ab-subbtn">Add Order</button>
                    </form>
              </div>
              
                            
            </div>
   
        </div>
    </div>)
}

export default Addentry;
