import './Header.css';
import {Link} from 'react-router-dom';
function Header(){
    return (<div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <div className="heading"> Capital Logistics</div> <form className="form-inline my-2 my-lg-0">                               
                <div className="user">
                       
                    <tr>
                        <div className="usericon">
                        <a className="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a> 
                        </div>
                    </tr>
                    
                    <td>
                        <div className="radioheading">
                        <input type="radio" name="option" className="radioselect" checked/><Link to="/adminsignup">Sign Up</Link><br/>
                        <input type="radio" name="option" className="radioselect"/><Link to="/adminlogin">Login</Link><br/>
                        <input type="radio" name="option" className="radioselect"/><Link to="/customertrackingnew">Track</Link><br/>
                        
                        </div>  
                    </td> 
                </div>                            
            </form>         
   
                   
      </nav>    
        
     </div>)
    }
     
    export default Header;