import './Customertracking.css';
import {useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';

function Customertracking(){
  const[getList,setList] = useState([]);
  const[getSearch,setSearch]=useState('');


  const onChangeSearchHandler=(event)=>{
    setSearch(event.target.value);
  }

  const searchFilter=(event)=>{
    event.preventDefault();
    let details = getList.filter((obj)=>{
      return obj.OrderNo === getSearch; 
    })
    setList(details);
  }
    return(<div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <h3 className="heading"> Capital Logistics</h3>       
            <form className="form-inline my-2 my-lg-0">                               
                <div className="orderformicon">   
                    <a className="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a>                                          
                       
                </div>                
            </form>             
        </nav>
        <div className="container customer">
            <div className="row">
                <div className="col-12 customerhead">
                    Enter your order number here!
                    <input type="text" className="input1" value={getSearch} onChange={onChangeSearchHandler} placeholder="order number" id="OrderNo" />
                    <button type="submit" onClick={searchFilter} className="btn btn-blue" ><Link to="/searchlogistics">Search</Link></button>   
                </div>
                <div>
                Your order is delivered!
                </div>
            </div>  
        </div>
    </div>)
}
export default Customertracking;