import './Userlogin.css'; 
import {Link} from 'react-router-dom';

function Userlogin(){
    return (<div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <h3 className="userloginheading"> Capital Logistics</h3>       
            <form classNameName="form-inline my-2 my-lg-0">                               
                <div className="userloginicon">   
                    <a classNameName="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a>                                          
                       
                </div>                
            </form>             
        </nav>
        <div className="container">
            
            <div className="row">
              <div className="col-12">
                
                <div className="userlog"> 
                    Account Registration is Successful.<Link to="/adminlogin">Please click here to login.</Link>
                </div>
              </div>
            </div>
        </div>

    </div>)
}
 
export default Userlogin;