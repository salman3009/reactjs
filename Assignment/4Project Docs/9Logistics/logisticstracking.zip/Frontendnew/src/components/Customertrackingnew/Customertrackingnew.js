import './Customertrackingnew.css';
import {useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import { useEffect} from 'react';
import axios from 'axios';


function Customertrackingnew(){
  const[getList,setList] = useState([]);
  const[getSearch,setSearch]=useState('');
  const[getIndex,setIndex]=useState(-1);

  const[getForm,setForm]=useState({
    OrderNo:'',
    Placedon:'',
    CourierName:'',
    Status:''
  });


  const onChangeSearchHandler=(event)=>{
    setSearch(event.target.value);
  }

  const onChangeHandler=(event)=>{
    setForm({
      ...getForm,[event.target.name]:event.target.value
    })
  }
  const onEditSubmitHandler=(event)=>{
    event.preventDefault();
    let logisticsDetails =[...getList];
    let id= logisticsDetails[getIndex].id;
    axios.patch('http://localhost:3000/logistics/'+id,{
        OrderNo:getForm.OrderNo,
        Placedon:getForm.Placedon,
        CourierName:getForm.CourierName,
        Status:getForm.Status,
      
    }).then(()=>{
      setList(logisticsDetails);
      logisticsDetails[getIndex].OrderNo = getForm.OrderNo;
      logisticsDetails[getIndex].Placedon=getForm.Placedon;
      logisticsDetails[getIndex].CourierName = getForm.CourierName;
      logisticsDetails[getIndex].Status= getForm.Status;
      
    }).catch(()=>{
    })

  }
  
// Add book details into table
useEffect(()=>{
    axios.get('http://localhost:3000/logistics').then((response)=>{
         console.log(response.data)
         setList(response.data);
     }).catch((error)=>{
       console.log(error);
     })
     //         if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
     //           setList(JSON.parse(sessionStorage.getItem('bookDetails')))
     //         }
      },[])
    

  //search data in the table
  const searchFilter=(event)=>{
   event.preventDefault();
   let details = getList.filter((obj)=>{
     return obj.OrderNo === getSearch; 
   })
   setList(details);
 }

  //reset search field
 const resetFilter=(event)=>{
     event.preventDefault();
     setSearch('');
     axios.get('http://localhost:3000/logistics').then((response)=>{
         console.log(response.data)
         setList(response.data);
     }).catch((error)=>{
       console.log(error);
     })
   //   if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
   //     setList(JSON.parse(sessionStorage.getItem('bookDetails')))
    }
     return(<div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <div className="heading"> Capital Logistics</div>       
            <form className="form-inline my-2 my-lg-0">                               
                <div className="orderformicon">   
                    <a className="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a>                                          
                     <p>Welcome Serkan ! </p>
                     <button type="submit" className="btn btn-logoutdarkblue"><Link to="/homescreen">Logout</Link></button>

                </div>                
            </form>             
        </nav>
        <div className="container-fluid customer">
            {/* <div className="row">
                <div className="col-4 customerhead">  */}
                    Enter your order number here!
                    <input type="text" className="input1" value={getSearch} onChange={onChangeSearchHandler} placeholder="order number" id="OrderNo" />
                    <button  type="submit" onClick={searchFilter} className="btn btn-outline-success" style={{marginLeft: 200}}>Search</button>
                    <button onClick={resetFilter} class="btn btn-blue1">Reset</button>
                    <button type="submit" className="btn btn-blue1"><Link to="/homescreen">Cancel</Link></button>
                    {/* <button type="submit" onClick={searchFilter} className="btn btn-blue" ><Link to="/searchlogistics">Search</Link></button>    */}
                 {/* </div>
                
            </div>    */}
           
                
                <table class="table table-bordered">
                      <thead>
                        <tr>
                        <th scope="col">Order No</th>
                        <th scope="col">Placed on</th>
                        <th scope="col">Courier Name</th>
                        <th scope="col">Status</th>                                                 
                        </tr>
                      </thead>
                      <tbody>
                      {getList.map((obj,index)=>{
                            return(<tr key={index}>                          
                            <td>{obj.OrderNo}</td>
                            <td>{obj.Placedon}</td>
                            <td>{obj.CourierName}</td>
                            <td>{obj.Status}</td>
                            {/* <td><i  onClick={()=>onEditHandler(index)} data-toggle="modal" data-target="#edit" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i  onClick={()=>onDeleteHandler(index)} className="fa fa-trash" aria-hidden="true"></i></td> */}
                            </tr>)
                            })}                       
                      </tbody>
                </table>
                 
        </div>
       
       

    </div>)
}
export default Customertrackingnew;