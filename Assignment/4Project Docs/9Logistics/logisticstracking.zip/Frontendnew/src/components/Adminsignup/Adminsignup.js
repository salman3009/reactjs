import './Adminsignup.css';
import background from '../../assests/background.png';
import {Link} from 'react-router-dom';
import {firstNameValidation,lastNameValidation,empidValidation,passwordValidation,confpasswordValidation}  from '../Validation';
import {useState} from 'react';
import {useNavigate} from 'react-router-dom';

function Adminsignup(){
    const[getForm,setForm]=useState({
        firstName:'',
        lastName:'',
        empid:'',
        password:'',
        confpassword:''
      });
    
      const[getValidation,setValidation]=useState({
        firstName:'',
        lastName:'',
        empid:'',
        password:'',
        confpassword:''
      });
    
      const navigate = useNavigate();

      const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
      }
      const onSubmitHandler=(event)=>{
        event.preventDefault(); 
        setValidation({
            ...getValidation,firstName:!firstNameValidation(getForm.firstName)?"please provide Firstname":'',
                   lastName:!lastNameValidation(getForm.lastName)?"Please provide Lastname":'',
                   empid:!empidValidation(getForm.CourierName)?"Please provide Emp-ID":'',
                   password:!passwordValidation(getForm.Status)?"Please provide password":'',
                   confpassword:!confpasswordValidation(getForm.Status)?"Please provide correct password":''
        });
        
        if(empidValidation(getForm.empid) && passwordValidation(getForm.password) && 
        firstNameValidation(getForm.firstName) && lastNameValidation(getForm.lastName) && confpasswordValidation(getForm.confpassword)){
          alert("success");
          sessionStorage.setItem("empid",getForm.empid);
          sessionStorage.setItem("password",getForm.password);
          sessionStorage.setItem("firstName",getForm.firstName);
          sessionStorage.setItem("lastName",getForm.lastName);
          sessionStorage.setItem("confpassword",getForm.confpassword);

          navigate('/userlogin');
        }
    }
       
    //   const onAddHandler=(event)=>{
    //     event.preventDefault();
    //     setValidation({
    //       ...getValidation,firstName:!firstNameValidation(getForm.firstName)?"please provide Firstname":'',
    //       lastName:!lastNameValidation(getForm.lastName)?"Please provide Lastname":'',
    //       empid:!empidValidation(getForm.CourierName)?"Please provide Emp-ID":'',
    //       password:!passwordValidation(getForm.Status)?"Please provide password":'',
    //       confpassword:!confpasswordValidation(getForm.Status)?"Please provide correct password":''
    //           });
    //     if(getForm.firstName && getForm.Placedon && getForm.CourierName && getForm.Status){
    //       axios.post('http://localhost:3000/logistics',{
    //         OrderNo:getForm.OrderNo,  
    //         Placedon:getForm.Placedon,
    //         CourierName :getForm.CourierName,
    //         Status:getForm.Status
                
    //         }).then(()=>{
    //             navigate('/Searchlogistics');
    //           }).catch(()=>{
    //              alert("error");
    //           })
    //         }
    //         else{
    //           alert("Please add some data");
    //         }
    //       }
            

    return (<div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <h3 className="adminloginheading"> Capital Logistics</h3>  
            <form className="form-inline my-2 my-lg-0">
                               
                <div classname="adminloginicon">   
                    <tr>
                        <a className="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a> 
                    </tr>
                </div>
        </form>
        </nav>
        <div className="container">
        <div className="row">
                    <div className="col-4">
                    </div>
                
                    <div className="col-4">

                    </div>
                <form className="regform">
                     <div className="form-group">                                                    
                     </div>
                    <div className="form-group">
                      <label className="tabletext" >First Name</label>                        
                      <input type="text" onChange={onChangeHandler} className="form-control text-bg" value={getForm.firstName} id="firstName" name="firstName"/>
                      {getValidation.firstName && <div class="alert alert-danger" role="alert">
                                {getValidation.firstName}
                    </div> }
                    </div>                
                    <div className="form-group">
                      <label className="tabletext" >Last Name</label> 
                      <input type="text"  onChange={onChangeHandler} className="form-control text-bg"  value={getForm.lastName} id="lastName" name="lastName"/>
                      {getValidation.lastName && <div class="alert alert-danger" role="alert">
                                {getValidation.lastName}
                    </div> }
                    </div>
                    <div className="form-group">
                    <label className="tabletext" >Employee Id</label>
                    <input type="text" onChange={onChangeHandler} className="form-control text-bg" value={getForm.empid} id="empid" name="empid"/>
                    {getValidation.empid && <div class="alert alert-danger" role="alert">
                                {getValidation.empid}
                                </div> }
                    </div>
                    <div className="form-group">
                    <label className="tabletext">Password</label>
                    <input type="password" onChange={onChangeHandler} className="form-control text-bg" value={getForm.password} id="password" name="password"  />
                    {getValidation.password && <div class="alert alert-danger" role="alert">
                                {getValidation.password}
                                </div> }
                    </div>        
                    <div className="form-group">
                    <label className="tabletext">Confirm Password</label>
                    <input type="password" onChange={onChangeHandler} className="form-control text-bg" value={getForm.confpassword} id="confpassword"  name="confpassword"/>
                    {getValidation.confpassword && <div class="alert alert-danger" role="alert">
                                {getValidation.confpassword}
                    </div> }
                    </div>        
                    <button className="btn btn-blue" onClick={onSubmitHandler} type="submit" >Submit</button><br/>
                    <button  onClick={onSubmitHandler} type="submit" className="btn btn-blue"><Link to="/homescreen">Cancel</Link></button>
                        
                    <div className="col-4">                    
                    </div>
                </form>
</div>
</div>


        </div>);
}
 
export default Adminsignup;