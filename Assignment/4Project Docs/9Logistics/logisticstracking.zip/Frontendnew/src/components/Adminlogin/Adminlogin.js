import './Adminlogin.css';
import {Link,useNavigate} from 'react-router-dom';
import {empidValidation,passwordValidation}  from '../Validation';
import {useState} from 'react';
function Adminlogin(){
    const navigate = useNavigate();

    const[getForm,setForm]=useState({       
        empid:'',
        password:''       
      });

    const[getValidation,setValidation]=useState({        
        empid:'',
        password:''        
      });

    const onChangeHandler=(event)=>{
        setForm({
          ...getForm,[event.target.name]:event.target.value
        })
      }

    const onSubmitHandler=(event)=>{
        event.preventDefault();
        setValidation({
            ...getValidation,empid:!empidValidation(getForm.empid)?"Emp Id Required":'',
        password:!passwordValidation(getForm.password)?"Password Required":''
        });
        if(empidValidation(getForm.empid) && passwordValidation(getForm.password)){
            
            let empid = sessionStorage.getItem('empid');
            let password = sessionStorage.getItem('password');
            if(empid === getForm.empid && password === getForm.password){                
              navigate('/orderform');
            }            
            else{
              setValidation({
                empid:'Please enter valid Employee ID',
                password:'Password Not Matched'
              });
            }        
          }  
    }


    return(<div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light" >   
            <h3 className="adminloginheading"> Capital Logistics</h3>  
            <form className="form-inline my-2 my-lg-0">
                               
                <div classname="adminloginicon">   
                    <tr>
                        <a className="navbar-brand" href="#"><i className="fa fa-user" aria-hidden="true"></i></a> 
                    </tr>
                </div>
        </form>
        </nav>
        <form className="logform">
            <table className="logtable">
              <tr>
                  <td className="logtabletext">Employee Id </td>
                  <td><input type="text" onChange={onChangeHandler} value={getForm.empid} className="form-control logtext-bg" id="empid" name="empid" />
                  {getValidation.empid && <div class="alert alert-danger" role="alert">
                  {getValidation.empid}
                  </div> }
                 </td>
              </tr>                   
              <tr>
                  <td className="logtabletext">Password  </td>
                  <td><input type="password" onChange={onChangeHandler} value={getForm.password} className="form-control logtext-bg" id="password" name="password"/>
                  {getValidation.password && <div class="alert alert-danger" role="alert">
                  {getValidation.password}
                  </div> }
                 </td>
              </tr>                    
              <tr>
                  <td className="logtablebutton"> <button onClick={onSubmitHandler} type="submit" className="btn btn-adminloginblue">Login</button></td>
                  
                  <td ><button type="submit" className="btn btn-adminloginblue"><Link to="/homescreen">Cancel</Link></button></td>
              </tr>
            </table> 
  </form> 

    </div>)

}
export default Adminlogin;
