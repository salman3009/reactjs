import './Homescreen.css';
import background from '../../assests/background.png';
import {Link} from 'react-router-dom';

function Homescreen(){

    return (<div>
      
      <div> <img src={background} width={1300} height={900}/> </div>

         </div>)
}
 
export default Homescreen;