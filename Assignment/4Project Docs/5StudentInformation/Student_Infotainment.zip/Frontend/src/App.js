// import logo from './logo.svg';
import './App.css';

import './Assests/font-awesome/css/font-awesome.min.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Header from './Components/Header/Header';
import SignUp from './Components/SignUp/SignUp';
import Login from './Components/Login/Login';
import About from './Components/About/About';
import Dashboard from './Components/Dashboard/Dashboard';
import AddStudent from './Components/AddStudent/AddStudent';
import Contact from './Components/Contact/Contact';
import Courses from './Components/Courses/Courses'


function App() {
  return (
    <div>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='' element={<SignUp/>} />
          {/* <Route path='SignUp' element={<SignUp/>} /> */}
          <Route path='Login' element={<Login/>} />
          <Route path='About' element={<About/>} />
          <Route path='Dashboard' element={<Dashboard/>} />
          {/* <Route path='AddStudent' element={<AddStudent/>}/> */}
          <Route path='Contact' element={<Contact/>}/>
          <Route path='Courses' element={<Courses/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
