import './Dashboard.css';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';


const Dashboard = () => {

    const navigateTo = useNavigate();

    const [getList, setList] = useState([]);

    const [getStudentSearch, setStudentSearch] = useState([]);

    const [getIndex, setIndex] = useState(-1);

    const [getStudent, setStudent] = useState({
        studentID	: '',
        studentFirstName: '',
        collegeName: '',
        course: '',
        city : '',
        schoolName: '',
        grades : ''
    })

    useEffect(() => {
        axios.get('http://localhost:3000/students').then((response) => {
            console.log(response.data);
            setList(response.data);
        }).catch((error) => {
            console.log(error);
        })
    }, [])


    const onSubmitHandler = () => {
        navigateTo('/AddStudent')
    }

    const onDeleteHandler = (index) => {
        let studentDetails = [...getList];
        let id = studentDetails[index].id;
        axios.delete('http://localhost:3000/students/' + id).then(() => {
            studentDetails.splice(index, 1);
            setList(studentDetails);
        }
        ).catch((event) => {

        })
    }

    const onChangeHandler = (event) => {
        setStudent({
            ...getStudent, [event.target.name]: event.target.value
        })
    }

    const onSearchChangeHandler = (event) => {
        setStudentSearch(event.target.value);
    }

    const onClickFilterSearch = (event) => {
        event.preventDefault();
        let details = getList.filter((obj) => {
            return obj.studentFirstName === getStudentSearch;
            // console.log(obj.bookTitle.match(getStudentSearch));
            // return obj.bookTitle.match(getStudentSearch);
        })
        setList(details);
    }

    const onClickResetFilter = (event) => {
        event.preventDefault();
        setStudentSearch('');       
        axios.get('http://localhost:3000/students').then((response) => {
            console.log(response.data);
            setList(response.data);
        }).catch((error) => {
            console.log(error);
        })
    }

    const onEditHandler = (index) => {
        setStudent({
            studentFirstName: getList[index].studentFirstName,
            collegeName: getList[index].collegeName,
            course: getList[index].course,
            city : getList[index].city,
            schoolName: getList[index].schoolName,
            grades : getList[index].grades
        })
        setIndex(index);
    }

    const onEditSubmitHandler = (event) => {
        event.preventDefault();
        let studentDetails = [...getList];
        let id = studentDetails[getIndex].id;
        //console.log(getStudent.studentFirstName);
        axios.patch('http://localhost:3000/students/'+ id, {
            studentFirstName: getStudent.studentFirstName,
            collegeName: getStudent.collegeName,
            course: getStudent.course,
            city : getStudent.city,
            schoolName: getStudent.schoolName,
            grades : getStudent.grades

        }).then(() => {
            
            setList(studentDetails);
            studentDetails[getIndex].studentFirstName = getStudent.studentFirstName;
           // console.log(getStudent.studentFirstName);
            studentDetails[getIndex].collegeName = getStudent.collegeName;
            studentDetails[getIndex].course = getStudent.course;
            studentDetails[getIndex].city = getStudent.city;
            studentDetails[getIndex].schoolName = getStudent.schoolName;
            studentDetails[getIndex].grades = getStudent.grades

            setList(studentDetails);

        }).catch((error) => {
            console.log(error)
        })
    }

    return (<div>
        <div className="container-fluid">
            <div className="row">
                <div className="col-3">
                    <form>
                        <h5>Search Student</h5>
                        <div className="form-group">
                            <div>
                                <label>Student Name:</label>
                                <input type="text" value={getStudentSearch} onChange={onSearchChangeHandler} className="form-control" id="BookTitle" />
                            </div>
                            <br />
                            <button value={getStudentSearch} onClick={onClickFilterSearch} type="submit" className="btn btn-primary  search-button">Search</button>
                            <button onClick={onClickResetFilter} type="submit" className="btn btn-primary  search-button">Reset</button>
                        </div>
                    </form>
                </div>
                <div className="col-7"></div>

            </div>

            <div className="row">
                <div className="col-12">
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col">Student ID</th>
                                <th scope="col">Student First Name</th>
                                <th scope="col">College Name</th>
                                <th scope="col">Course</th>
                                <th scope="col">City </th>
                                <th scope="col">School Name</th>
                                <th scope="col">12th Grades </th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {getList.map((obj, index) => {
                                return (<tr key={index}>
                                    <th scope="row">{index + 1}</th>                                    
                                    <td>{obj.studentFirstName}</td>
                                    <td>{obj.collegeName}</td>
                                    <td>{obj.course}</td>
                                    <td>{obj.city}</td>
                                    <td>{obj.schoolName}</td>
                                    <td>{obj.grades}</td>
                                    <td><i onClick={() => onEditHandler(index)} data-toggle="modal" data-target="#edit" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                                    <td><i onClick={() => onDeleteHandler(index)} className="fa fa-trash" aria-hidden="true"></i></td>
                                </tr>
                                )
                            })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div className="modal fade" id="edit" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div className="modal-dialog" role="document">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id="exampleModalLabel">Update Student Details</h5>
                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div className="modal-body">
                        <div className="form-group">
                            <label>Student Name</label>
                            <input type="text" name="studentFirstName" value={getStudent.studentFirstName} onChange={onChangeHandler} className="form-control" id="studentFirstName" placeholder="student First Name" />
                        </div>
                        <div className="form-group">
                            <label>College Name</label>
                            <input type="text" name="collegeName" value={getStudent.collegeName} onChange={onChangeHandler} className="form-control" id="collegeName" placeholder="collegeName" />
                        </div>
                        <div className="form-group">
                            <label>Course</label>
                            <input type="text" name="course" value={getStudent.course} onChange={onChangeHandler} className="form-control" id="course " placeholder="course" />
                        </div>
                        <div className="form-group">
                            <label>City</label>
                            <input type="text" name="city" value={getStudent.city} onChange={onChangeHandler} className="form-control" id="city" placeholder="city" />
                        </div>
                        <div className="form-group">
                            <label>School Name</label>
                            <input type="text" name="schoolName" value={getStudent.schoolName} onChange={onChangeHandler} className="form-control" id="schoolName " placeholder="schoolName" />
                        </div>
                        <div className="form-group">
                            <label>12th Grades</label>
                            <input type="text" name="grades" value={getStudent.grades} onChange={onChangeHandler} className="form-control" id="grades" placeholder="grades" />
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" data-dismiss="modal" onClick={onEditSubmitHandler} className="btn btn-primary">Update</button>
                    </div>
                </div>
            </div>
        </div>

    </div>);
}

export default Dashboard;