import './About.css';
import Background from '../.././Assests/Univ.jpg';

function About() {
    return (
        <div>
            <div>
                <div className="img-container">
                    <img className="about-image" src={Background} alt="University" />
                    <h1 className="top-left">Welcome to <br /> Bharathiar University</h1>
                </div>
                <p>The Bharathiar University was established at Coimbatore by the Government of Tamilnadu in February 1982 under the Bharathiar University Act, 1981 (Act 1 of 1982). The erstwhile Postgraduate Centre of the University of Madras formed the core of the Bharathiar University, which was functioning at Coimbatore before 1982. University Grants Commission (UGC) recognized Bharathiar University in 1985 for grants.</p>
                <p><strong>University Vision</strong></p>
                <p>Our vision is to provide Internationally comparable quality higher education to the youth. The aim is not only focused on imparting subject knowledge and skills, but also to mould the students with better conduct and character committed to the societal needs and national development. Enshrined with the motto “Educate to Elevate”. The University strives to realize the vision of India and excel in promoting and protecting the rich heritage of our past and secular ideals of the nation.</p>

                <p><strong>University Mission</strong></p>
                <ul>
                    <li>To be innovative, inclusive and international University; committed to excellence in teaching, research and knowledge transfer and to serve the social, cultural and economic needs of the nation".</li>
                    <li>To innovate and offer educational programmes in various disciplines with synergistic interaction with the industry and society.</li>
                    <li>To impart knowledge and skills to students equipping them to be ready to face the emerging challenges to the knowledge area.</li>
                    <li>To provide equal opportunity to women students and prepare them to be equal partners in meeting the scientific and technological demands of the nation.</li>
                    <li>To contribute to the advancement to knowledge through applied research leading to newer products and process.</li>
                    <li>To prepare the students to work for societal transformation with commitment to justice and equality.</li>
                    <li>To inculcate among students a global vision with skills of international competence.</li>
                </ul>
            </div>
        </div>);
}

export default About;