import './Login.css';

import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { emailValidation, passwordValidation } from '../Validation.js'

function Login() {

    const navigateTo = useNavigate();

    const [getLogin, setLogin] = useState({
        libUsername: '',
        libPassword: ''
    });

    const [getLoginValidation, setLoginValidation] = useState({
        libUsername: '',
        libPassword: ''
    });

    const onLoginChangeHandler = (event) => {
        setLogin({
            ...getLogin, [event.target.name]: event.target.value
        })
    }

    const onLoginSubmit = (event) => {
        event.preventDefault();
        setLoginValidation({
            ...getLoginValidation, libUsername: !emailValidation(getLogin.libUsername) ? "please enter valid email / user name" : '',
            libPassword: !passwordValidation(getLogin.libPassword) ? "please enter correct password" : ''
        });

        if (emailValidation(getLogin.libUsername) && passwordValidation(getLogin.libPassword)) {

            let libUserName = sessionStorage.getItem('email');
            let libPassword = sessionStorage.getItem('password');
            if (libUserName === getLogin.libUsername && libPassword === getLogin.libPassword) {
                navigateTo('/dashboard');
            }
            else {
                setLoginValidation({
                    libUsername: 'User name does not match',
                    libPassword: 'Password does not match'
                });
            }

        }

    }
    return (
        <div>
            <div className="container">
                <div className="card bg-light text-white">

                    <div className="row">
                        <div className="col-4">

                        </div>
                        <div className="col-4">
                            <form>
                                <h2 className="login-label">Log in </h2>
                                <div className="form-group">
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td><input type="text" onChange={onLoginChangeHandler} name="libUsername" value={getLogin.libUsername} className="form-control" id="UserName" placeholder="Email" />   </td>
                                            </tr>
                                            <tr>{getLoginValidation.libUsername && <td colSpan={3} className="alert alert-danger" role="alert">
                                                {getLoginValidation.libUsername}
                                            </td>}
                                            </tr>
                                            <tr></tr>
                                            <tr>
                                                <td><input type="password" onChange={onLoginChangeHandler} name="libPassword" value={getLogin.libPassword} className="form-control" id="password" placeholder="Password" /></td>
                                            </tr>
                                            <tr>{getLoginValidation.libPassword && <td colSpan={3} className="alert alert-danger" role="alert">
                                                {getLoginValidation.libPassword}</td>}
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <button type="submit" onClick={onLoginSubmit} className="btn btn-primary login-margin">Login</button>
                            </form>
                        </div>
                        <div className="col-4">

                        </div>
                    </div>

                </div>
            </div>
        </div>);
}

export default Login;