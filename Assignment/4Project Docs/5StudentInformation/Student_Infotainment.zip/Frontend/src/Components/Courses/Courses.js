import './Courses.css';

function Courses() {
    return (
        <div>
            <div>
                <h1>Courses offered</h1>
                <h4>School of Management</h4>
                <h6>Departments</h6>
                <ul>
                    <li>Bharathiar School of Management and Entrepreneur Development(BSMED)</li>
                </ul>

                <h4>School of Biotechnology &amp; Genetic Engineering</h4>
                <h6>Departments</h6>
                <ul>
                    <li>Department of Biotechnology</li>
                    <li>Department of Microbial - Biotechnology</li>
                    <li>Department of Bio-Chemistry</li>
                </ul>

                <h4>School of Chemical Sciences</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Chemistry</li>
                </ul>

                <h4>School of Commerce</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Commerce</li>
                </ul>

                <h4>School of Computer Science &amp; Engineering</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Computer Science</li>
                    <li>Department of Computer Applications</li>
                    <li>Department of Information Technology</li>
                </ul>

                <h4>School of Economics</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Economics</li>
                </ul>

                <h4>School of Educational Studies</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Communication &amp; Media Studies</li>
                    <li>Department of Educational Technology</li>
                    <li>Department of Education</li>
                    <li>Department of Extension, Career Guidance and Student Welfare</li>
                    <li>Department of Physical Education</li>
                    <li>Department of Education(School of Distance Education)</li>
                </ul>

                <h4>School of English &amp; Other Foreign Languages</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of English and Foreign Languages</li>
                    <li>Department of Linguistics</li>
                </ul>

                <h4>School of Life Sciences</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Botany</li>
                    <li>Department of Bioinformatics</li>
                    <li>Department of Environmental Sciences</li>
                    <li>Department of Zoology</li>
                    <li>Department of Human Genetics and Molecular Biology</li>
                    <li>Department of Textiles and Apparel Design</li>
                </ul>

                <h4>School of Mathematics &amp; Statistics</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Mathematics</li>
                    <li>Department of Statistics</li>
                    <li>Department of Applied Mathematics</li>
                </ul>

                <h4>School of Physical Sciences</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Physics</li>
                    <li>Department of Medical Physics</li>
                    <li>Department of Nanoscience and Technology</li>
                    <li>Department of Electronics &amp; Instrumentation</li>
                </ul>

                <h4>School of Social Sciences</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Social Work</li>
                    <li>Department of Sociology and Population Studies</li>
                    <li>Department of Psychology</li>
                    <li>Department of Women's Studies</li>
                    <li>Department of Library Sciences</li>
                    <li>Department of History</li>
                </ul>

                <h4>School of Tamil and Other Indian Languages</h4>

                <h6>Departments</h6>

                <ul>
                    <li>Department of Tamil</li>
                </ul>

            </div>
        </div>);
}

export default Courses;