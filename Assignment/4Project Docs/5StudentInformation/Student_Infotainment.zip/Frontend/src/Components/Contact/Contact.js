import './Contact.css';

function Contact() {
    return (
        <div>
            <div>
                <h1>Contact Us</h1>
                <p><strong>Address</strong></p>
                The Registrar<br />
                Bharathiar University<br />
                Maruthamalai Road<br />
                Coimbatore-641 046<br />
                Tamil Nadu, India.<br />

                <p><strong>Phone</strong>:+91-422-2422222, 2422223<br />
                    <br />
                    <strong>Email</strong>:regr@buc.edu.in<br />
                    <br />
                    <strong>Fax</strong>: +91-422-2425706</p>
            </div>
        </div>);
}

export default Contact;