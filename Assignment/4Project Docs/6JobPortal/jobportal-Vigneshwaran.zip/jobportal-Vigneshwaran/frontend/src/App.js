import './App.css';

import AddJob from './Components/Addjob/Addjob';
import Admin from './Components/Admin/Admin';
import Header from './Components/Header/Header';
import JobList from './Components/Joblist/Joblist';
import Login from './Components/Login/Login';
import Profile from './Components/Profile/Profile';
import Register from './Components/Register/Register';
import SearchJob from './Components/Searchjob/Searchjob';
import About from './Components/About/About';
import {BrowserRouter,Routes,Route} from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
    <Routes>
    <Route path = '/Addjob' element={<AddJob/>}/>      
    <Route path = '' element={<><Header/><Register/></>}/>
    <Route path = '/Login' element={<Login/>}/>
    <Route path = '/Profile' element={<Profile/>}/>
    <Route path = '/Register' element={<Register/>}/>
    <Route path = '/Searchjob' element={<SearchJob/>}/>
    <Route path = '/About' element={<About/>}/>
    </Routes>
    </BrowserRouter>
  );
}
export default App;