import './Addjob.css';
import {Link,useNavigate} from 'react-router-dom';
import {useState} from 'react';
import axios from 'axios';

function Addjob(){

  const[getJob,setJob]=useState({
    Name:'',
    Position:'',
    Office:'',
    Age:'',
    StartDate:'',
    Salary:''
  });
  const navigate = useNavigate();
  const onChangeHandler=(event)=>{
    setJob({
      ...getJob,[event.target.name]:event.target.value
    })
  }
  const onAddHandler=(event)=>{
    event.preventDefault();
    if(getJob.Name && getJob.Position && getJob.Office && getJob.Age && getJob.StartDate && getJob.Salary){
        axios.post('http://localhost:3000/Addjob',{
          Name:getJob.Name,
          Position:getJob.Position,
          Office:getJob.Office,
          Age:getJob.Age,
          StartDate:getJob.StartDate,
          Salary:getJob.Salary
        }).then(()=>{
          navigate('/Searchjob');
        }).catch(()=>{
           alert("error");
        })
      // if(sessionStorage.getItem('expenseDetails')){ 
      //   let details = JSON.parse(sessionStorage.getItem('expenseDetails'));
      //   console.log(typeof details);
      //   expenseDetails.push(...details);
      //   expenseDetails.push({...getJob});
      //   sessionStorage.setItem("expenseDetails",JSON.stringify(expenseDetails));
      // }
      // else{
      //   expenseDetails.push({...getJob});
      //   sessionStorage.setItem("expenseDetails",JSON.stringify(expenseDetails));
      // }
      
    }
    else{
      alert("Please add some data");
    }
  }

    return (<div>
          <div className="container">
              <div className="row">
                <div className="col-4">

                </div>
                <div className="col-4">
                  <form>
                      <div className="form-group">
                          <label>Name</label>
                          <input type="text"  value={getJob.Name} onChange={onChangeHandler} name="Name" className="form-control" id="Name"  placeholder="Name"/>
                        </div>
                        <div className="form-group">
                          <label>Position</label>
                          <input  value={getJob.Position} onChange={onChangeHandler} type="text" name="Position" className="form-control" id="Position"  placeholder="Position"/>
                        </div>                
                      <div className="form-group">
                        <label>Office</label>
                        <input value={getJob.Office} onChange={onChangeHandler} type="text" name="Office" className="form-control" id="Office" placeholder="Office"/>                      
                      </div>
                      <div className="form-group">
                        <label>Age</label>
                        <input value={getJob.Age} onChange={onChangeHandler} type="text" name="Age" className="form-control" id="Age" placeholder="Age"/>
                      </div>
                      <div className="form-group">
                        <label>StartDate</label>
                        <input value={getJob.StartDate} onChange={onChangeHandler} type="StartDate"  name="StartDate" className="form-control" id="StartDate" placeholder="StartDate"/>
                      </div>
                      <div className="form-group">
                        <label>Salary</label>
                        <input value={getJob.Salary} onChange={onChangeHandler} type="text" name="Salary" className="form-control" id="Salary" placeholder="Salary"/>                     
                      </div>                  
                      <button onClick={onAddHandler} type="submit" className="btn btn-success">ADD</button>
                    </form>
              </div>
                <div className="col-4">                    
              </div>
              </div>     
          </div>
    </div>)
}
export default Addjob;