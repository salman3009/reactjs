import './Searchjob.css';
import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';
const Searchjob=()=>{
  const[getList,setList] =  useState([]);
  const[getIndex,setIndex]=useState(-1);
  const[getSearch,setSearch]=useState('');
  const[getJob,setJob]=useState({
    Name:'',
    Position:'',
    Office:'',
    Age:'',
    StartDate:'',
    Salary:''
  });
     useEffect(()=>{              
      axios.get('http://localhost:3000/Addjob').then((response)=>{
          console.log(response.data)
          setList(response.data);
      }).catch((error)=>{
        console.log(error);
      }) 
            // if(JSON.parse(sessionStorage.getItem('jobDetails')) && JSON.parse(sessionStorage.getItem('jobDetails')).length>0){
            //    setList(JSON.parse(sessionStorage.getItem('jobDetails')))
            // }
     },[])
     const onDeleteHandler=(index)=>{
       let jobDetails = [...getList];
       let id = jobDetails[index].id;
       axios.delete('http://localhost:3000/Addjob/'+id).then((response)=>{
        jobDetails.splice(index,1);
        setList(jobDetails);
       }).catch(()=>{
       })
      // sessionStorage.setItem('jobDetails',JSON.stringify(jobDetails));
     }
     const onEditHandler=(index)=>{
      setJob({
        Name:getList[index].Name,
        Position:getList[index].Position,
        Office:getList[index].Office,
        Age:getList[index].Age,
        StartDate:getList[index].StartDate,
        Salary:getList[index].Salary,
      })
      setIndex(index);
     }
     const onChangeHandler=(event)=>{
      setJob({
        ...getJob,[event.target.name]:event.target.value
      })
    }
    const onChangeSearchHandler=(event)=>{
      setSearch(event.target.value);
    }
    const onEditSubmitHandler=(event)=>{
      event.preventDefault();
      let jobDetails =[...getList];
      let id= jobDetails[getIndex].id;
      axios.patch('http://localhost:3000/Addjob/'+id,{
        Name:getJob.Name,
        Position:getJob.Position,
        Office:getJob.Office,
        Age:getJob.Age,
        StartDate:getJob.StartDate,
        Salary:getJob.Salary
      }).then(()=>{
        setList(jobDetails);
        jobDetails[getIndex].Name = getJob.Name;
        jobDetails[getIndex].Position=getJob.Position;
        jobDetails[getIndex].Office = getJob.Office;
        jobDetails[getIndex].Age = getJob.Age;
        jobDetails[getIndex].StartDate = getJob.StartDate;
        jobDetails[getIndex].Salary = getJob.Salary;
      }).catch(()=>{
      })     
     // sessionStorage.setItem('jobDetails',JSON.stringify(jobDetails));
    }
    const searchFilter=(event)=>{
      event.preventDefault();
      let details = getList.filter((obj)=>{
        return obj.Name === getSearch; 
      })
      setList(details);
    }
    const resetFilter=(event)=>{
        event.preventDefault();
        setSearch('');
        if(JSON.parse(sessionStorage.getItem('jobDetails')) && JSON.parse(sessionStorage.getItem('jobDetails')).length>0){
          setList(JSON.parse(sessionStorage.getItem('jobDetails')))
       }
    }
    return (<div>
      <div>
          <nav className="navbar navbar-expand">
            <a className="navbar-brand" href="#"><i className="fa fa-university" aria-hidden="true"></i></a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item active">
                    <Link className="nav-link" to="/Register">Home <span className="sr-only">(current)</span></Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/Searchjob">Search Job</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to="/Profile">Profile</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/About">About</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/Addjob">Add-Job</Link>
                </li>
              </ul>
            </div>
        </nav>
        </div>
        <br></br>
        <br></br>
       <div className="container-fluid">
              <div className="row">
                <div className="col-3">
                    <form>        
                        <div className="form-group">
                          <label>Name</label>
                          <input type="text" valsue={getSearch} onChange={onChangeSearchHandler} className="form-control" id="Name" name="Name" placeholder="Name"/>                        
                        </div>       
                        <button onClick={searchFilter} type="submit" className="btn btn-success">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button onClick={resetFilter}>Reset</button>
                      </form>
                </div>
                <div className="col-3">
                    <form>        
                        <div className="form-group">
                          <label>Office</label>
                          <input type="text" value={getSearch} onChange={onChangeSearchHandler} className="form-control" id="Office" name="Office" placeholder="Office"/>                        
                        </div>       
                      </form>
                </div>
                <div className="col-3">
                    <form>        
                        <div className="form-group">
                          <label>Age</label>
                          <input type="text" value={getSearch} onChange={onChangeSearchHandler} className="form-control" id="Age" name="Age" placeholder="Age"/>                        
                        </div>       
                      </form>
                </div>
                <div className="col-7"></div>
                <div className="col-2">
                </div>                
              </div>
              <div className="row">
                  <div className="col-12">
                    <table className="table table-bordered">
                        <thead>
                          <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Position</th>
                            <th scope="col">Office</th>
                            <th scope="col">Age</th>
                            <th scope="col">Start Date</th>
                            <th scope="col">Salary</th>
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                          </tr>
                        </thead>
                        <tbody>             
                        {getList.map((obj,index)=>{
                           return(<tr key={index}>
                            <th scope="row">{index+1}</th>
                            <td>{obj.Name}</td>
                            <td>{obj.Position}</td>
                            <td>{obj.Office}</td>
                            <td>{obj.Age}</td>
                            <td>{obj.StartDate}</td>
                            <td>{obj.Salary}</td>
                            <td><i onClick={()=>onEditHandler(index)} data-toggle="modal" data-target="#edit" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i onClick={()=>onDeleteHandler(index)} className="fa fa-trash" aria-hidden="true"></i></td>
                          </tr>
                           )})}
                        </tbody>
                      </table>
                  </div>
              </div>     
          </div> 
          <div className="modal fade" id="edit"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div className="modal-dialog" role="document">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" className="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div className="modal-body">
        <form>
                      <div className="form-group">
                          <label>Name</label>
                          <input type="text"  value={getJob.Name} onChange={onChangeHandler} name="Name" className="form-control" id="Name"  placeholder="Name"/>
                        </div>
                        <div className="form-group">
                          <label>Position</label>
                          <input  value={getJob.Position} onChange={onChangeHandler} type="text" name="Position" className="form-control" id="Position"  placeholder="Position"/>
                        </div>                        
                      <div className="form-group">
                        <label>Office</label>
                        <input value={getJob.Office} onChange={onChangeHandler} type="text" name="Office" className="form-control" id="Office" placeholder="Office"/>                      
                      </div>
                      <div className="form-group">
                        <label>Age</label>
                        <input value={getJob.Age} onChange={onChangeHandler} type="text" name="Age" className="form-control" id="Age" placeholder="Age"/>                  
                      </div>
                      <div className="form-group">
                        <label>StartDate</label>
                        <input value={getJob.StartDate} onChange={onChangeHandler} type="date"  name="StartDate" className="form-control" id="StartDate" placeholder="Password"/>
                      </div>
                      <div className="form-group">
                        <label>Salary</label>
                        <input value={getJob.Salary} onChange={onChangeHandler} type="text" name="Salary" className="form-control" id="Salary" placeholder="Salary"/>
                      </div>                  
                      <button data-dismiss="modal" onClick={onEditSubmitHandler} type="submit" className="btn btn-success">ADD</button>
                    </form>
        </div>       
      </div>
    </div>
  </div>
    </div>)
}
export default Searchjob;