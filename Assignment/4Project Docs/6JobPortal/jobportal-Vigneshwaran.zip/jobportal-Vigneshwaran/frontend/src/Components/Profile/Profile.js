import './Profile.css';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
function Profile(){
    return(
        <div>
        <div>
          <nav className="navbar navbar-expand">
            <a className="navbar-brand" href="#"><i className="fa fa-university" aria-hidden="true"></i></a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item active">
                    <Link className="nav-link" to="/Register">Home <span className="sr-only">(current)</span></Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/Searchjob">Search Job</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to="/Profile">Profile</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/About">About</Link>
                </li>
              </ul>
            </div>
        </nav>
        </div>
        <div><br></br><br></br><h3>User Profile</h3>
        <div>
          <form>
            
          </form>
        </div>
        </div>
        </div>
    );
}
export default Profile;