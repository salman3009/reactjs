import './FacProfile.css';

function FacProfile() {
    return (
        <div>
            Welcome to Faculty Profile - 
            {/* <userContext.Consumer>
{

}
</userContext.Consumer> */}
        </div>)
    }
    
    export default FacProfile;