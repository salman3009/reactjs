import './Login.css';
import abticon from '../../Assets/LibImages/bkShelf.jpg';
import stkicon from '../../Assets/LibImages/stackbk.jpg';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { emailValidation, passwordValidation } from '../Validation';
function test() {
    const navigate = useNavigate();
    
    const [getForm, setForm] = useState({
        email: '',
        password: ''
    });

    const [getValidation, setValidation] = useState({
        email: '',
        password: ''
    });

    const onChangeHandler = (event) => {
        setForm({
            ...getForm, [event.target.name]: event.target.value
        })
    }
    const onSubmitHandler = (event) => {
        event.preventDefault();
        setValidation({
            ...getValidation, email: !emailValidation(getForm.email) ? "Please enter email" : '',
            password: !passwordValidation(getForm.password) ? "Please enter password" : ''
        });
        if (emailValidation(getForm.email) && passwordValidation(getForm.password)) {
            let email = sessionStorage.getItem('email');
            let password = sessionStorage.getItem('password');
            if (email === getForm.email && password === getForm.password) {
                alert("success");
                navigate('/dashboard');
            }
            else {
                alert("Login Failed");
                setValidation({
                    email: 'no match found',
                    password: 'no match found'
                });
            }
        }
    }
    return (
        <div>
            <div className='container-fluid'>
                <img className="card-img" src={abticon} alt="bgfile" />
                <div className="card-img-overlay">
                    <div className='containers'>
                        <div className="row internpadd">
                            <div className="col-4">
                                <img src={stkicon} height={100} alt="bgfiles" />
                            </div>
                            <div className="col-8 padcls">
                                <h3>LIBRARY</h3>
                                <h5>MANAGEMENT SYSTEM</h5>
                            </div>
                        </div>
                        <div className="row internpadd">
                            <div className="col-4 text-right">
                                <label>User Name</label>
                            </div>
                            <input type="email" onChange={onChangeHandler} value={getForm.email} id="email" name="email" placeholder="Enter email" />
                        </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <div className="col-8 noPaddingCls">
                                {getValidation.email && <div className="alert alert-danger alertpadd" role="alert">
                                    {getValidation.email}
                                </div>}
                            </div>
                        </div>
                        <div className="row internpadd">
                            <div className="col-4 text-right">
                                <label>Password</label>
                            </div>
                            <input type="password" onChange={onChangeHandler} value={getForm.email} id="password" name="password" placeholder="Enter password" />
                        </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <div className="col-8">
                                {getValidation.password && <div className="alert alert-danger alertpadd" role="alert">
                                    {getValidation.password}
                                </div>}
                            </div>
                        </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <button onClick={onSubmitHandler} type="submit" className="btn btns">Login</button>
                        </div>
                    </div>
                </div>
            </div >
        </div >)
}
export default test;