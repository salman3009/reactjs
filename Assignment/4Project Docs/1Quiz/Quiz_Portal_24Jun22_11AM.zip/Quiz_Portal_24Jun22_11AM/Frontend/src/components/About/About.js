import './About.css';
import abticon from '../../Assets/LibImages/quizicon.jpg';
function About() {
    return (<div>
        <div className="container">
            <div className="row">
                <div className="col-12">
                    about
                    <img src={abticon} alt="abtic"/>
                                    </div>
            </div>
        </div>
    </div>);
}
export default About;