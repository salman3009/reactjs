import './Dashboard.css';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { bookTitleAuthorValidation, bookId, bookDescValidation } from '../Validation';
import axios from 'axios';
const Dashboard = () => {
  const [getList, setList] = useState([]);
  const [getIndex, setIndex] = useState(-1);
  const [getSearch, setSearch] = useState('');
  const [getBook, setBook] = useState({
    rollno: '',
    firstName: '',
    lastName: '',
    marks: ''
  });
  const [getValidation, setValidation] = useState({
    rollno: '',
    firstName: '',
    lastName: '',
    marks: ''
  });
  useEffect(() => {
    axios.get('http://localhost:3000/studentInfo').then((response) => {
      console.log(response.data)
      setList(response.data);
    }).catch((error) => {
      console.log(error);
    })
  }, [])
  const onDeleteHandler = (index) => {
    let expenseDetails = [...getList];
    let id = expenseDetails[index].id;
    axios.delete('http://localhost:3000/studentInfo/' + id).then((response) => {
      expenseDetails.splice(index, 1);
      setList(expenseDetails);
    }).catch(() => {

    })
  }
  const onEditHandler = (index) => {
    setBook({
      rollno: getList[index].rollno,
      firstName: getList[index].firstName,
      lastName: getList[index].lastName,
      marks: getList[index].marks
    })
    setIndex(index);
  }
  const onChangeHandler = (event) => {
    setBook({
      ...getBook, [event.target.name]: event.target.value
    })
  }
  const onChangeSearchHandler = (event) => {
    setSearch(event.target.value);
  }

  const onEditSubmitHandler = (event) => {
    event.preventDefault();
    let studDetails = [...getList];
    let id = studDetails[getIndex].id;
    axios.patch('http://localhost:3000/studentInfo/' + id, {
      rollno: getBook.rollno,
      firstName: getBook.firstName,
      lastName: getBook.lastName,
      marks: getBook.bookauthname
    }).then(() => {
      setList(studDetails);
      studDetails[getIndex].rollno = getBook.rollno;
      studDetails[getIndex].firstName = getBook.firstName;
      studDetails[getIndex].lastName = getBook.lastName;
      studDetails[getIndex].marks = getBook.marks;
    }).catch(() => {
    })
  }

  const searchFilter = (event) => {
    event.preventDefault();
    let details = getList.filter((obj) => {
      return obj.rollno === getSearch;
    })
    setList(details);
  }

  const resetFilter = (event) => {
    event.preventDefault();
    setSearch('');
    if (JSON.parse(sessionStorage.getItem('studDetails')) && JSON.parse(sessionStorage.getItem('studDetails')).length > 0) {
      setList(JSON.parse(sessionStorage.getItem('studDetails')))
    }
  }

  return (<div>
    <div className="container-fluid">
      <div className="row">
        <div className="col-3">
          <form>
            <div className="form-group">
              <label>Search Roll No</label>
              <input type="text" value={getSearch} onChange={onChangeSearchHandler} className="form-control" id="btxt" placeholder="Enter Roll no" />
            </div>
            <span>
              <button onClick={searchFilter} type="submit" className="btn btnin">Search</button>

              <button onClick={resetFilter} className="btn btnin">Reset</button>
            </span>
          </form>
        </div>
        <div className="col-7"></div>
        <div className="col-2">
          <button type="submit" className="btndash"><Link to="/addbook">Add Student</Link></button>
        </div>

      </div>

      <div className="row">
        <div className="col-12">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Roll No</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Marks</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              {getList.map((obj, index) => {
                return (<tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{obj.rollno}</td>
                  <td>{obj.firstName}</td>
                  <td>{obj.lastName}</td>
                  <td>{obj.marks}</td>
                  <td><i onClick={() => onEditHandler(index)} data-toggle="modal" data-target="#edit" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                  <td><i onClick={() => onDeleteHandler(index)} className="fa fa-trash" aria-hidden="true"></i></td>
                </tr>
                )
              })
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>


    <div className="modal fade" id="edit" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div className="modal-dialog" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div className="modal-body">
            <div className="container">
              <div className="col-10">
                <div className="row internpadd">
                  <div className="col-2">
                    <label className="font-weight-bold text-left"><h3>Edit Student details</h3></label>
                  </div>
                </div>
                <div className="row internpadd">
                  <div className="col-2">
                    <label className="font-weight-bold text-left">Roll No</label>
                  </div>
                  <div className="col-4">
                    <input type="text" value={getBook.rollno} onChange={onChangeHandler} name="rollno" className="form-control" id="rollno" placeholder="Enter rollno" />
                    {getValidation.rollno && <div className="alert alert-danger alertpadd" role="alert">
                      {getValidation.rollno}
                    </div>}
                  </div>
                </div>
                <div className="row internpadd">
                  <div className="col-2">
                    <label className="font-weight-bold text-left">First Name:</label>
                  </div>
                  <div className="col-4">
                    <input type="text" value={getBook.firstName} onChange={onChangeHandler} name="firstName" className="form-control" id="firstName" placeholder="Enter first name" />
                    {getValidation.firstName && <div className="alert alert-danger alertpadd" role="alert">
                      {getValidation.firstName}
                    </div>}
                  </div>
                </div>
                <div className="row internpadd">
                  <div className="col-2">
                    <label className="font-weight-bold text-left internpadd">Last Name:</label>
                  </div>
                  <div className="col-4">
                    <input type="text" value={getBook.lastName} onChange={onChangeHandler} name="lastName" className="form-control" id="lastName" placeholder="Enter last name" />
                    {getValidation.lastName && <div className="alert alert-danger alertpadd" role="alert">
                      {getValidation.lastName}
                    </div>}
                  </div>
                </div>
                <div className="row internpadd">
                  <div className="col-2">
                    <label className="font-weight-bold text-left">Marks:</label>
                  </div>
                  <div className="col-4">
                    <input type="text" value={getBook.marks} onChange={onChangeHandler} name="marks" className="form-control" id="marks" placeholder="Enter marks" />
                    {getValidation.marks && <div className="alert alert-danger alertpadd" role="alert">
                      {getValidation.marks}
                    </div>}
                  </div>
                </div>
                <div className="row internpadd">
                  <div className="col-2">
                    <button data-dismiss="modal" onClick={onEditSubmitHandler} type="submit" className="btn btn-success">Update</button>
                  </div>
                </div>
              </div >
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>)
}

export default Dashboard;