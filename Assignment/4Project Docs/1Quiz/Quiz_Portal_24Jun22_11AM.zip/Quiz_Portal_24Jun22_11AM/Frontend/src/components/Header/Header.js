import './Header.css';
import { Link } from 'react-router-dom';
import libricon from '../../Assets/LibImages/quizicon.jpg';
function Header() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light">
                <img src={libricon} height={50} width={50} alt="libicon" />
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>

                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item bgclr active">
                            <Link className="nav-link" to="/dashboard">Home</Link>
                        </li>
                        <li className="nav-item bgclr">
                            <Link className="nav-link" to="/FacProfile">Profile</Link>
                        </li>
                        <li className="nav-item bgclr">
                            <Link className="nav-link" to="/rules">Quiz Rules</Link>
                        </li>
                        <li className="nav-item bgclr">
                            <Link className="nav-link" to="/price">Post Quiz</Link>
                        </li>
                        <li className="nav-item bgclr">
                            <Link className="nav-link" to="/studdashboard">Student List</Link>
                        </li>
                    </ul>
                    <button className="btn submit-register atag" type="submit"><Link to="/">Sign Up</Link></button>
                    <button className="btn atag" type="submit"><Link to="login">Login</Link></button>

                </div>
            </nav>
        </div>)
}

export default Header;