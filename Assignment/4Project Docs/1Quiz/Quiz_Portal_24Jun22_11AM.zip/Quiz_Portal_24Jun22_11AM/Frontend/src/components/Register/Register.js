import './Register.css';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { emailValidation, passwordValidation, textValidation } from '../Validation';
import nwUsr from '../../Assets/LibImages/newUser.jpg';
function Register() {
//   <userContext.Provider value={"test"}>

// </userContext.Provider>
  const navigate = useNavigate();

  const [getForm, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  });

  const [getValidation, setValidation] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  });

  const onChangeHandler = (event) => {
    setForm({
      ...getForm, [event.target.name]: event.target.value
    })
  }
  const onSubmitHandler = (event) => {
    event.preventDefault();
    setValidation({
      ...getValidation, firstName: !textValidation(getForm.firstName) ? "Please provide First Name (alphabets only)" : '',
      lastName: !textValidation(getForm.lastName) ? "Please provide Last Name (alphabets only)" : '',
      email: !emailValidation(getForm.email) ? "Please provide Email (your email will be a username)" : '',
      password: !passwordValidation(getForm.password) ? "Please provide the Password (min 10 chars includes uppercase, number, special characters)" : ''
    });
    if (textValidation(getForm.firstName) && textValidation(getForm.lastName) && emailValidation(getForm.email) && passwordValidation(getForm.password)) {
      alert("success");
      sessionStorage.setItem("firstName", getForm.firstName);
      sessionStorage.setItem("lastName", getForm.lastName);
      sessionStorage.setItem("email", getForm.email);
      sessionStorage.setItem("password", getForm.password);
      navigate('/login');
    }
  }
  return (<div>
    <div className="container-fluid">
      {/*--------------------- Heading ---------------*/}
      <div className="row internpadd">
        <div className="col-4 text-right">
          <img src={nwUsr} height={50} alt="bgfiles" />
        </div>
        <div className="col-8">
          <label className="font-weight-bold text-left internpadd"><h3>Register</h3></label>
        </div>
      </div>
      {/*--------------------- firstName ---------------*/}
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-4">
          <label className="font-weight-bold text-left internpadd"><label>First Name</label></label>
        </div>
      </div>
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-3">
          <input type="text" onChange={onChangeHandler} value={getForm.firstName} className="form-control formctrl" id="firstName" name="firstName" placeholder="First Name" />
        </div>
        <div className="col-5">
          {getValidation.firstName && <div className="alert alert-danger alertpadd" role="alert">
            {getValidation.firstName}
          </div>}
        </div>
      </div>
      {/*--------------------- lastName ---------------*/}
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-4">
          <label className="font-weight-bold text-left internpadd"><label>Last Name</label></label>
        </div>
      </div>
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-3">
          <input type="text" onChange={onChangeHandler} value={getForm.lastName} className="form-control formctrl" id="lastName" name="lastName" placeholder="Last Name" />
        </div>
        <div className="col-5">
          {getValidation.lastName && <div className="alert alert-danger alertpadd" role="alert">
            {getValidation.lastName}
          </div>}
        </div>
      </div>
      {/*--------------------- Email ---------------*/}
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-4">
          <label className="font-weight-bold text-left internpadd"><label>Email Address</label></label>
        </div>
      </div>
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-3">
          <input type="text" onChange={onChangeHandler} value={getForm.email} className="form-control formctrl" id="email" name="email" placeholder="Enter email" />
        </div>
        <div className="col-5">
          {getValidation.email && <div className="alert alert-danger alertpadd" role="alert">
            {getValidation.email}
          </div>}
        </div>
      </div>
      {/*--------------------- Password ---------------*/}
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-4">
          <label className="font-weight-bold text-left"><label>Password</label></label>
        </div>
      </div>
      <div className="row">
        <div className="col-4">
        </div>
        <div className="col-3">
          <input type="text" onChange={onChangeHandler} value={getForm.password} className="form-control formctrl" id="password" name="password" placeholder="Enter password" />
        </div>
        <div className="col-5">
          {getValidation.password && <div className="alert alert-danger alertpadd" role="alert">
            {getValidation.password}
          </div>}
        </div>
      </div>
      {/*--------------------- submit button ---------------*/}
      <div className="row internpadd">
        <div className="col-4">
        </div>
        <div className="col-4">
          <button onClick={onSubmitHandler} type="submit" className="btn btns">Sign Up</button>
        </div>
      </div>
       {/*--------------------- End ---------------*/}
    </div>
  </div >)
}
export default Register;