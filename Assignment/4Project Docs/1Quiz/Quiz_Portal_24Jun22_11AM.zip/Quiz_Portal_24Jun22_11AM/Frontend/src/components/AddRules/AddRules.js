import './AddRules.css';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { bookTitleAuthorValidation,bookId} from '../Validation';
import axios from 'axios';
function AddRules() {
    const navigate = useNavigate();

    const [getBook, setBook] = useState({
      ruleno: '',
      rule:''
    });
    const [getValidation, setValidation] = useState({
      ruleno: '',
      rule:''
    });
  
    const onChangeHandler = (event) => {
      setBook({
        ...getBook, [event.target.name]: event.target.value
      })
    }
    const onAddHandler = (event) => {
      event.preventDefault();
      setValidation({
            ...getValidation, ruleno: !bookId(getBook.ruleno) ? "Please enter rule no" : '',
            rule: !bookTitleAuthorValidation(getBook.rule) ? "Please enter the rule" : ''
          });
      if (bookId(getBook.ruleno) && bookTitleAuthorValidation(getBook.rule)) {
        if (getBook.ruleno && getBook.rule) {
          axios.post('http://localhost:3000/ruleInfo', {
            ruleno: getBook.ruleno,
            rule: getBook.rule
                     }).then(() => {
            navigate('/rules');
          }).catch(() => {
            alert("error");
          })
        }
        else {
          alert("Please add some data");
        }
      }
    }
  return (<div>
      <div className="container">
        <div className="col-10">
          <div className="row internpadd">
            <div className="col-5">
              <label className="font-weight-bold text-left"><h3>Add Rule</h3></label>
            </div>
          </div>
          <div className="row internpadd">
            <div className="col-2">
              <label className="font-weight-bold text-left">New Rule #:</label>
            </div>
            <div className="col-4">
              <input type="text" value={getBook.ruleno} onChange={onChangeHandler} name="ruleno" className="frmCtrlModal" id="ruleno" placeholder="Enter Rule #" />
            </div>
            <div className="col-4">
              {getValidation.ruleno && <div className="alert alert-danger alertpadd" role="alert">
                {getValidation.ruleno}
              </div>}
            </div>
          </div>
          <div className="row internpadd">
            <div className="col-2">
              <label className="font-weight-bold text-left">New Rule:</label>
            </div>
            <div className="col-4">
              <input type="text" value={getBook.rule} onChange={onChangeHandler} name="rule" className="frmCtrlModal" id="rule" placeholder="Enter title" />
            </div>
            <div className="col-4">
              {getValidation.rule && <div className="alert alert-danger alertpadd" role="alert">
                {getValidation.rule}
              </div>}
            </div>
          </div>
      
          <div className="row internpadd">
            <div className="col-2">
  
            </div>
            <div className="col-5">
              <button onClick={onAddHandler} type="submit" className="btn btns">Add Rule</button>
            </div>
          </div>
        </div>
      </div >
        </div>)
    }
    
    export default AddRules;