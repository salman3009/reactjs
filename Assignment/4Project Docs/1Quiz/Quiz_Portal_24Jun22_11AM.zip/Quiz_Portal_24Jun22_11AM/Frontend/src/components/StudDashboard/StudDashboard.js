import './StudDashboard.css';
import { useEffect, useState } from 'react';
import { bookTitleAuthorValidation, bookId, bookDescValidation } from '../Validation';
import axios from 'axios';
const StudDashboard = () => {
  const [getList, setList] = useState([]);
  const [getIndex, setIndex] = useState(-1);
  const [getSearch, setSearch] = useState('');
  const [getBook, setBook] = useState({
    rollno: '',
    firstName: '',
    lastName: '',
    marks: ''
  });
  const [getValidation, setValidation] = useState({
    rollno: '',
    firstName: '',
    lastName: '',
    marks: ''
  });
  useEffect(() => {
    axios.get('http://localhost:3000/studentInfo').then((response) => {
      console.log(response.data)
      setList(response.data);
    }).catch((error) => {
      console.log(error);
    })
  }, [])
  
  const onChangeHandler = (event) => {
    setBook({
      ...getBook, [event.target.name]: event.target.value
    })
  }
  const onChangeSearchHandler = (event) => {
    setSearch(event.target.value);
  }
 
  const searchFilter = (event) => {
    event.preventDefault();
    let details = getList.filter((obj) => {
      return obj.rollno === getSearch;
    })
    setList(details);
  }

  const resetFilter = (event) => {
    event.preventDefault();
    setSearch('');
    if (JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length > 0) {
      setList(JSON.parse(sessionStorage.getItem('bookDetails')))
    }
  }

  return (<div>
    <div className="container-fluid">
      <div className="row">
        <div className="col-3">
          <form>
            <div className="form-group">
              <label>Search Roll No</label>
              <input type="text" value={getSearch} onChange={onChangeSearchHandler} className="form-control" id="btxt" placeholder="Enter Roll Number" />
            </div>
            <span>
              <button onClick={searchFilter} type="submit" className="btn btnin">Search</button>

              <button onClick={resetFilter} className="btn btnin">Reset</button>
            </span>
          </form>
        </div>
        
      </div>

      <div className="row">
        <div className="col-12">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Roll No</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Marks</th>
                </tr>
            </thead>
            <tbody>
              {getList.map((obj, index) => {
                return (<tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{obj.rollno}</td>
                  <td>{obj.firstName}</td>
                  <td>{obj.lastName}</td>
                  <td>{obj.marks}</td>
                     </tr>
                )
              })
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>     
    </div>)
}

export default StudDashboard;