import './App.css';
import './Assets/font-awesome/css/font-awesome.min.css';
import Login from './components/Login/Login';
//import Logout from './components/Logout/Logout';
import Header from './components/Header/Header';
import FacProfile from './components/FacProfile/FacProfile';
import Register from './components/Register/Register';
import About from './components/About/About';
import Rules from './components/Rules/Rules';
import Price from './components/Price/Price';
import Home from './components/Home/Home';
import Dashboard from './components/Dashboard/Dashboard';
import HeaderStudent from './components/HeaderStudent/HeaderStudent';
import AddStudent from './components/AddStudent/AddStudent';
import StudDashboard from './components/StudDashboard/StudDashboard';
import StudProfile from './components/StudProfile/StudProfile';
import RulesRead from './components/RulesRead/RulesRead';
import AddRules from './components/AddRules/AddRules';
import Quiz from './components/QuizMain';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import React from 'react';
export const userContext=React.createContext();
function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          {/*dynamic data */}
          <Route path='/about' element={<><HeaderStudent /><About /></>} />
          <Route path='/studprofile' element={<><HeaderStudent /><StudProfile /></>} />
          <Route path='/studdashboard' element={<><HeaderStudent /><StudDashboard /></>} />
          <Route path='/rulesread' element={<><HeaderStudent /><RulesRead /></>} />
          <Route path='/addrules' element={<><HeaderStudent /><AddRules /></>} />
          <Route path='/facprofile' element={<><Header /><FacProfile /></>} />
          <Route path='/login' element={<Login />} />
          <Route path='/about' element={<><Header /><About /></>} />
          <Route path='/price' element={<><Header /><Price /></>} />
          <Route path='/rules' element={<><Header /><Rules /></>} />
          <Route path='' element={<><Header /><Register /></>} />
          <Route path='/home' element={<><Header /><Home /></>} />
          <Route path='/quiz' element={<><Header /><Quiz /></>} />
          <Route path='/dashboard' element={<><Header /><Dashboard /></>} />
          <Route path='/addstudent' element={<><Header /><AddStudent /></>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;