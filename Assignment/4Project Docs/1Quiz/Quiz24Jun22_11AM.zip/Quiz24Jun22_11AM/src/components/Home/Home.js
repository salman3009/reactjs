import './Home.css';
function Home() {
    return (
        <div>
           <h3>Welcome to Quiz Portal</h3>
        </div>)
    }
    
export default Home;