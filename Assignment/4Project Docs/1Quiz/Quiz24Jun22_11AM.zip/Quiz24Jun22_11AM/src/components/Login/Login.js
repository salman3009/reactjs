import './Login.css';
import stkicon from '../../Assets/LibImages/readyimg.jpg';
import abticon from '../../Assets/LibImages/quizicon.jpg';
import { Link, useNavigate, Redirect} from 'react-router-dom';
import { useState } from 'react';
import { emailValidation, passwordValidation } from '../Validation';
//import Register from './components/Register/Register';
//import {userContext} from './components/Register/Register';
function Login() {
    const navigate = useNavigate();

    const [getForm, setForm] = useState({
        email: '',
        password: ''
    });

    const [getValidation, setValidation] = useState({
        email: '',
        password: ''
    });

    const onChangeHandler = (event) => {
        setForm({
            ...getForm, [event.target.name]: event.target.value
        })
    }
    const onFSubmitHandler = (event) => {
        event.preventDefault();
        setValidation({
            ...getValidation, email: !emailValidation(getForm.email) ? "Please enter email" : '',
            password: !passwordValidation(getForm.password) ? "Please enter password" : ''
        });
        if (emailValidation(getForm.email) && passwordValidation(getForm.password)) {
            let email = sessionStorage.getItem('email');
            let password = sessionStorage.getItem('password');
            if (email === getForm.email && password === getForm.password) {
                navigate('/dashboard');
                           }
            else {
                alert("Login Failed");
                setValidation({
                    email: 'no match found',
                    password: 'no match found'
                });
            }
        }
    }
    const onSubmitHandler = (event) => {
        event.preventDefault();
        setValidation({
            ...getValidation, email: !emailValidation(getForm.email) ? "Please enter email" : '',
            password: !passwordValidation(getForm.password) ? "Please enter password" : ''
        });
        if (emailValidation(getForm.email) && passwordValidation(getForm.password)) {
            let email = sessionStorage.getItem('email');
            let password = sessionStorage.getItem('password');
            if (email === getForm.email && password === getForm.password) {
                navigate('/studprofile');
                           }
            else {
                alert("Login Failed");
                setValidation({
                    email: 'no match found',
                    password: 'no match found'
                });
            }
        }
    }
    const onsignupHandler = (event) => {
        navigate('/');

    }
    return (
        <div>
            <div className='container-fluid containers'>
                {/* <img src={abticon} alt="bgfiless" /> */}
                <div className="col-4">
                </div>
                <div className="col-8">
                    <div className='formsett'>
                        <div className="row internpadd">
                            <div className="col-4">
                                <img src={abticon} height={100} alt="bgfiles" />
                            </div>
                            {/*
                            <div className="col-8 padcls">
                                <h3>QUIZ PORTAL</h3>
                            </div>*/}
                        </div>
                        <div className="row internpadd">
                            <div className="col-4 text-right">
                                <label>User Name</label>
                            </div>
                            <input type="email" onChange={onChangeHandler} value={getForm.email} id="email" name="email" placeholder="Enter email" />
                        </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <div className="col-8 noPaddingCls">
                                {getValidation.email && <div className="alert alert-danger alertpadd" role="alert">
                                    {getValidation.email}
                                </div>}
                            </div>
                        </div>
                        <div className="row internpadd">
                            <div className="col-4 text-right">
                                <label>Password</label>
                            </div>
                            <input type="password" onChange={onChangeHandler} value={getForm.password} id="password" name="password" placeholder="Enter password" />
                        </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <div className="col-8">
                                {getValidation.password && <div className="alert alert-danger alertpadd" role="alert">
                                    {getValidation.password}
                                </div>}
                            </div>
                        </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <button onClick={onSubmitHandler} type="submit" className="btn btns">Student Login</button>
                            <button onClick={onFSubmitHandler} type="submit" className="btn btns">Faculty Login</button>
                                                    </div>
                        <div className="row internpadd">
                            <div className="col-4">
                            </div>
                            <button onClick={onsignupHandler} className="btn btns submit-register" type="submit">New User Sign Up</button>
                        </div>
                    </div>
                </div >
            </div >
        </div >)
}
export default Login;