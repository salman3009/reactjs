import './AddStudent.css';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { bookTitleAuthorValidation, bookId, bookDescValidation } from '../Validation';
import axios from 'axios';
function AddStudent() {
  const navigate = useNavigate();
  const [getBook, setBook] = useState({
    rollno: '',
    firstName: '',
    lastName: '',
    marks: ''
  });
  const [getValidation, setValidation] = useState({
    rollno: '',
    firstName: '',
    lastName: '',
    marks: ''
  });

  const onChangeHandler = (event) => {
    setBook({
      ...getBook, [event.target.name]: event.target.value
    })
  }
  const onAddHandler = (event) => {
    event.preventDefault();
    setValidation({
          ...getValidation, rollno: !bookId(getBook.rollno) ? "Please enter proper roll number" : '',
          firstName: !bookTitleAuthorValidation(getBook.firstName) ? "Please enter proper First Name" : '',
          lastName: !bookDescValidation(getBook.lastName) ? "Please enter proper Last Name" : ''
        });
    if (bookId(getBook.rollno) && bookTitleAuthorValidation(getBook.firstName) && bookDescValidation(getBook.lastName)) {
      if (getBook.rollno && getBook.firstName && getBook.lastName) {
        axios.post('http://localhost:3000/studentInfo', {
          rollno: getBook.rollno,
          firstName: getBook.firstName,
          lastName: getBook.lastName
         
        }).then(() => {
          navigate('/dashboard');
        }).catch(() => {
          alert("error");
        })
      }
      else {
        alert("Please add some data");
      }
    }
  }
  return (<div>
    <div className="container">
      <div className="col-10">
        <div className="row internpadd">
          <div className="col-5">
            <label className="font-weight-bold text-left"><h3>Add Student</h3></label>
          </div>
        </div>
        <div className="row internpadd">
          <div className="col-2">
            <label className="font-weight-bold text-left">Roll No:</label>
          </div>
          <div className="col-4">
            <input type="text" value={getBook.rollno} onChange={onChangeHandler} name="rollno" className="frmCtrlModal" id="rollno" placeholder="Enter rollno" />
          </div>
          <div className="col-4">
            {getValidation.rollno && <div className="alert alert-danger alertpadd" role="alert">
              {getValidation.rollno}
            </div>}
          </div>
        </div>
        <div className="row internpadd">
          <div className="col-2">
            <label className="font-weight-bold text-left">First Name:</label>
          </div>
          <div className="col-4">
            <input type="text" value={getBook.firstName} onChange={onChangeHandler} name="firstName" className="frmCtrlModal" id="firstName" placeholder="Enter title" />
          </div>
          <div className="col-4">
            {getValidation.firstName && <div className="alert alert-danger alertpadd" role="alert">
              {getValidation.firstName}
            </div>}
          </div>
        </div>
        <div className="row internpadd">
          <div className="col-2">
            <label className="font-weight-bold text-left internpadd">Last Name:</label>
          </div>
          <div className="col-4">
            <input type="text" value={getBook.lastName} onChange={onChangeHandler} name="lastName" className="frmCtrlModal" id="lastName" placeholder="Enter Description" />
          </div>
          <div className="col-4">
            {getValidation.lastName && <div className="alert alert-danger alertpadd" role="alert">
              {getValidation.lastName}
            </div>}
          </div>
        </div>
        {/* <div className="row internpadd">
          <div className="col-2">
            <label className="font-weight-bold text-left">Author Name:</label>
          </div>
          <div className="col-4">
            <input type="text" value={getBook.marks} onChange={onChangeHandler} name="marks" className="frmCtrlModal" id="marks" placeholder="Enter Book Author Name" />
          </div>
          <div className="col-4">
            {getValidation.marks && <div className="alert alert-danger alertpadd" role="alert">
              {getValidation.marks}
            </div>}
          </div>
        </div> */}
        <div className="row internpadd">
          <div className="col-2">

          </div>
          <div className="col-5">
            <button onClick={onAddHandler} type="submit" className="btn btns">Add Student</button>
          </div>
        </div>
      </div>
    </div >
  </div >)
}

export default AddStudent;