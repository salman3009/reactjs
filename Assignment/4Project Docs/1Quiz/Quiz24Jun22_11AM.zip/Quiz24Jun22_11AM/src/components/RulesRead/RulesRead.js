import './RulesRead.css';
import { useEffect, useState } from 'react';
import axios from 'axios';
const RulesRead = () => {
  const [getList, setList] = useState([]);
  const [getIndex, setIndex] = useState(-1);
  const [getSearch, setSearch] = useState('');
  const [getBook, setBook] = useState({
    ruleno: '',
    rule: ''
  });
  const [getValidation, setValidation] = useState({
    ruleno: '',
    rule: ''
  });
  useEffect(() => {
    axios.get('http://localhost:3000/ruleInfo').then((response) => {
      console.log(response.data)
      setList(response.data);
    }).catch((error) => {
      console.log(error);
    })
  }, [])

  const onChangeHandler = (event) => {
    setBook({
      ...getBook, [event.target.name]: event.target.value
    })
  }
  const onChangeSearchHandler = (event) => {
    setSearch(event.target.value);
  }

  const onEditSubmitHandler = (event) => {
    event.preventDefault();
    let ruleDetails = [...getList];
    let id = ruleDetails[getIndex].id;
    axios.patch('http://localhost:3000/ruleInfo/' + id, {
      ruleno: getBook.ruleno,
      rule:getBook.rule
    }).then(() => {
      setList(ruleDetails);
      ruleDetails[getIndex].ruleno = getBook.ruleno;
      ruleDetails[getIndex].rule = getBook.rule;
    }).catch(() => {
    })
  }
 
  const searchFilter = (event) => {
    event.preventDefault();
    let details = getList.filter((obj) => {
      return obj.rule === getSearch;
    })
    setList(details);
  }

  const resetFilter = (event) => {
    event.preventDefault();
    setSearch('');
    if (JSON.parse(sessionStorage.getItem('ruleDetails')) && JSON.parse(sessionStorage.getItem('ruleDetails')).length > 0) {
      setList(JSON.parse(sessionStorage.getItem('ruleDetails')))
    }
  }

  return (<div>
    <div className="container-fluid">
      <div className="row">
        <div className="col-3">
          <form>
            <div className="form-group">
              <label>Search Rule</label>
              <input type="text" value={getSearch} onChange={onChangeSearchHandler} className="form-control" id="btxt" placeholder="Enter Rule" />
            </div>
            <span>
              <button onClick={searchFilter} type="submit" className="btn btnin">Search</button>

              <button onClick={resetFilter} className="btn btnin">Reset</button>
            </span>
          </form>
        </div>
       

      </div>

      <div className="row">
        <div className="col-12">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Rule No</th>
                <th scope="col">Rule</th>
                             </tr>
            </thead>
            <tbody>
              {getList.map((obj, index) => {
                return (<tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{obj.ruleno}</td>
                  <td>{obj.rule}</td>
                   </tr>
                )
              })
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>       
  </div>)
}

export default RulesRead;