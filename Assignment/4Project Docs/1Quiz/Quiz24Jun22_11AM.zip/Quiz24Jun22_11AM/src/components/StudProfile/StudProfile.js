import './StudProfile.css';

function StudProfile() {
    return (
        <div>
            Welcome to Student Profile - 
            {/* <userContext.Consumer>
{

}
</userContext.Consumer> */}
        </div>)
    }
    
    export default StudProfile;