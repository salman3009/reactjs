import './Price.css';
function Price() {
    return (
        <div>
            Post a quiz
        </div>)
    }
    
    export default Price;