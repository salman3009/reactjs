const initialState = {
    AddBookStatus:false,
    email:'',
    password:''
};

function users(state = initialState, action){

 switch(action.type){
     case 'success' : 
               return {
                   ...state,
                   email:action.payload.email,
                   password:action.payload.password,
                   AddBookStatus:true
               }
   case 'failure':
       return{
           ...state,
           AddBookStatus:false
       }
       
       default:          
       return state;   
 }

}

export default users;