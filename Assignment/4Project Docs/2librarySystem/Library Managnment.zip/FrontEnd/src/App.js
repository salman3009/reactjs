 import './App.css';
 
import './assests/font-awesome/css/font-awesome.min.css';
 import Header from './components/Header/Header';
import Register from './components/Register/Register';
import Login from './components/Login/Login';
import SearchBook from './components/SearchBook/SearchBook';

import AddBook from './components/AddBook/AddBook';
import AdminLogin from './components/AdminLogin/AdminLogin';
import Home from './components/Home/Home';
import AboutLibrary from './components/AboutLibrary/AboutLibrary';
import {BrowserRouter,Routes, Route} from 'react-router-dom';
 
function App() {
  return (
    <div>
      <BrowserRouter>
     
      <Routes>
      <Route path='/header' element={<Header/>} />
      <Route path='/register' element={<Register/>} />
      <Route path='/login' element={<Login/>} />
      <Route path='/searchbook' element={<SearchBook/>} />
      <Route path='/addbook' element={<AddBook/>} />
      <Route path='/adminlogin' element={<><Header/><AdminLogin/></>} />
     
      <Route path='/aboutlibrary' element={<><Header/><AboutLibrary/></>} />
      <Route path='/' element={<><Header/><Home/></>} />
      </Routes>   
      </BrowserRouter>
    
 
        
    </div>
  );
}
 export default App;