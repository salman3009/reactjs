import './Header.css';
import {useNavigate} from 'react-router-dom';
import {Link} from 'react-router-dom';
import {useSelector} from 'react-redux';
import {useDispatch } from 'react-redux';
import Users from '../../services/users';
function Header(){

    const usersInfo = useSelector((state) => state.users);
    const dispatch = useDispatch();
    const navigate = useNavigate();




    const onAddBook=(event)=>{
        event.preventDefault();
        Users.AddBook(dispatch);
        navigate('/addbook');
  }









    return(<div>

<nav className="navbar navbar-expand-lg navbar-dark bg-dark">
<a className="navbar-brand" href="#"><i className="fa fa-university" style={{color:"lightblue"}} aria-hidden="true"></i></a>
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto lt">
                      <li className="nav-item active">
                            <Link className="nav-link" to="/">Home</Link>
                      </li>
                      <li className="nav-item active">
                          <Link className="nav-link" to="/aboutlibrary">About Library</Link>
                      </li>
                      <li className="nav-item active">
                          <a className="nav-link" href="#">Rules and Regulations</a>
                      </li>
                      <li className="nav-item active">
                          <a className="nav-link" href="#">Price Card</a>
                      </li>
                </ul>
                <div>
                {!usersInfo.AddBookStatus &&
              <form className="form-inline my-2 my-lg-0">
              <button className="btn btn-outline-success my-2 my-sm-0 submit-register" type="submit"><Link to="/register">Sign Up</Link></button>
              <button className="btn btn-outline-success my-2 my-sm-0" type="submit"><Link to="/login">Login</Link></button>
            </form>
               }
{usersInfo.AddBookStatus &&
              <form className="form-inline my-2 my-lg-0">
              <button className="btn btn-outline-success my-2 my-sm-0 submit-register"  onClick={onAddBook} type="submit">AddBook</button>
            </form>
               }
                </div>
              </div>
        </nav>


    </div>)
}



export default Header;