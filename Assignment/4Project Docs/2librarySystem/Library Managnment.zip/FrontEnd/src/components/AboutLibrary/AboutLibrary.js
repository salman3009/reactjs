import './AboutLibrary.css';
import about from '../../assests/about.jpg';
function AboutLibrary(){






return(<div>
  <div className="container">
            <div className="row img-about" style={{backgroundRepeat:"no-repeat",  backgroundSize: "cover"}}>
            {/* <div className="col-4"> 
                                         <div><img src={about} /> </div> 
                                 </div>   */}
              <div className="col-12" style={{textAlign:"left",marginTop:"180px",color:"black"}}>               
                    <div ><h1>Welcome To</h1></div>
                    <div><h1>Library Management System</h1></div>
              </div>              
            </div>  
          </div>
          <div className="container">
            <div className="row">
                <div className="col about-par" style={{color:"black",textAlign:"justify"}}>                  
                  <div><h4>Online library management project in spring spring and hibernate is 
                      complete solution for all the manual problem that we face during the library
                      management. Mainly there are 2 main actor of the application that going to operate
                      the application <b>1.Admin/ Librarian and 2. User/Students.</b><br/>
                      Book or Digital books is the main module of the library management
                      system. Book are assets that we are storing in the database with some 
                      details like name, author name and version and a PDF format. So admin 
                      can perform crud operation and issued the booked to users</h4></div>  
                </div>              
            </div> 
        </div>     
    </div>);
}





export default AboutLibrary;