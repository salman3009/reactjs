export function emailValidation(input){

    return /^.+@.+\..+$/.test(input);
}
export function passwordValidation(input){
    return /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{5,30}$/.test(input);
}
export function firstNameValidation(input){

    return /^[a-zA-Z]*$/.test(input);
}
export function lastNameValidation(input){

    return /^[a-zA-Z]*.{5,20}$/.test(input);
}

export function bookTitleValidation(input){

    return /^[a-zA-Z].{3,10}$/.test(input);

}

export function bookDescValidation(input){

    return /^[a-zA-Z].{3,10}$/.test(input);

}


export function bookAuthorValidation(input){

    return /^[a-zA-Z].{3,10}$/.test(input);

}


export function noBooksValidation(input){

    return /^[0-9].{1,10}$/.test(input);

}
