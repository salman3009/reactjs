import './Home.css';
import last from '../../assests/last.jpg';

function Home(){

    return(<div>
<div className="row">
<div className=" img-about">

<img   
     src ={last} style={{width:"120%",height:"100%", backgroundRepeat:"no-repeat",  backgroundSize: "cover"}}/>

<marquee  width={"110%"}  direction={"left"} height={"100px"} padding={"20px"}><h1>Welcome to Online Library!!! </h1></marquee>
<h3  > Happy Reading!!!!!</h3>

</div>
</div>


    </div>)
}
export default Home;