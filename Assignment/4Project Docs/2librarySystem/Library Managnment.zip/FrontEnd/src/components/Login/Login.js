import './Login.css';
import axios from'axios';
import {Link,useNavigate} from 'react-router-dom';
import {useState,useEffect} from 'react';
import React from 'react';
import {useDispatch } from 'react-redux';
import Users from '../../services/users';
import books from '../../assests/books.jpg';
import{emailValidation,passwordValidation} from '../Validations';

function Login(){
    const navigate=useNavigate();
    const dispatch = useDispatch();
    
    const[getList,setList] =  useState([]);
    const[getForm,setForm]=useState({
        email:'',
        password:''
    })
    
    const[getValidation,setValidation]=useState({
        email:'',
        password:''
    })
    
    const onChangeHandler=(event)=>{
        setForm({
            ...getForm,[event.target.name]:event.target.value
          })
    }
    
    const onSubmitHandler=(event)=>{
        event.preventDefault();
        setValidation({
            ...getValidation,email:!emailValidation(getForm.email)?"Please enter your  registered email,as your username":'',
        password:!passwordValidation(getForm.password)?"Please enter correct password":''
        });
        if(emailValidation(getForm.email) && passwordValidation(getForm.password)){
            
            let email = sessionStorage.getItem('email');
            let password = sessionStorage.getItem('password');
            if(email === getForm.email && password === getForm.password){
               
              navigate('/searchbook');
            }
            
            else{
              setValidation({
                email:'Invalid Email-id',
                password:'Invalid Password'
              });
            }
        
          }
        
    
    }
    
    const onSubmitAdminHandler=(event)=>{
        event.preventDefault();
        setValidation({
            ...getValidation,email:!emailValidation(getForm.email)?"Please enter your  email":'',
        password:!passwordValidation(getForm.password)?"Please enter your  correct password":''
        });
        if(emailValidation(getForm.email) && passwordValidation(getForm.password)){
            
            let email = sessionStorage.getItem('email');
            let password = sessionStorage.getItem('password');
            if(email === getForm.email && password === getForm.password){
               
                Users.loadUsers(dispatch,email,password);
              navigate('/adminlogin');
            }
            
            else{
              setValidation({
                email:'no match found',
                password:'no match found'
              });
            }
        
          }
        
    
    }
    
    useEffect(()=>{
              
        axios.get('http://localhost:3000/library').then((response)=>{
            console.log(response.data)
            setList(response.data);
        }).catch((error)=>{
          console.log(error);
        }) 
              // if(JSON.parse(sessionStorage.getItem('expenseDetails')) && JSON.parse(sessionStorage.getItem('expenseDetails')).length>0){
              //    setList(JSON.parse(sessionStorage.getItem('expenseDetails')))
              // }
       },[])




    return(<div>

<div className="container bgimg" >            
              <div className="row">
                    <div className="col-4">
                    </div>
                    <div className="col-4 logform">
                            <div className="row">
                            <div className="col-4">
                                        <div><img src={books} width= {100} height= {100}/> </div>
                                </div>   
                                 
                                <div className="col-4" style={{marginRight:"30px"}}>                          
                                    <h1>LIBRARY</h1>
                                    <h6>MANAGEMENTSYSTEM</h6>
                                </div>    
                            </div>                    
                        <form className="form-inline" style={{marginTop:"10px"}}>
                            <div className="form-group row log" >
                                        <label for="validationCustomUsername" style={{fontSize:"20px"}} ><b>User Name </b>:</label><br></br>
                                <div className="input-group">
                                        <div className="input-group-prepend" style={{marginLeft:"30px"}}    >
                                        <span className="input-group-text" id="inputGroupPrepend"><i className="fa fa-user" aria-hidden="true"></i></span>
                                        </div>
                                        <input type="text"   value={getForm.email} onChange={onChangeHandler} className="form-control log-text" name="email" id="email"  aria-describedby="inputGroupPrepend" />
                                        {getValidation.email && <div class="alert alert-primary" role="alert">
                        {getValidation.email}
</div> }
                                </div>                        
                            </div>
                            
                            <div className="form-group row log">
                                   <br></br> <label for="validationCustomUsername" style={{fontSize:"20px"}} ><b>Password:  </b>   </label>
                                <div className="input-group"  style={{marginTop:"30px"}}>
                                    <div className="input-group-prepend" style={{marginLeft:"30px"}}>
                                        <span className="input-group-text" id="inputGroupPrepend"><i className="fa fa-key" aria-hidden="true"></i></span>
                                    </div>                          
                                    <input  type="password"  value={getForm.password} onChange={onChangeHandler} className="form-control log-text"  name="password" id="password"/>
                                    {getValidation.password && <div class="alert alert-primary" role="alert">
                        {getValidation.password}
</div> }
                                </div>
                            </div>                      
                        
                            <div className="form-group row">
                                <div className="col-sm-10" >
                                <table>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td><button type="submit"  onClick={onSubmitAdminHandler} className="btn btn-info ">Admin Login</button></td>
                                        <td><button type="submit" onClick={onSubmitHandler}  className="btn btn-info ">Login</button></td>
                                    </tr>
                                </table>                                
                                </div>
                            </div>
                        </form>
                
                        <div className="col-4">                    
                        </div>
                    </div>     
                </div>
        </div>
    </div>);
}

export default Login;