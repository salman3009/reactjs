
import './Register.css';
import {Link,useNavigate} from 'react-router-dom';
import {useState} from 'react';
import {firstNameValidation,lastNameValidation,emailValidation,passwordValidation}  from '../Validations';

function Register(){

  const navigate = useNavigate();
  const[getForm,setForm]=useState({
      firstName:'',
      lastName:'',
      email:'',
      password:''
    });

    const[getValidation,setValidation]=useState({
      firstName:'',
      lastName:'',
      email:'',
      password:''
    });


    const onChangeHandler=(event)=>{
      setForm({
        ...getForm,[event.target.name]:event.target.value
      })
    }
    const onSubmitHandler=(event)=>{
      event.preventDefault(); 
      setValidation({
        ...getValidation,firstName:!firstNameValidation(getForm.firstName)?"First name must be in alphabets more than 3 characters":'',
        lastName:!lastNameValidation(getForm.lastName)?"LastName must be atleast more than  3 characters":'',
        email:!emailValidation(getForm.email)?"please provide email,Your email-id will be your username ":'',
        password:!passwordValidation(getForm.password)?"Password must in capitalletter,number,special characters more than 6 characters":''
        
      });
      
      if(emailValidation(getForm.email) && passwordValidation(getForm.password) && 
      firstNameValidation(getForm.firstName) && lastNameValidation(getForm.lastName)){
        alert("Registered Sucessfully");
        sessionStorage.setItem("firstName",getForm.firstName);
        sessionStorage.setItem("lastName",getForm.lastName);
        sessionStorage.setItem("email",getForm.email);
        sessionStorage.setItem("password",getForm.password);
        

        navigate('/login');
      }
  }
     
    

    return(<div>
        <div className="container">
              <div className="row">
                    <div className="col-4">
                    </div>
                    <div className="col-4" >
                    <label><h1>Sign Up</h1></label>
                    </div>
                </div>
                <div className="row">
                    <div className="col-4">
                    </div>
                
                    <div className="col-4">
                    <form>
                            <div className="form-group">                                                    
                            </div>
                            <div className="form-group">
                                <label><b>First Name</b></label>
                                <input type="text" onChange={onChangeHandler} className="form-control" value={getForm.firstName} id="firstName" name="firstName" placeholder="Enter first name"/>
                                {getValidation.firstName && <div class="alert alert-primary" role="alert">
                                {getValidation.firstName}
                                </div> }
                            </div>
                            <div className="form-group">
                                <label><b>Last Name</b></label>
                                <input type="text" onChange={onChangeHandler} className="form-control" value={getForm.lastName} id="lastName" name="lastName"  placeholder="Enter last name"/>
                                {getValidation.lastName && <div class="alert alert-primary" role="alert">
                                {getValidation.lastName}
                                </div> }

                            </div>                        
                            <div className="form-group">
                                <label><b>Email address</b></label>
                                <input type="email" onChange={onChangeHandler} className="form-control" value={getForm.email} id="email" name="email" placeholder="Enter email"/>                      
                                {getValidation.email && <div class="alert alert-primary" role="alert">
                                {getValidation.email}
                                </div> }
                            </div>
                            <div className="form-group">
                                <label><b>Password</b></label>
                                <input type="password" onChange={onChangeHandler} className="form-control" value={getForm.password} id="password" name="password" placeholder="Password"/>
                                {getValidation.password && <div class="alert alert-primary" role="alert">
                                {getValidation.password}
                                </div> }
                            </div>                    
                            <button onClick={onSubmitHandler} type="submit" style={{marginLeft:"100px"}}className="btn btn-info">Register</button>
                        </form>
                    </div>
                    <div className="col-4">                    
                    </div>
                </div>     
        </div>
    </div>);
}

export default Register;
