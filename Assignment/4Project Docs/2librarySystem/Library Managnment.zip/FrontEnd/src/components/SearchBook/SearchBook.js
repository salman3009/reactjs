import './SearchBook.css';
import {Link} from 'react-router-dom';
import { useEffect,useState } from 'react';
import axios from 'axios';

function Searchbook(){
  const[getList,setList] = useState([]);
  const[getSearch,setSearch]=useState('');


  const onChangeSearchHandler=(event)=>{
    setSearch(event.target.value);
  }

  

   // Add book details into table
   useEffect(()=>{

    axios.get('http://localhost:3000/library').then((response)=>{
      console.log(response.data)
      setList(response.data);
  }).catch((error)=>{
    console.log(error);
  })
  //         if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
  //            setList(JSON.parse(sessionStorage.getItem('bookDetails')))
  //         }
   },[])
   //search data in the table
   const searchFilter=(event)=>{
    event.preventDefault();
    let details = getList.filter((obj)=>{
      return obj.bookTitle === getSearch; 
    })
    setList(details);
  }


  const resetFilter=(event)=>{
    event.preventDefault();
    setSearch('');
    if(JSON.parse(sessionStorage.getItem('bookDetails')) && JSON.parse(sessionStorage.getItem('bookDetails')).length>0){
      setList(JSON.parse(sessionStorage.getItem('bookDetails')))
   }
}



    return(<div>
        
        <div className="container-fluid">
            <div className="row">
              <div className="col-12">
                  <form>       
                    <div><label><h1>Search Book</h1></label></div> 
                    <div className="form-group row">
                      <label for="booktitle" className="col-sm-2 col-form-label">Book Title:</label>
                      <div className="col-sm-10">
                        <input type="text" value={getSearch} onChange={onChangeSearchHandler}  name="searchBookName" class="form-control" id="booktitle" style={{width: 250, height:30}} />
                      </div>
                    </div>                           
                      <button type="submit" onClick={searchFilter} className="btn btn-info "style={{marginLeft: 200}}>Search</button>
                      <button type="submit" onClick={resetFilter} className="btn btn-info " style={{marginLeft: 200}}>Reset</button>
                    </form>
              </div>                            
            </div>s

            <div className="row">
                <div className="col-12">
                <table class="table table-bordered">
                      <thead class="thead-dark">
                        <tr class="table-prim">
                          <th  scope="col">Book ID</th>
                          <th scope="col">Book Title</th>
                          <th scope="col">Book Description</th>
                          <th scope="col">Author</th>
                          <th scope="col">Number of books available</th>                         
                          <th scope="col">Purchase</th>                          
                        </tr>
                      </thead>
                      <tbody>
                            {getList.map((obj,index)=>{
                            return(<tr key={index}>   
                             <th class="table-danger" scope="row">{index+1}</th>                        
                             <td class="table-danger">{obj.bookTitle}</td>
                            <td class="table-danger">{obj.bookDesc}</td>
                            <td class="table-danger">{obj.bookAuthor}</td>
                            <td class="table-danger">{obj.noBooks}</td>
                            <td className="btn btn-info" data-toggle="modal" data-target="#purchase">Purchase</td> 
                          </tr>)
                            })}                        
                      </tbody>
                    </table>
                </div>
            </div>
   
        </div>




        <div className="modal fade" id="purchase"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLabel"></h5>
                  <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
  <h3>Your Payment to GateWay is Processing</h3>
<button className="btn btn-success">Click here to proceed</button>
<button  style={{paddingLeft:"10px"}} className="btn btn-danger">Cancel Payment </button>   

<button className="btn btn-info "><Link to="/">Back to home Page</Link> </button>             
        </div>
       
      </div>
    </div>
  </div>
    </div>);
}

export default Searchbook;