import './AddBook.css';
import {useNavigate} from 'react-router-dom';

import axios from 'axios';
import  {bookTitleValidation,bookDescValidation,bookAuthorValidation,noBooksValidation} from '../Validations'

import {useState} from 'react';


function AddBook(){
   
    const navigate=useNavigate();
const [getBook,setBook]=useState({
bookId:'',
    bookTitle:'',
bookDesc:'',
bookAuthor:'',
noBooks:''
})



const [getValidation,setValidation]=useState({

    bookTitle:'',
bookDesc:'',
bookAuthor:'',
noBooks:''
})






const onChangeHandler=(event)=>{
setBook({

        ...getBook,[event.target.name]:event.target.value
    })
}







const onAddHandler=(event)=>{
    event.preventDefault();
    setValidation({
      ...getValidation,bookTitle:!bookTitleValidation(getBook.bookTitle)?"Enter Alphabets only":'',
      bookDesc:!bookDescValidation(getBook.bookDesc)?"Enter Alphabets only":'',
      bookAuthor:!bookAuthorValidation(getBook.bookAuthor)?"Enter Alphabets only":'',
      noBooks:!noBooksValidation(getBook.noBooks)?"Enter numbers  only":''
    });
   
      if( getBook.bookTitle && getBook.bookDesc && getBook.bookAuthor && getBook.noBooks){
          axios.post('http://localhost:3000/library',{
         
            bookTitle:getBook.bookTitle,
            bookDesc:getBook.bookDesc,
            bookAuthor:getBook.bookAuthor,
            noBooks:getBook.noBooks
          }).then(()=>{
            navigate('/adminlogin');
          }).catch(()=>{
             alert("error");
          })
     
    }
    else{
      alert("Please fill all the details");
    }
  }








 





// const onAddHandler=(event)=>{
//     event.preventDefault();
//     if(getBook.bookTitle && getBook.bookDesc && getBook.bookAuthor && getBook.noBooks){
//         axios.post('http://localhost:3000/library',{
//             bookTitle:getBook.bookTitle,
//           bookdesc:getBook.bookDesc,
//           bookAuthor:getBook.bookAuthor,
//           nooBooks:getBook.noBooks
//         }).then(()=>{
//           navigate('/AdminLogin');
//         }).catch(()=>{
//            alert("error");
//         })
//       // 
//     else{
//       alert("Please add some data");
//     }
//   }




    return(<div>

<div className="container" style={{textlign:"center"}}>
            <div className="row">
            
              <div className="col-12">
                  <form>       
                    <div><label><h1>Add Book</h1></label></div> 
                   
                    <div className="form-group row">   
                    <table className="addbook_table">
                      <tbody>
                      {/* <tr>
                        <td><label >Book Id:</label>  </td>
                       
<td><input type="text" className="form-control " value={getBook.bookId} id="bookId" name="bookId" /></td>
                       
               
                      </tr> */}

                      
                      <tr>
                        <td><label ><b>Book Title:</b></label>  </td>
                       
<td><input type="text" onChange={onChangeHandler} className="form-control " value={getBook.bookTitle} id="bookTitle" name="bookTitle" />
                       
{getValidation.bookTitle && <div class="alert alert-primary" role="alert">
                        {getValidation.bookTitle}
</div> } </td>
                      
                      </tr><br></br> 
                      <tr>
                      <td><label ><b>Book Desc:</b></label></td>
                       
                        <td><input type="text" onChange={onChangeHandler} className="form-control" value={getBook.bookDesc} id="bookDesc" name="bookDesc" />
                        {getValidation.bookDesc && <div class="alert alert-primary" role="alert">
                        {getValidation.bookDesc}
                      
</div> }</td></tr><br></br> 
                      <tr>
                        <td><label ><b>Author Name:</b></label> </td>
                        <td><input type="text" onChange={onChangeHandler} className="form-control" value={getBook.bookAuthor} id="bookAuthor" name="bookAuthor" />
                        {getValidation.bookAuthor && <div class="alert alert-primary" role="alert">
                        {getValidation.bookAuthor}
</div> }</td>
                      </tr><br></br> <br></br> 
                      <tr>
                        <td><label><b>Number of Book Available:</b></label>  </td>
                        <td><input type="text" onChange={onChangeHandler} width={20} className="form-control" value={getBook.noBooks}  id="noBooks" name="noBooks"  />
                        {getValidation.noBooks && <div class="alert alert-primary" role="alert">
                        {getValidation.noBooks}
</div> }</td>
                      </tr>
                      </tbody>
                    </table>                                                            
                       
                    </div>
                                                                 
                      <button type="submit" onClick={onAddHandler} className="btn btn-info" >Add Book</button>
                    </form>
        </div>
              
                            
            </div>
   
        </div>

    </div>) 
    }
export default AddBook;