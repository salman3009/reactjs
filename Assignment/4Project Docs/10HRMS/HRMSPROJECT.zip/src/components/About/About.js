import './About.css';
import images from '../../assests/images.jfif';

const About=()=>{
   return(<div>
       <img src={images} style={{width:"1100px",height:"300px"}} 
        />
        <div class="col-4">
        <center>To terminate or dissolve a Supplemental Needs Trust, the worker sends a copy of the trust instrument and a memorandum to OKDHS Family Support Services Division, Attention: Health Related and Medical Services (HR&MS) explaining the reason for the requested termination or dissolution of the Supplemental Needs Trust, and giving the name and address of the trustee. The Employer and the Union recognize that the statewide payroll system (HRMS) rounds payroll calculations to five decimal places. This information is stored in the VCCS Human Resource Management System (HRMS). The Union and the Employer recognize that the statewide payroll system (HRMS) rounds payroll calculations to five (5) decimal places. Mass spectra (HRMS) were recorded on a LTQ XL Orbitrap by Thermo Fisher Scientific. To terminate or dissolve a Medicaid Income Pension Trust, the worker sends a memorandum with a copy of the trust to OKDHS Family Support Services Division, Attention: HR&MS, explaining the reason and effective date for the requested termination or dissolution of the Medicaid Income Pension Trust, and giving the name and address of the trustee. Employees requiring an address change, home telephone number, and/or emergency contact information, must make these changes in the HRMS. Delay in extraction and conversion of legacy data, and u</center>
      </div>
   </div>)
}

export default About;