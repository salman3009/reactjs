

function App(){

     return (<div>
       <div>Welcome to programming</div>
       <br/>
       <h1>Programming to javascript</h1>
     </div>)

}

export default App;
