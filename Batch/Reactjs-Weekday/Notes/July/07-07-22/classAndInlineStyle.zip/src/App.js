import Table from './Table/Table';
import Form from './Form/Form';
import {useState} from 'react';

function App(){

      const[getTableDetails,setTableDetails]=useState({
        productName:'',
        price:''
      });

      
    const[getFlag,setFlag]=useState(false);

      const onChangeGlobalHandler=(event)=>{
        setTableDetails({
            ...getTableDetails,
            [event.target.name]:event.target.value
        })
    }
    const onSubmitGlobalHandler=()=>{
      setFlag(true);
    }

 

     return (<div>
      {/* {getFlag && <Table productName={getTableDetails.productName} price={getTableDetails.price}/> }  */}
      {getFlag && <Table globalList={getTableDetails}/> } 
       <Form onCheckHandler={onChangeGlobalHandler}  onfinalSubmit={onSubmitGlobalHandler}/>
     </div>)

}

export default App;
