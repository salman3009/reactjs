import './Table.css';

function Table(props){
  
    const onSelectionHandler=()=>{
        alert("selection");
    }

    return(<div>
        <table>
            <thead>
            <tr>
                <th className="table-header">Product Name</th>
                <th className="table-header">Price</th>
            </tr>
            </thead>
           <tbody>
           <tr>
            
                <td>{props.globalList && props.globalList.productName}</td>
                
                <td>{props.globalList && props.globalList.price}</td>
            </tr>
           </tbody>
           
        </table>
    </div>)
}

export default Table;