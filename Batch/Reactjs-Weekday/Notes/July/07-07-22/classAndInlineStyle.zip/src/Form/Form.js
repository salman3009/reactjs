import { useState } from 'react';
import './Form.css';

function Form(props) {

    // const fontStyle = {
    //     fontWeight: 900,
    //     backgroundColor: 'indigo',
    //     height: '50px',
    //     borderRadius: "10px",
    //     marginLeft: "20px"
    // };

    const[getFontStyle,setFontStyle]=useState({
        fontWeight: 900,
        backgroundColor: 'indigo',
        height: '50px',
        borderRadius: "10px",
        marginLeft: "20px"   
    })
    const onChangeHandler = (event) => {
        if(event.target.name === "productName"){
            setFontStyle({
                ...getFontStyle,
                backgroundColor:event.target.value
            })
        }
        props.onCheckHandler(event);
    }

    const onSubmitHandler = (event) => {
        event.preventDefault();
        props.onfinalSubmit();
    }

    return (<div>
        <form className="form-control">
            <label>
                Product Name:
            </label>
            <input onChange={onChangeHandler} type="text" id="productName" name="productName" />
            <label>
                Price:
            </label>
            <input type="text" onChange={onChangeHandler} id="price" name="price" />
            <button style={getFontStyle} onClick={onSubmitHandler}>Add</button>
        </form>
    </div>)
}

export default Form;