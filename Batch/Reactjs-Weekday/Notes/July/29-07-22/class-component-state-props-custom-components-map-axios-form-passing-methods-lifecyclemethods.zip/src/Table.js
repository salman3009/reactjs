import {Component} from 'react';
class Table extends Component{

    constructor(props){
          super(props);
    }
  render(){
    return (<div>
      <table>
          <thead>
          <tr>
              <th>
              Expense Name
              </th>
          </tr>
          </thead>
          <tbody>
              <tr>
                  <td>{this.props.expense}</td>
              </tr>
          </tbody>
         
          
      </table>
    </div>)
  }
}

export default Table;
