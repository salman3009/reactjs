import './App.css';
import {Component} from 'react';
import Form from './Form';
import Table from './Table';
import List from './List';
class App extends Component{

  constructor(props){
    super(props);
    this.state={
      expenseName:'',
      flag:true
    }
  }

  onChangeHandler=(input)=>{
    this.setState({
      expenseName:input
    })
  }

  render(){
    return (<div>
      <Form onChangeForm={this.onChangeHandler}/>
      <Table expense={this.state.expenseName}/>
      <List/>
    </div>)
  }
}

export default App;
