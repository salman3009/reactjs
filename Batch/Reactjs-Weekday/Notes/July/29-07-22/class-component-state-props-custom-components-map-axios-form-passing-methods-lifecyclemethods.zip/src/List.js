import {Component} from 'react';
import axios from 'axios';

class List extends Component{

    constructor(props){
          super(props);
          this.state={
              list:[]
          }
    }
    
    componentDidMount(){
        axios.get('http://localhost:3000/expense').then(
            (response)=>{
               this.setState({
                   list:response.data
               })
            }
        ).catch((error)=>{
                console.log("error",error); 
        })
    }
  render(){
    return (<div>
      <table>
          <thead>
          <tr>
              <th>
              Expense Name
              </th>
          </tr>
          </thead>
          <tbody>
              {this.state.list.map((obj,index)=>{
                  return(
                    <tr key={index}>
                    <td>{obj.expenseName}</td>
                </tr>
                  )
              })}
             
          </tbody>
         
          
      </table>
    </div>)
  }
}

export default List;
