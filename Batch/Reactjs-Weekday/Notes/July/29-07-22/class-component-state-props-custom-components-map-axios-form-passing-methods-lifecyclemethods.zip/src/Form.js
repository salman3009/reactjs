
import {Component} from 'react';

class Form extends Component{
    
    constructor(props){
        super(props);
    }
    render(){
        return(<div>
            <form>
                <input type="text" onChange={(event)=>this.props.onChangeForm(event.target.value)} name="expenseName"/>
                <button>Add</button>
            </form>
        </div>)
    }
}

export default Form;
