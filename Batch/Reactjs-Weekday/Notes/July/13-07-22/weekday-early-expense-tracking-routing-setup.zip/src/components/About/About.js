import './About.css';
import dash from '../../assets/image/dash.PNG';
const About=()=>{
   return (<div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                 <img src={dash}/>
                </div>
          
            </div>
        </div>
   </div>)

}
export default About;
