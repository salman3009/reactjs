import './Login.css';

const Login=()=>{
   return (<div>
                 <div className="container">
            <div className="row">
                <div className="col-3">
 
                </div>
                <div className="col-6">
                 <form>
                      <div className="form-group">
                        <label>Email</label>
                        <input type="text" className="form-control"  name="email"  placeholder="Enter email"/>
                      </div>
                     <div className="form-group">
                       <label>Password</label>
                       <input type="password" className="form-control" name="passowrd" placeholder="Password"/>
                     </div>
                     <button type="submit" className="btn btn-success">Submit</button>
                   </form>
             </div>
             <div className="col-3">
                    
             </div>
            </div>
        </div>
   </div>)

}
export default Login;
