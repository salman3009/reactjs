import './Filter.css';

const Filter=()=>{
   return (<div>
         <div className="container">
            <div className="row">
                <div className="col-6">
                 <form>
                     <div className="form-group">
                       <label>Expense Name</label>
                       <input type="text" className="form-control"  name="expenseName"  placeholder="Enter expenseName"/>
                     </div>
                     <button type="submit" className="btn btn-success">search</button>
                   </form>
             </div>
             <div className="col-3">
                    
             </div>
            </div>

            
        </div>
   </div>)

}
export default Filter;
