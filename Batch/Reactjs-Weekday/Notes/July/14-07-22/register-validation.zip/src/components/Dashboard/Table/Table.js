import './Table.css';

const Table=()=>{
   return (<div>
         <div className="container">
            <div className="row">
                <div className="col-12">
                    <table className="table table-bordered">
                        <tr>
                            <th>Expense Name</th>
                            <th>Amount</th>
                            <th>Paid By</th>
                            <th>Date</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                        <tr>
                            <td>Car Loan</td>
                            <td>3000</td>
                            <td>Akash</td>
                            <td>29/03/2022</td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i className="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td>Car Loan</td>
                            <td>3000</td>
                            <td>Akash</td>
                            <td>29/03/2022</td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i className="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td>Car Loan</td>
                            <td>3000</td>
                            <td>Akash</td>
                            <td>29/03/2022</td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i className="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
   </div>)

}
export default Table;
