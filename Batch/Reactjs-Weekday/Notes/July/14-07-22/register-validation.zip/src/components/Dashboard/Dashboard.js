
import Filter from './Filter/Filter';
import Table from './Table/Table';

const Dashboard=()=>{
    return(<div>Dashboard
        <Filter/>
        <Table/>
    </div>)
}

export default Dashboard;