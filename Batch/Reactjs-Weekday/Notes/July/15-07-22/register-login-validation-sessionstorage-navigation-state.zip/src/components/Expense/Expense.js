import './Expense.css';

const Expense=()=>{
   return (<div>
           <div className="container">
            <div className="row">
                <div className="col-6">
                 <form>
                     <div className="form-group">
                       <label>Expense Name</label>
                       <input type="text" className="form-control"  name="expenseName"  placeholder="Enter expenseName"/>
                     </div>
                     <div className="form-group">
                        <label>Amount</label>
                        <input type="number" className="form-control"  name="amount"  placeholder="Enter amount"/>
                      </div>
                      <div className="form-group">
                        <label>Paid By</label>
                        <select className="form-control" name="paidBy" id="exampleFormControlSelect1">
                          <option>Cash</option>
                          <option>Card</option>
                          <option>UPI</option>
                        </select>
                      </div>
                     <div className="form-group">
                       <label>Expense Date</label>
                       <input type="date" className="form-control" name="date" placeholder="date"/>
                     </div>
                     <button type="submit" className="btn btn-success">Add</button>
                   </form>
             </div>
             <div className="col-3">
                    
             </div>
            </div>
        </div>
   </div>)

}
export default Expense;
