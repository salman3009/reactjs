import './Table.css';
import {useEffect,useState} from 'react';


const Table=()=>{

    const[getList,setList]=useState([]);

    useEffect(()=>{
         if(sessionStorage.getItem('list')){
             let list = JSON.parse(sessionStorage.getItem('list'));
             console.log(list);
             setList(list);
         }
    },[])

   return (<div>
         <div className="container">
            <div className="row">
                <div className="col-12">
                    <table className="table table-bordered">
                        <thead>
                        <tr>
                            <th>Expense Name</th>
                            <th>Amount</th>
                            <th>Paid By</th>
                            <th>Date</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                        </thead>
                        <tbody>
                        {
                           getList.map((obj,index)=>{
                               return (
                                 
<tr key={index}>
                            <td>{obj.expenseName}</td>
                            <td>{obj.amount}</td>
                            <td>{obj.paidBy}</td>
                            <td>{obj.date}</td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i className="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                                  

                       
                               )

                           }) 
                        }
                         </tbody>
                    </table>
                </div>
            </div>
        </div>
   </div>)

}
export default Table;
