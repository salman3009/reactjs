import Table from './Table/Table';
import Form from './Form/Form';
import {useState} from 'react';

function App(){

      const[getTableDetails,setTableDetails]=useState({
        productName:'',
        price:''
      });

      const onFormHandler=(input)=>{
               alert("formHandler");
               console.log(input);
               setTableDetails(input);
      }

     return (<div>
       <Table productName={getTableDetails.productName} price={getTableDetails.price}/>
       <Form onCheckHandler={onFormHandler} />
     </div>)

}

export default App;
