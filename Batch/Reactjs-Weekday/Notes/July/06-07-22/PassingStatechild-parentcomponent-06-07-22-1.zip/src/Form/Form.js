import {useState} from 'react';
import Table from '../Table/Table';

function Form(props){

    const[getForm,setForm]=useState({
        productName:'',
        price:''
    });

    const[getFlag,setFlag]=useState(false);

    const onChangeHandler=(event)=>{
        setForm({
            ...getForm,
            [event.target.name]:event.target.value,
            list:[1,2,3]
        })
    }

    const onSubmitHandler=(event)=>{
        event.preventDefault();
        setFlag(true);
        props.onCheckHandler(getForm);
    }

     return(<div>
         <form>
            Product Name:<input onChange={onChangeHandler} type="text" id="productName" name="productName"/>
            <br/>
            <br/>
            Price:<input type="text" onChange={onChangeHandler} id="price" name="price"/>
            <br/>
            <br/>
            <button onClick={onSubmitHandler}>Add</button>
         </form>
         {/* {getFlag && <div>
            <Table productName={getForm.productName} price={getForm.price}/>
         </div> } */}
         
     </div>)
}

export default Form;