import {useState} from 'react';
import Table from '../Table/Table';

function Form(props){
    const onChangeHandler=(event)=>{
        props.onCheckHandler(event);
    }

    const onSubmitHandler=(event)=>{
        event.preventDefault();
        props.onfinalSubmit();
    }

     return(<div>
         <form>
            Product Name:<input onChange={onChangeHandler} type="text" id="productName" name="productName"/>
            <br/>
            <br/>
            Price:<input type="text" onChange={onChangeHandler} id="price" name="price"/>
            <br/>
            <br/>
            <button onClick={onSubmitHandler}>Add</button>
         </form>    
     </div>)
}

export default Form;