import {useState} from 'react';

function Form(){

    const[getForm,setForm]=useState({
        productName:'',
        price:''
    });

    const[getFlag,setFlag]=useState(false);

    // let productName = "phone";
    // let price = 4000;

    const onChangeHandler=(event)=>{
         console.log(event.target.name);
         console.log(event.target.value);
        //  price = event.target.value;
        setFlag(true);
        setForm({
            ...getForm,
            [event.target.name]:event.target.value,
            list:[1,2,3]
        })
    }

    const onSubmitHandler=(event)=>{
        event.preventDefault();
        console.log("inside the submit");
        // productName = "laptop";
        // console.log(productName);

        // setForm({
        //     productName:"laptop",
        //     price:'333'
        // })

        // setForm({
        //     ...getForm,
        //     productName:"laptop"
        // })
    }

     return(<div>
         <form>
            Product Name:<input onChange={onChangeHandler} type="text" id="productName" name="productName"/>
            <br/>
            <br/>
            Price:<input type="text" onChange={onChangeHandler} id="price" name="price"/>
            <br/>
            <br/>
            <button onClick={onSubmitHandler}>Add</button>
         </form>
         {/* <div>Product Name:{productName}</div>
         <div>Price:{price}</div> */}
         {getFlag && <div>
            <div>Product Name:{getForm.productName}</div>
         <div>Price:{getForm.price}</div>
         <div>List:{getForm.list?getForm.list[0]:''}</div>
         {/* <div>List:{getForm.list && getForm.list[0]}</div> */}
         </div> }
         
     </div>)
}

export default Form;