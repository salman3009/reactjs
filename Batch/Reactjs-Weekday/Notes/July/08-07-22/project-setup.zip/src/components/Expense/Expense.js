import './Expense.css';

const Expense=()=>{
   return (<div>
       Expense
   </div>)

}
export default Expense;
