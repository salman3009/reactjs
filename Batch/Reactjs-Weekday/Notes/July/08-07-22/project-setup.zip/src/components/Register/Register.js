import './Register.css';

const Register=()=>{
   return (<div>
        <div className="container">
            <div className="row">
                <div className="col-3">
 
                </div>
                <div className="col-6">
                 <form>
                     <div className="form-group">
                       <label>Full Name</label>
                       <input type="text" className="form-control"  name="fullName"  placeholder="Enter fullName"/>
                     </div>
                     <div className="form-group">
                        <label>Last Name</label>
                        <input type="text" className="form-control"  name="lastName"  placeholder="Enter lastName"/>
                      </div>
                      <div className="form-group">
                        <label>Email</label>
                        <input type="text" className="form-control"  name="email"  placeholder="Enter email"/>
                      </div>
                     <div className="form-group">
                       <label htmlFor="exampleInputPassword1">Password</label>
                       <input type="password" className="form-control" name="passowrd" placeholder="Password"/>
                     </div>
                     <button type="submit" className="btn btn-success">Submit</button>
                   </form>
             </div>
             <div className="col-3">
                    
             </div>
            </div>
        </div>
   </div>)

}
export default Register;
