
import './App.css';
import Login from './components/Login/Login';
import Register from './components/Register/Register';
import Header from './components/Header/Header';
import About from './components/About/About';
import Dashboard from './components/Dashboard/Dashboard';
import Expense from './components/Expense/Expense';
import './assets/icon/font-awesome/css/font-awesome.min.css';

function App() {
  return (
    <div>
      <Header/>
      <Register/>
    </div>
  );
}

export default App;
