import './Table.css';
import {useEffect,useState} from 'react';
import Modal from '../../UI/Modal/Modal';
import axios from 'axios';

const Table=()=>{

    const[getList,setList]=useState([]);
    const[getModal,setModal]=useState(false);
    const[getModalIndex,setModalIndex]=useState(-1);
    const[getModalObject,setModalObject]=useState({});

    useEffect(()=>{
        axios.get('http://localhost:3000/expense').then(
            (response)=>{
                 console.log(response.data);
                 setList(response.data);
            }
        ).catch((error)=>{
                console.log("error",error); 
        })
    },[])

    const onDeleteHandler=(index)=>{
        let list = JSON.parse(sessionStorage.getItem('list'));
        list.splice(index,1);
        setList([...list]);
        sessionStorage.setItem('list',JSON.stringify(list));
    }

    const onEditHandler=(index)=>{
        setModal(true);
        let obj = getList[index];
        setModalObject({...obj});
        setModalIndex(index);
    }

    const onCloseModal=(props)=>{
        setModal(false);
        let list = getList;
        list[getModalIndex]=props;
        setList([...list]);
        sessionStorage.setItem('list',JSON.stringify(list));
    }


   return (<div>
         <div className="container">
            <div className="row">
                <div className="col-12">
                    {getModal && <Modal modalList={getModalObject} onClose={onCloseModal}/>}
                    <table className="table table-bordered">
                        <thead>
                        <tr>
                            <th>Expense Name</th>
                            <th>Amount</th>
                            <th>Paid By</th>
                            <th>Date</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                        </thead>
                        <tbody>
                        {
                           getList.map((obj,index)=>{
                               return (
                                 
<tr key={index}>
                            <td>{obj.expenseName}</td>
                            <td>{obj.amount}</td>
                            <td>{obj.paidBy}</td>
                            <td>{obj.date}</td>
                            <td><i  data-toggle="modal" onClick={()=>{onEditHandler(index)}} data-target="#exampleModal" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i onClick={()=>{onDeleteHandler(index)}} className="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                                  

                       
                               )

                           }) 
                        }
                         </tbody>
                    </table>
                </div>
            </div>
        </div>
   </div>)

}
export default Table;
