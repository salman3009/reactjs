import Table from './Table/Table';
import Form from './Form/Form';
function App(){

     return (<div>
       <Table productName="sony" price="4000" />
       <Form/>
     </div>)

}

export default App;
