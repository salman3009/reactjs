const initialState = {
    fullName: 'rajesh',
    age: 0
}

function user(state = initialState, action) {

    switch (action.type) {
        case 'success':
            return {
                ...state,
                ...action.payload,
                flag: true
            }

        case 'failure':
            return {
                flag: false
            }

        default:
            return state;
    }
}

export default user;