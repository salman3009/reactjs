const initalState={
    countries:[]
}

function list(state=initalState,action){

    switch(action.type){
        case 'details':
             return {
                 countries:action.payload?action.payload:[]
             }
       default :
              return {
                  ...state
              }      
    }

}

export default list;