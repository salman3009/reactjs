import React from 'react';
import ComponentB from './ComponentB';
import {useSelector} from 'react-redux';
function ComponentA(props){
    
    const user = useSelector((state)=>state.user);
    return (<div>
       <div>Component A{user.fullName}</div>
       <ComponentB fullName={props.fullName}/>
    </div>)
}
export default ComponentA