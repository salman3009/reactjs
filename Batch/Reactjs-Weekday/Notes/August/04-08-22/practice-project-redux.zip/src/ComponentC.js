import React from 'react';
import {userContext} from './App';
import {useSelector,useDispatch} from 'react-redux';
import {users} from './service/index';

function ComponentC(props){

    const dispatch = useDispatch();
    const user = useSelector((state)=>state.user);

    const onDispatchHandler=()=>{
        users.loadUsers(dispatch)
    }
    
    return (<div>
       <div>Component C - {user.fullName}</div>
       <button onClick={onDispatchHandler}>Dispatch</button>
       <div>{props.fullName}</div>
       <userContext.Consumer>
           {
               (obj)=>{
                   return (<div>{obj}</div>)
               }
           }
       </userContext.Consumer>
    </div>)
}
export default ComponentC