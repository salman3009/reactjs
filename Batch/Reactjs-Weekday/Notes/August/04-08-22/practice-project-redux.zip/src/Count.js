import React from 'react';
function Count(props){
        console.log("props",props.text);
    return (<div>
       <div>{props.text}</div>
       <div>{props.count}</div>
    </div>)
}
export default React.memo(Count);;