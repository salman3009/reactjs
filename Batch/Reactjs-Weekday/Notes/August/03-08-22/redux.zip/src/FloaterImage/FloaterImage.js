import './FloaterImage.css';
import Image from '../Assets/Image/tech-logo.png';

function FloaterImage(){
          return(<div>
              <img src={Image}/>
          </div>)
}
export default FloaterImage;