import {combineReducers} from 'redux';
import user from './user';
import list from './list';

const rootReducers = combineReducers({
       user:user,
       list:list
});

export default rootReducers;
