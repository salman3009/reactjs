import {useState} from 'react';
import Table from './Table/Table';
import Form from './Form/Form';
import FloaterImage from './FloaterImage/FloaterImage';
import UseRef from './UseRef';
import UseReducer from './UseReducer';
import UseCallBack from './useCallBack';
import ComponentA from './ComponentA';
import React from 'react';
export const userContext = React.createContext();


function App(){

      const[getTableDetails,setTableDetails]=useState({
        productName:'',
        price:''
      });

      const[getList,setList]=useState({
        flag:false
      });

      

      
    const[getFlag,setFlag]=useState(false);

      const onChangeGlobalHandler=(event)=>{
        setTableDetails({
            ...getTableDetails,
            [event.target.name]:event.target.value
        })
    }
    const onSubmitGlobalHandler=()=>{
      setFlag(true);
      setList(true);
      setList((obj)=>{
        console.log(obj);
        return obj;
      })
      // console.log(getList);
      

    }

 

     return (<div>
      {/* {getFlag && <Table productName={getTableDetails.productName} price={getTableDetails.price}/> }  */}
      {/* {getFlag && <Table globalList={getTableDetails}/> } 
       <Form onCheckHandler={onChangeGlobalHandler}  onfinalSubmit={onSubmitGlobalHandler}/>
        <FloaterImage/> */}
        {/* <UseRef/> */}
        {/* <UseReducer/> */}
        {/* <UseCallBack/> */}
        <userContext.Provider value={"microsoft"}>
          <ComponentA fullName="akash"/>
        </userContext.Provider>
    
     </div>)

}

export default App;
