

export const users={

      loadUsers:function(dispatch){
              dispatch({
                 type:"success",
                 payload:{
                     fullName:"akash",
                     age:44
                 }
            })
      },
      failedUsers:function(dispatch){
        dispatch({
           type:"failure",
           payload:{}
      })
},

};
