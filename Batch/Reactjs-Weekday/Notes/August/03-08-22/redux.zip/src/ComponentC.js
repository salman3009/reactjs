import React from 'react';
import {userContext} from './App';
import {useSelector} from 'react-redux';

function ComponentC(props){

    const user = useSelector((state)=>state.user);
    
    return (<div>
       <div>Component C - {user.fullName}</div>
       <div>{props.fullName}</div>
       <userContext.Consumer>
           {
               (obj)=>{
                   return (<div>{obj}</div>)
               }
           }
       </userContext.Consumer>
    </div>)
}
export default ComponentC