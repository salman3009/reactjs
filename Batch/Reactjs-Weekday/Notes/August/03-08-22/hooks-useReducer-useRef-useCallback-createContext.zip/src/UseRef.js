import {useRef,useEffect} from 'react';


function UseRef(){
    const refType  = useRef(null);

    useEffect(()=>{
      console.log(refType.current.id);
      refType.current.name = "fullName";
      refType.current.value = "salman";
      refType.current.disabled = true;  
    },[])

    return (<div>
       FullName: <input ref={refType} type="text" id="list"/>
    </div>)
}
export default UseRef;