import './Table.css';

function Table(props){
  
    let data = 'header';
    const onSelectionHandler=()=>{
        alert("selection");
    }

    return(<div>
        <table>
            <thead>
            <tr>
                <th className={"table-"+data}>Product Name</th>
                <th className={"table-"+data}>Price</th>
            </tr>
            </thead>
           <tbody>
           <tr>
            
                <td>{props.globalList && props.globalList.productName}</td>
                
                <td>{props.globalList && props.globalList.price}</td>
            </tr>
           </tbody>
           
        </table>
    </div>)
}

export default Table;