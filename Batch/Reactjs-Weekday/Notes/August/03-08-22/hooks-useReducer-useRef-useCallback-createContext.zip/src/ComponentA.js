import React from 'react';
import ComponentB from './ComponentB';
function ComponentA(props){
    
    return (<div>
       <div>Component A</div>
       <ComponentB fullName={props.fullName}/>
    </div>)
}
export default ComponentA