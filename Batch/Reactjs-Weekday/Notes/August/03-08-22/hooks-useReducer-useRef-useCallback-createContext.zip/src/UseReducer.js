import {useReducer} from 'react';

function UseReducer(){
   
     const initialState = 0;

     function reducer(state,type){
       switch(type){
         case 'increment':
              return state+1;
         case 'decrement':
              return state -1;
         default :
               return state;
       }

     }

     const[count,dispatch]=useReducer(reducer,initialState)
    return (<div>
       <div>{count}</div>
       <button onClick={()=>dispatch('increment')}>Increment</button>
       <button onClick={()=>dispatch('decrement')}>Decrement</button>
    </div>)
}
export default UseReducer;