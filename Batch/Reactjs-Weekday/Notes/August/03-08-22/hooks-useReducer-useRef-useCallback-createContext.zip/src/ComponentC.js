import React from 'react';
import {userContext} from './App';
function ComponentC(props){
    
    return (<div>
       <div>Component C</div>
       <div>{props.fullName}</div>
       <userContext.Consumer>
           {
               (obj)=>{
                   return (<div>{obj}</div>)
               }
           }
       </userContext.Consumer>
    </div>)
}
export default ComponentC