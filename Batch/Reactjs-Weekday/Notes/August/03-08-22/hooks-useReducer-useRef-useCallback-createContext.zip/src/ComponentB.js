import React from 'react';
import ComponentC from './ComponentC';
function ComponentB(props){
    
    return (<div>
       <div>Component B</div>
       <ComponentC fullName={props.fullName}/>
    </div>)
}
export default ComponentB