import React from "react";

function Rules() {
  return (
    <div>
      <h1>rules</h1>
    </div>
  );
}

export default Rules;
