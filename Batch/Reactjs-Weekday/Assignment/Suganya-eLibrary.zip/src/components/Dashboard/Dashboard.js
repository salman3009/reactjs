import Table from "./Table/Table";
import Filter from "./Filter/Filter";
export default function Dashboard() {
  return (
    <div>
      <Filter />
      <Table />
    </div>
  );
}
