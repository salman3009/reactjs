import "./PriceCard.css";

const PriceCard = () => {
  return (
    <div>
      <div className="container mt-3">
        <h2>price card</h2>
      </div>
    </div>
  );
};

export default PriceCard;
