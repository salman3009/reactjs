import "./SearchBookPage.css";

const SearchBookPage=()=>{
    return(<div>
        <h2>Search Book</h2>
    <div className="container">
        <div className="row">
            <div className="col-3">
                <form>
                    <div className="form-group row">
                        <label className="col-sm-5 col-form-label">Book Title:</label>
                        <div className="col-sm-7">
                            <input type="text" className="form-control" />
                        </div>
                    </div>
                    <div className="text-center">
                        <button type="submit" className="btn">Search</button>
                    </div>
                </form>
            </div>
            <div className="col-4">


            </div>
            <div className="col-3">

            </div>

        </div>

    </div>
    <table className="table">
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Position</th>
            <th scope="col">Office</th>
            <th scope="col">Age</th>
            <th scope="col">Start date</th>
            <th scope="col">Salary</th>
            <th scope="col">Purchase</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Mark</td>
            <td>Accountant</td>
            <td>San Antonio</td>
            <td>33</td>
            <td>2006/02/12</td>
            <td>$12,000</td>
            <td><a href="https://www.w3schools.com">Purchase</a></td>
          </tr>
          <tr>
            <td>Hunter</td>
            <td>Chief Executive Officer (CEO)</td>
            <td>Los Angeles</td>
            <td>56</td>
            <td>2012/08/12</td>
            <td>$90,000</td>
            <td><a href="https://www.w3schools.com">Purchase</a></td>
          </tr>
          <tr>
            <td>Jack</td>
            <td>Junior Technical Author</td>
            <td>Chicago</td>
            <td>47</td>
            <td>2013/08/30</td>
            <td>$45,000</td>
            <td><a href="https://www.w3schools.com">Purchase</a></td>
          </tr>
          <tr>
            <td>Jaxson</td>
            <td>Software Engineer</td>
            <td>Houston</td>
            <td>30</td>
            <td>2010/09/08</td>
            <td>$60,000</td>
            <td><a href="https://www.w3schools.com">Purchase</a></td>
          </tr>
          <tr>
            <td>Grayson</td>
            <td>Software Engineer</td>
            <td>San Antonio</td>
            <td>37</td>
            <td>2011/05/17</td>
            <td>$60,000</td>
            <td><a href="https://www.w3schools.com">Purchase</a></td>
          </tr>
          <tr>
            <td>Colton</td>
            <td>Sales Assistant</td>
            <td>Dallas</td>
            <td>38</td>
            <td>2011/10/15</td>
            <td>$46,000</td>
            <td><a href="https://www.w3schools.com">Purchase</a></td>
          </tr>
        </tbody>
      </table>
    </div>)
}
export default SearchBookPage;