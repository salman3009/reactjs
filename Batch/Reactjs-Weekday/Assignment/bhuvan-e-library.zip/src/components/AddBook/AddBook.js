import "./AddBook.css";

const AddBook=()=>{
    return(<div>
        <div className="container">
        <div className="row">
            <div className="col-7">
                <form>
                    <h1>Add Book</h1>
                    <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Book ID:</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" placeholder="" />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Book Title:</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" placeholder="" />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Book Desc:</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" placeholder="" />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Author Name:</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" placeholder="" />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Number of Book Available:</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" placeholder="" />
                        </div>
                      </div>
                    <div className="text-center">
                        <button type="submit" className="btn">Add Book</button>
                    </div>
                </form>

            </div>
            <div className="col-3">

            </div>
            <div className="col-2">

            </div>

        </div>
        </div>
    </div>)
}
export default AddBook;