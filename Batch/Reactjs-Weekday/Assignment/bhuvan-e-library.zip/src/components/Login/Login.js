import "./Login.css";
//import book from "../../assets/image/book";
import { useState } from "react";
import { email, password } from '../../helper/validation';
import {registerValidationError} from '../../helper/constant';
import { useNavigate } from "react-router-dom";

const Login=()=>{

    const navigate = useNavigate();

    const [getLoginForm,SetLoginForm]=useState({
        email:'',
        password:''
    })

    const [getLoginFormValidation,SetLoginFormValidation]=useState({
        email:false,
        password:false,
        sessionDetails:false
    })

    const [getLoginGlobalCheck,SetLoginGlobalCheck]=useState(false);

    const onChangeHandler=(event)=>{
        SetLoginForm({
            ...getLoginForm,
            [event.target.name]:event.target.value
        })
    }

    const onSubmitHandler=(event)=>{
        event.preventDefault();
        SetLoginGlobalCheck(true);
        SetLoginFormValidation({
            email:email(getLoginForm.email)?false:true,
            password:password(getLoginForm.password)?false:true
        })
        if(getLoginForm.email && getLoginForm.password){
            let email = sessionStorage.getItem('email');
            let password = sessionStorage.getItem('password');
            if(email!=getLoginForm.email && password!=getLoginForm.password){
                SetLoginFormValidation({
                    ...getLoginFormValidation,
                    sessionDetails:true
                })
            }else{
                navigate("searchBookPage")
            }
        }
        alert("Hello");
    }

    return(<div>
        <div className="bg">
        <div className="container">
            <div className="row">
                <div className="col-3">

                </div>
                <div className="col-6">
                {getLoginGlobalCheck && getLoginFormValidation.sessionDetails && <div className="alert alert-danger" role="alert">
                {registerValidationError.sessionDetails} </div>}
                    <form className="form-container" onSubmit={onSubmitHandler}>
                        <div className="header">
                            <img src='./book.PNG' />
                            <h1>LIBRARY MANAGEMENT SYSTEM</h1>
                        </div> 
                        <div className="form-group row">
                            <label className="col-sm-2 col-form-label">UserName</label>
                            <div className="col-sm-10">
                                <input type="text" onChange={onChangeHandler} className="form-control" name="email" placeholder="Username"/>  
                                {getLoginGlobalCheck && getLoginFormValidation.email && <div className="alert alert-danger" role="alert">
                {registerValidationError.email} </div>}
                            </div>      
                        </div>
                        <div className="form-group row">
                            <label className="col-sm-2 col-form-label">Password</label>
                            <div className="col-sm-10">
                                <input type="password" onChange={onChangeHandler} className="form-control" name="password" placeholder="Password"/>
                                {getLoginGlobalCheck && getLoginFormValidation.password && <div className="alert alert-danger" role="alert">
                {registerValidationError.password} </div>}
                            </div>
                        </div>
                        <div className="text-center">
                            <button type="submit" className="btn btn-primary">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>)
}
export default Login;