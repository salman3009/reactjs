import "./EditBook.css";

const EditBook=()=>{
    return(<div>
        <h2>Search Book</h2>
    <div className="container">
        <div className="row">
            <div className="col-5">
                <form>
                    <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Book Title:</label>
                        <div className="col-sm-9">
                            <input type="text" className="form-control" />
                        </div>
                    </div>
                    <div className="text-center">
                        <button type="submit" className="searchbtn">Search</button>
                    </div>
                </form>
            </div>
            <div className="col-4">


            </div>
            <div className="col-3">

            </div>

        </div>

    </div>
    <table className="table">
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Position</th>
            <th scope="col">Office</th>
            <th scope="col">Age</th>
            <th scope="col">Start date</th>
            <th scope="col">Salary</th>
            <th scope="col">Options</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Mark</td>
            <td>Accountant</td>
            <td>San Antonio</td>
            <td>33</td>
            <td>2006/02/12</td>
            <td>$12,000</td>
            <td><i className="fa fa-pencil edit" aria-hidden="true"></i><i className="fa fa-trash trash" data-toggle="modal" data-target="#exampleModalCenter" aria-hidden="true"></i></td>
          </tr>
          <tr>
            <td>Hunter</td>
            <td>Chief Executive Officer (CEO)</td>
            <td>Los Angeles</td>
            <td>56</td>
            <td>2012/08/12</td>
            <td>$90,000</td>
            <td><span className="glyphicon glyphicon-pencil"></span> <span className="glyphicon glyphicon-trash"></span></td>
          </tr>
          <tr>
            <td>Jack</td>
            <td>Junior Technical Author</td>
            <td>Chicago</td>
            <td>47</td>
            <td>2013/08/30</td>
            <td>$45,000</td>
            <td><span className="glyphicon glyphicon-pencil"></span> <span className="glyphicon glyphicon-trash" data-toggle="modal" data-target="#exampleModalCenter"></span></td>
          </tr>
          <tr>
            <td>Jaxson</td>
            <td>Software Engineer</td>
            <td>Houston</td>
            <td>30</td>
            <td>2010/09/08</td>
            <td>$60,000</td>
            <td><span className="glyphicon glyphicon-pencil"></span> <span className="glyphicon glyphicon-trash" data-toggle="modal" data-target="#exampleModalCenter"></span></td>
          </tr>
          <tr>
            <td>Grayson</td>
            <td>Software Engineer</td>
            <td>San Antonio</td>
            <td>37</td>
            <td>2011/05/17</td>
            <td>$60,000</td>
            <td><span className="glyphicon glyphicon-pencil"></span> <span className="glyphicon glyphicon-trash" data-toggle="modal" data-target="#exampleModalCenter"></span></td>
          </tr>
          <tr>
            <td>Colton</td>
            <td>Sales Assistant</td>
            <td>Dallas</td>
            <td>38</td>
            <td>2011/10/15</td>
            <td>$46,000</td>
            <td><span className="glyphicon glyphicon-pencil"></span> <span className="glyphicon glyphicon-trash" data-toggle="modal" data-target="#exampleModalCenter"></span></td>
          </tr>
        </tbody>
      </table>


    


     



<div className="modal fade" id="exampleModalCenter" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div className="modal-dialog modal-dialog-centered" role="document">
    <div className="modal-content">
      <div className="modal-header">
        <h5 className="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div className="modal-body">
        ...
      </div>
      <div className="modal-footer">
        <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" className="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
    </div>)
}
export default EditBook;