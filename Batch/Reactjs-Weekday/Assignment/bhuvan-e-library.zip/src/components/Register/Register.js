import "./Register.css";
import { useState } from "react";
import { alphanumeric, email, password } from '../../helper/validation';
import {registerValidationError} from '../../helper/constant';
import { useNavigate } from "react-router-dom";

const Register = () => {

  const navigate = useNavigate();

  const [getForm, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  })

  const [getFormValidation, setFormValidation] = useState({
    firstName: false,
    lastName: false,
    email: false,
    password: false
  })

  const [getGlobalFormCheck, setGlobalFormCheck] = useState(false);

  const onChangeHandler = (event) => {
    setForm({
      ...getForm,
      [event.target.name]: event.target.value
    })
  }

  const onSubmitHandler = (event) => {
    event.preventDefault();
    setGlobalFormCheck(true);
    setFormValidation({
      firstName: alphanumeric(getForm.firstName) ? false : true,
      lastName: alphanumeric(getForm.lastName) ? false : true,
      email: email(getForm.email) ? false : true,
      password: password(getForm.password) ? false : true,
    })
    if(alphanumeric(getForm.firstName) && alphanumeric(getForm.lastName) && email(getForm.email) && password(getForm.password)){
      sessionStorage.setItem("email",getForm.email);
      sessionStorage.setItem("password",getForm.password);
      navigate("login");
    }

    alert("hello");

  }

  return (<div>
    <div className="container">
      <div className="row">
        <div className="col-3">

        </div>
        <div className="col-5">
          <form onSubmit={onSubmitHandler}>
            <h1>Sign Up</h1>
            <div className="form-group">
              <label>First Name </label>
              <input type="text" onChange={onChangeHandler} className="form-control" name="firstName" placeholder="Enter Firstname" />
              {getGlobalFormCheck && getFormValidation.firstName && <div className="alert alert-danger" role="alert">
                {registerValidationError.firstName}
              </div>}
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input type="text" onChange={onChangeHandler} className="form-control" name="lastName" placeholder="Enter Lastname" />
              {getGlobalFormCheck && getFormValidation.lastName && <div className="alert alert-danger" role="alert">
                {registerValidationError.lastName}
              </div>}
            </div>
            <div className="form-group">
              <label>Email Address</label>
              <input type="email" className="form-control" onChange={onChangeHandler} name="email" email="true" placeholder="Enter Email" />
              {getGlobalFormCheck && getFormValidation.email && <div className="alert alert-danger" role="alert">
                {registerValidationError.email}
              </div>}
            </div>
            <div className="form-group">
              <label>Password</label>
              <input type="password" onChange={onChangeHandler} className="form-control" name="password" placeholder="Enter password" />
              {getGlobalFormCheck && getFormValidation.password && <div className="alert alert-danger" role="alert">
                {registerValidationError.password}
              </div>}
            </div>
            <div className="text-center">
              <button type="submit" className="btn">Sign Up</button>
            </div>
          </form>

        </div>
        <div className="col-4">

        </div>

      </div>

    </div>
  </div>)
}
export default Register;