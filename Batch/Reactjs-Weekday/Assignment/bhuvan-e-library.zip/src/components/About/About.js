import "./About.css";

const About=()=>{
    return(<div>
        <div className="bg">
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <h1 className="title"> Welcome To Library Management System</h1>
                </div>
            </div>
        </div>
    </div>
    <div className="container-fluid">
        <p className="content">All library offers a valuable means of education knowledge and turns to promote love of
            literature. Poor people, especially poor students who can’t afford to buy books, can make good use of the
            library. They can issues books and gather knowledge . It is a place where unlimited knowledge is preserved.
            A good library makes the taste for reading widespread and universal.</p>
    </div>
    </div>)
}
export default About;