import './App.css';
import EditBook from './components/EditBook/EditBook';
import SearchBookPage from './components/SearchBookPage/SearchBookPage';
import AddBook from './components/AddBook/AddBook';
import Header from './components/Header/Header';
import Login from './components/Login/Login';
import Register from './components/Register/Register';
import About from './components/About/About';
import './assets/icon/font-awesome/css/font-awesome.min.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';

function App() {
  return (
    <div>
      <BrowserRouter>
      <Header/>
      <Routes>
        <Route path="" element={<Register/>}></Route>
        <Route path="login" element={<Login/>}></Route>
        <Route path="about" element={<About/>}></Route>
        <Route path="searchBookPage" element={<SearchBookPage/>}></Route>
        <Route path="/login/searchBookPage" element={<SearchBookPage/>}></Route>
        <Route path="editBook" element={<EditBook/>}></Route>
        <Route path="addbook" element={<AddBook/>}></Route>
      </Routes>
      </BrowserRouter>
      
    </div>
  );
}

export default App;
