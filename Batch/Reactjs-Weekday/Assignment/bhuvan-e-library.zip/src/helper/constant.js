
export const registerValidationError={
    firstName:"FullName Should be alphanumeric",
    lastName:"lastName Should be alphanumeric",
    email:"email should be valid one",
    password:"password should be alphanumeric following symbol(_-&#@)",
    sessionDetails:"email and password not found"
};