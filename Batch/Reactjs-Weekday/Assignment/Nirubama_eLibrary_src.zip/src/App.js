// import logo from './logo.svg';
import './App.css';
import Login from './components/Login/Login';
import Register from './components/Register/Register';
import Header from './components/Header/Header';
import About from './components/About/About';
import SearchBooks from './components/SearchBooks/SearchBooks';
import AddBook from './components/AddBook/AddBook';
import './assets/icon/font-awesome/css/font-awesome.min.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';


function App() {
  return (
    <div>
      <BrowserRouter>
      <Header/>
      <Routes>
        <Route path="" element={<Register/>}></Route>
        <Route path="login" element={<Login/>}></Route>
        <Route path="about" element={<About/>}></Route>
        <Route path="addbook" element={<AddBook/>}></Route>
        <Route path="searchbooks" element={<SearchBooks/>}></Route>
      </Routes>
      </BrowserRouter>
     
    </div>
  );
}

export default App;
