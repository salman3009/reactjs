export const registerValidationError={
    firstName:"FullName should be alphanumeric with minimun three characters",
    lastName:"lastName should be alphanumeric with minimun three characters",
    email:"email should be valid one",
    password:"password should be alphanumeric and following symbol(_-&#@)",
    sessionDetails:"email and password not found"    
}


    // export const fullName = "FullName should be alphanumeric";
    // export const lastName = "lastName should be alphanumeric";
    // export const email = "email should be valid one";
    // export const password ="password should be alphanumeric and following symbol(_-&#@)";