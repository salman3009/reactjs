import Filter from './Filter/Filter';
import Table from './Table/Table';

const SearchBooks=()=>{
   return (<div>
       <Filter/>
        <Table/>
   </div>)

}
export default SearchBooks;