import './Filter.css';

const Filter=()=>{
   return (<div>
          <div class="container">
            <div class="row">
                <div class="col-6">
                    <form>
                        <div class="form-group">
                          <h1>Search Book</h1><br/>
                          <label>Book Title</label>
                          <input type="text" class="form-control"  name="bookTitle"  placeholder="Enter book title" />
                        </div>
                        <button type="submit" class="btn">search</button>
                    </form>
                </div>
                <div class="col-3">
 
                </div>
            </div>
            </div>
   </div>)

}
export default Filter;
