import './Table.css';

const Table=()=>{
   return (<div>
     <div className="container">
       <div class="row">
                <div class="col-12">
                    <table class="table table-bordered">
                        <tr>
                            <th>Book ID</th>
                            <th>Book Name</th>
                            <th>Book Description</th>
                            <th>Author</th>
                            <th>Number of Books available</th>
                            <th>Purchase</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Listen</td>
                            <td>Thriller</td>
                            <td>Nirubama</td>
                            <td>29</td>
                            <td><a href="./2login.html">Purchase</a></td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i data-toggle="modal" data-target="#exampletashModal" class="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td>112</td>
                            <td>Hunger</td>
                            <td>Auto Biography</td>
                            <td>Anu</td>
                            <td>229</td>
                            <td><a href="./2login.html">Purchase</a></td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i data-toggle="modal" data-target="#exampletashModal" class="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td>561</td>
                            <td>Jockey</td>
                            <td>Crime story</td>
                            <td>Anbu</td>
                            <td>97</td>
                            <td><a href="./2login.html">Purchase</a></td>
                            <td><i  data-toggle="modal" data-target="#exampleModal" class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i data-toggle="modal" data-target="#exampletashModal" class="fa fa-trash" aria-hidden="true"></i></td>
                        </tr>
                    </table>
                    
             </div>
            </div>
        </div>
   </div>)

}
export default Table;
