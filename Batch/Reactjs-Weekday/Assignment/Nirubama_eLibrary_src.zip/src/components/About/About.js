import './About.css';
import about from '../../assets/image/about.jpg'

const About=()=>{
   return (<div>
       <div class="bg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h1 class="title"> Welcome To Library Management System</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <p class="content">A library is a collection of materials, books or media that are accessible for use and not just for display purposes. A library provides physical (hard copies) or digital access (soft copies) materials, and may be a physical location or a virtual space, or both. A library's collection can include printed materials and other physical resources in many formats such as DVD, CD and cassette as well as access to information, music or other content held on bibliographic databases.</p>
        </div>
   </div>)

}
export default About;
