import './Login.css';
import { useState } from 'react';
import { email, password } from '../../helpers/validation';
import { registerValidationError } from '../../helpers/constant';
import { useNavigate } from 'react-router-dom';

const Login = () => {

  const navigate = useNavigate();

  const [getLoginForm, setLoginForm] = useState({
    email: '',
    password: ''
  });

  const [getLoginFormValidation, setLoginFormValidation] = useState({
    email: false,
    password: false,
    sessionDetail: false
  });

  const [getLoginGlobalCheck, setLoginGlobalCheck] = useState(false);

  const onChangeEventHandler=(event)=>{
    setLoginForm({
      ...getLoginForm,
      [event.target.name]:event.target.value
    })
}
  const onSubmitEventHandler=(event)=>{
    event.preventDefault();
    setLoginGlobalCheck(true);
    setLoginFormValidation({
      sessionDetail:false,
      email:email(getLoginForm.email)?false:true,
      password:password(getLoginForm.password)?false:true
    });
    if(getLoginForm.email && getLoginForm.password){
      let email = sessionStorage.getItem('email');
      let password = sessionStorage.getItem('password');
      if(email!=getLoginForm.email || password!=getLoginForm.password){
        setLoginFormValidation({
          ...getLoginFormValidation,
          sessionDetail:true
        })
      }
      else{
        navigate('searchbooks');
      }
    }
}
  return (<div>
    <div className="container box">
      <div className="row">
        <div className="col-3">

        </div>
        <div className="col-6">
          {getLoginGlobalCheck && getLoginFormValidation.sessionDetail && <div className="alert alert-danger" role="alert">
            {registerValidationError.sessionDetails}
          </div>}
          <form onSubmit={onSubmitEventHandler}>
            <h1>Library Management System</h1>
            <div className="form-group">
              <label>User name</label>
              <input type="text" onChange={onChangeEventHandler} className="form-control" name="email" placeholder="Enter email" />
              {getLoginGlobalCheck && getLoginFormValidation.email && <div className="alert alert-danger" role="alert">
                {registerValidationError.email}
              </div>}
            </div>
            <div className="form-group">
              <label>Password</label>
              <input type="password" onChange={onChangeEventHandler} className="form-control" name="password" placeholder="Password" />
              {getLoginGlobalCheck && getLoginFormValidation.password && <div className="alert alert-danger" role="alert">
                {registerValidationError.password}
              </div>}
            </div>
            <button type="submit" className="btn" >Login</button>
          </form>
        </div>
        <div className="col-3">

        </div>
      </div>
    </div>
  </div>)

}
export default Login;