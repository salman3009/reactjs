import './Register.css';
import { alphanumeric, password, email } from '../../helpers/validation.js';
import { registerValidationError } from '../../helpers/constant.js';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Register = () => {

  const navigate = useNavigate();
  const [getForm, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  })

  const [getFormValidation, setFormValidation] = useState({
    firstName: false,
    lastName: false,
    email: false,
    password: false
  })

  const [getGlobalFormCheck, setGlobalFormCheck] = useState(false);

  const onChangeHandler = (event) => {
    setForm({
      ...getForm,
      [event.target.name]: event.target.value
    })
  }

  const onSubmitHandler = (event) => {
    event.preventDefault();
    setGlobalFormCheck(true);
    setFormValidation({
      firstName: alphanumeric(getForm.firstName) ? false : true,
      lastName: alphanumeric(getForm.lastName) ? false : true,
      email: email(getForm.email) ? false : true,
      password: password(getForm.password) ? false : true
    });
    // alert("Hi NIru");
    if(alphanumeric(getForm.firstName) && alphanumeric(getForm.lastName) && email(getForm.email) && password(getForm.password)){
      sessionStorage.setItem("email",getForm.email);
      sessionStorage.setItem("password",getForm.password);
      navigate('login');
   }
  }

  return (<div>
    <div className="container box">
      <div className="row">
        <div className="col-3">
        </div>
        <div className="col-6">
          <form onSubmit={onSubmitHandler}>
            <h1>Sign Up</h1>
            <div className="form-group">
              <label>First name</label>
              <input type="text" onChange={onChangeHandler} className="form-control" name="firstName" placeholder="First name" />
              {getGlobalFormCheck && getFormValidation.firstName &&<div className="alert alert-danger" role="alert">
                {registerValidationError.firstName}
              </div>}
            </div>
            <div className="form-group">
              <label>Last name</label>
              <input type="text" onChange={onChangeHandler} className="form-control" name="lastName" placeholder="Last name" />
              {getGlobalFormCheck && getFormValidation.lastName &&<div className="alert alert-danger" role="alert">
                {registerValidationError.lastName}
              </div>}
            </div>
            <div className="form-group">
              <label>Email address</label>
              <input type="text" onChange={onChangeHandler} className="form-control" name="email" placeholder="Enter email" />
              {getGlobalFormCheck && getFormValidation.email &&  <div className="alert alert-danger" role="alert">
                {registerValidationError.email}
              </div>}
            </div>
            <div className="form-group">
              <label htmlFor="exampleInputPassword1">Password</label>
              <input type="password" onChange={onChangeHandler} className="form-control" name="password" placeholder="Enter password" />
              {getGlobalFormCheck && getFormValidation.password && <div className="alert alert-danger" role="alert">
                {registerValidationError.password}
              </div>}
            </div>
            <button type="submit" className="btn" >Signup</button>
          </form>
        </div>
        <div className="col-3">

        </div>
      </div>
    </div>
  </div>)

}
export default Register;