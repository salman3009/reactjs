import './AddBook.css';

const AddBook=()=>{
   return (<div>
       <div class="container">
            <div class="row">
                <div class="col-3">
                </div>
                <div class="col-6">
                 <form>
                   <h1>Add Book</h1>
                   <div class="form-group">
                  <label>Book ID</label>
                  <input type="number" class="form-control"  name="bookid"  placeholder="Book ID" />
                </div>
                <div class="form-group">
                   <label>Book Title</label>
                   <input type="text" class="form-control"  name="booktitle"  placeholder="Book Title" />
                 </div>
                      <div class="form-group">
                        <label>Book Description</label>
                        <input type="text" class="form-control"  name="bookdescription"  placeholder="Book Description" />
                      </div>
                      <div class="form-group">
                        <label>Author Name</label>
                        <input type="text" class="form-control"  name="authorname"  placeholder="Author Name" />
                      </div>
                      <div class="form-group">
                        <label>Number of book available</label>
                        <input type="number" class="form-control"  name="numberofbooks"  placeholder="12" />
                      </div>
                     <button type="submit" class="btn" >Add Book</button>
                   </form>
             </div>
             <div class="col-3">
                    
             </div>
            </div>
        </div>
   </div>)

}
export default AddBook;
