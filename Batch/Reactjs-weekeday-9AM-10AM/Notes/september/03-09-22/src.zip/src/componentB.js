import ComponentC from "./ComponentC";
const ComponentB =()=>{


            


    return(<div>
       <div>ComponentB</div>
       <ComponentC/>
    </div>)
}
export default ComponentB;