import ComponentB from "./componentB";
const ComponentA =()=>{

            


     return(<div>
        <div>ComponentA</div>
        <ComponentB/>
     </div>)
}
export default ComponentA;