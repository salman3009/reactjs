alert("welcome to javascript");
alert("welcome to css");
alert('welcome to html');