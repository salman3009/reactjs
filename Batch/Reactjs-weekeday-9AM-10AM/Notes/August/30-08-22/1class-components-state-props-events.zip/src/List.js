import { Component } from "react";
import './App.css';

class List extends Component{
    render(){
        return(<div className="list-box">
            <h4>Transactions</h4>
            <strong>
                {new Date().toISOString()}-{100}-{'ADD'}
            </strong>
            <strong>
                {new Date().toISOString()}-{100}-{'ADD'}
            </strong>
            <strong>
                {new Date().toISOString()}-{100}-{'ADD'}
            </strong>
        </div>)
    }
}

export default List;