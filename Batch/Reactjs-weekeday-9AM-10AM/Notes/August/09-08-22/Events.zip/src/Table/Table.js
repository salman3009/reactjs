
import './Table.css';

function Table(){

    const onClickHandler = (event)=>{
        console.log(event.target.id);
        alert("onClickHandler");
        return 1;
    }

    const onChangeHandler =(event) =>{
        console.log(event.target.name);
        console.log(event.target.value);
    }

    return (<div>
       <table>
           <tr>
               <td><input type="text" name="firstName" onChange={onChangeHandler}/></td>
               <td><button id="add" onClick={onClickHandler}>Submit</button></td>
           </tr>
       </table>
    </div>)
}

export default Table;