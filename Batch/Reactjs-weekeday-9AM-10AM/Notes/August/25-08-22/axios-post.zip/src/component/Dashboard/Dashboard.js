import './Dashboard.css';
import {useState,useEffect} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

function Dashboard(){
 


  const[getDetails,setDetails]=useState([]);

  useEffect(()=>{
          axios.get('http://localhost:3000/expense').then((result)=>{
                  console.log(result.data);
                  setDetails(result.data)
          }).catch((error)=>{
                 console.log(error);
          })
  },[])

 return (<div>
       <div className="container">
           <div className="row">
            
            <div className="col-4">
                <form>
                    <div className="form-group">
                        <label>expense Title</label>
                        <input type="text" className="form-control" id="expenseTitle"  name="expenseTitle" placeholder="expenseTitle"/>
                       
                      </div>
          
                    
                   
                    <button type="submit" className="btn btn-success">Search</button>
                  </form>
            </div> 
            <div className="col-4"></div>   
            <div className="col-4">
              <button  className="btn btn-success"><Link to="/addexpense">Add Expense</Link></button>
              </div> 
        </div> 
        
        </div>

        <div className="container">
        <div className="row">
            <div className="col-12">
                <table className="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Expense Title</th>
                        <th scope="col">Expense Category</th>
                        <th scope="col">Expense Amount</th>
                        <th scope="col">Expense Date</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                 
                     {
                       getDetails.map((obj,index)=>{
                          return (<tr key={index}>
                            <td>{index+1}</td>
                            <td>{obj.title}</td>
                            <td>{obj.category}</td>
                            <td>{obj.amount}</td>
                            <td>{obj.date}</td>
                            <td><i data-toggle="modal" data-target="#exampleModal" className="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                            <td><i className="fa fa-trash" aria-hidden="true"></i></td>
                          </tr>) 
                       })
                     }
           
                   
                    </tbody>
                  </table>
            </div>
        </div>
        </div>
 </div>)
}
export default Dashboard;