export const registerLabel={
  firstName:"firstName cannot be empty",
  lastName:"LastName cannot be empty",
  email:"Email cannot be empty",
  password:"Password cannot be empty",
  validationMatch:"email and password not match"
};