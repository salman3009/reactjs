import './Expense.css';

function Expense(){
    return(<div className="container">
    <div className="row">
     
     <div className="col-4">
         <form>
             <div className="form-group">
                 <label>expense Title</label>
                 <input type="text" className="form-control" id="expenseTitle"  name="expenseTitle" placeholder="expenseTitle"/>
                
               </div>
               <div className="form-group">
                 <label>Expense category</label>
                 <select className="form-control" id="expenseCategory" name="expenseCategory">
                   <option>1</option>
                   <option>2</option>
                   <option>3</option>
                   <option>4</option>
                   <option>5</option>
                 </select>
               </div>
               <div className="form-group">
                 <label>Expense Amount</label>
                 <input type="number" className="form-control" id="expenseAmount"  name="expenseAmount" placeholder="expenseAmount"/>
                
               </div>
               <div className="form-group">
                 <label>Date</label>
                 <input type="date" className="form-control" id="date"  name="date" placeholder="date"/>
                
               </div>
             
            
             <button type="submit" className="btn btn-success">Add</button>
           </form>
     </div> 
     <div className="col-4"></div>   
     <div className="col-4"></div> 
 </div> 
 
 </div>)
}
export default Expense;