
import { useState } from 'react';
import './Table.css';
import cart from '../Assets/Image/download.png';
function Table(){

    const[getFullName,setFullName]=useState("no value");
    const[getFlag,setFlag] = useState(false);

    const onClickHandler = (event)=>{
        console.log(event.target.id);
        alert("onClickHandler");
        setFullName('');
        setFlag(true);
    }

    const onChangeHandler =(event) =>{
        console.log(event.target.name);
        console.log(event.target.value);
        setFullName(event.target.value);
       
    }

    return (<div>
       <table>
           <tr>
               <td><input type="text" name="firstName" onChange={onChangeHandler}/></td>
               <td><button id="add" onClick={onClickHandler}>Submit</button></td>
           </tr>
       </table>
       <h1>{getFullName}</h1>
       {getFlag && <div>Succesfully submitted</div>}
       {getFlag?<div>returning here
           <h1>Details</h1>
           <h1>procedure</h1>
       </div>:''}
       <img src={cart}/>
    </div>)
}

export default Table;