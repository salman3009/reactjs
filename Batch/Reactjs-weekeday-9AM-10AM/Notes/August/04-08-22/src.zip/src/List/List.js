import './List.css';
function List() {

    return (
        <div className="box">

        </div>
    )
}
export default List;