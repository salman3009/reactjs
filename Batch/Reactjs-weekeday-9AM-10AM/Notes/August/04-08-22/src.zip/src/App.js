
import './App.css';
import List from './List/List';

function App(){

      return (<div>
         <List/>
         <List/>
         <List/>
         <List/>
         <List/>
         <List/>
         <List/>
        </div>
        )

}

export default App;