import './Login.css';

function Login(){
  return (
    <div className="container">
     <div className="row">
      <div className="col-4"></div> 
      <div className="col-4">
          <form>
             
                <div className="form-group">
                  <label>Email</label>
                  <input type="email" className="form-control" id="email"  name="email" placeholder="email"/>
                 
                </div>
                <div className="form-group">
                  <label>password</label>
                  <input type="password" className="form-control" id="password"  name="password" placeholder="password"/>
                 
                </div>
              
             
              <button type="submit" className="btn btn-success">Submit</button>
            </form>
      </div> 
      <div className="col-4"></div>   
  </div> 
  
  </div>)  
}
export default Login;