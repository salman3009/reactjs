import './Register.css';
function Register(){
  return(
     
    <div className="container">
    <div className="row">
     <div className="col-4"></div> 
     <div className="col-4">
         <form>
             <div className="form-group">
                 <label>first Name</label>
                 <input type="text" className="form-control" id="firstName"  name="firstName" placeholder="first Name"/>
                
               </div>
               <div className="form-group">
                 <label>last Name</label>
                 <input type="text" className="form-control" id="lastName"  name="lastName" placeholder="first Name"/>
                
               </div>
               <div className="form-group">
                 <label>Email</label>
                 <input type="email" className="form-control" id="email"  name="email" placeholder="email"/>
                
               </div>
               <div className="form-group">
                 <label>password</label>
                 <input type="password" className="form-control" id="password"  name="password" placeholder="password"/>
                
               </div>
             
            
             <button type="submit" className="btn btn-success">Submit</button>
           </form>
     </div> 
     <div className="col-4"></div>   
 </div> 
 
 </div>
)

}
export default Register;