import {UserContext} from './App';

function ComponentC(){
    return(<div>
        <UserContext.Consumer>
            {
                obj=>{
                    return (<div>{obj}</div>)
                }
            }
        </UserContext.Consumer>
        This is component</div>)
}

export default ComponentC;