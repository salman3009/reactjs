import { useReducer } from 'react';
import './App.css';
import UseReducer from './UseReducer';
import UseRef from './UseRef';
import UseCallBack from './UseCallBack';
import UseMemo from './UseMemo';
function App() {



  return (
    <div className="App">
           <UseMemo/>
           {/* <UseCallBack/> */}
           {/* <UseRef/> */}
          {/* <UseReducer/> */}
    </div>
  );
}

export default App;
