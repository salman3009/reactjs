
const Users = {
    
    loadUsers(dispatch) {
        dispatch({
            type: 'success',
            payload: [44,55,66,55]
        })
      
    }
}
export default Users;