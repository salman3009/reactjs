
import ComponentB
 from "./ComponentB";

 import {useSelector } from 'react-redux';


function ComponentA(){

    const usersInfo = useSelector((state) => state.users);

    return(<div>This is component A {usersInfo.list.map((obj)=>{
         return (<div>{obj}</div>)
    })}</div>)
}

export default ComponentA;